"""Operator-only checks, launched after reading the GREEN regression logs."""
import hashlib, json, subprocess, sys, tarfile, time
from pathlib import Path
assert Path.cwd().name=='841-sweep-20261105'
sys.path.insert(0,str(Path('scripts/shape-sweep').resolve()))
from cases import matrix
from evidence import summarize
from analyze import ratios
statuses=json.loads(Path('evidence/review-green-status.json').read_text())
assert [r['check'] for r in statuses]==['python','native','fmt','probe']
assert all(r['exit_status']==0 for r in statuses)
assert 'Ran 10 tests' in Path('evidence/review-python-green.log').read_text()
assert '7 passed; 0 failed' in Path('evidence/review-native-green.log').read_text()
assert '1 passed; 0 failed' in Path('evidence/review-probe-green.log').read_text()
builds=json.loads(Path('evidence/variants/builds.json').read_text())
for name,row in builds.items():
    assert hashlib.sha256(Path('evidence/variants',name).read_bytes()).hexdigest()==row['sha256']
assert hashlib.sha256(Path('evidence/query-probe').read_bytes()).hexdigest()=='f3ab6172495e8be4504428cd00ba78ffd24340b5a61eb5af69444e7d0725e9c4'
selected=[c['id'] for c in matrix(True) if c['family']=='scalar' and not c['pending'] and c['operation']=='asc' and c['limit']==10]
assert len(selected)==1
Path('evidence/review-selector.json').write_text(json.dumps(selected))
steps=[
 ('selector',['python3','scripts/shape-sweep/run.py','--binary','evidence/variants/baseline','--out','evidence/review-selector-smoke','--fixtures','fixtures-review-smoke','--smoke','--families','scalar','--case-ids','evidence/review-selector.json','--sessions','1','--samples','1','--core-revision','5a0ff549271084018c7d4e6050658e64e7e6432e']),
 ('pairs',['python3','scripts/shape-sweep/run_variants.py','--binaries','evidence/variants','--out','evidence/review-paired-smoke','--fixtures','fixtures-review-smoke','--smoke','--sessions','2','--samples','1']),
 ('diagnostics',['python3','scripts/shape-sweep/run_diagnostics.py','--binary','evidence/query-probe','--out','evidence/review-query-memory-smoke','--fixtures','fixtures-review-smoke','--public-results','evidence/review-selector-smoke'])]
for name,command in steps:
    print(time.strftime('%H:%M:%S',time.gmtime()),'starting',name,flush=True)
    with Path(f'evidence/review-{name}-smoke.log').open('x') as out:
        subprocess.run(command,stdout=out,stderr=subprocess.STDOUT,check=True)
for name,sessions,wanted in [('review-selector-smoke',1,1),('review-paired-smoke',2,64)]:
    p=Path('evidence',name)
    cases=json.loads((p/'cases.json').read_text())
    rows=[json.loads(l) for l in (p/'samples.jsonl').read_text().splitlines()]
    result=summarize(cases,rows,sessions,1)
    assert result['reconciliation']=={'cases':len(cases),'expected_samples':wanted,'measured':wanted}
    (p/'review-reconciled.json').write_text(json.dumps(result,indent=2))
    if sessions==2:
        result=ratios(rows)
        assert len(result)==16 and all(r['pairs']==2 and len(r['placements'])==2 for r in result)
        (p/'review-ratios.json').write_text(json.dumps(result,indent=2))
obs=json.loads(Path('evidence/review-query-memory-smoke/observations.json').read_text())
assert len(obs)==1 and obs[0]['disposition']=='measured'
archive=Path('evidence/reviewed-build-inputs.tar.gz')
assert not archive.exists()
with tarfile.open(archive,'w:gz') as out:
    for p in sorted(Path('scripts/shape-sweep').rglob('*')):
        if p.is_file() and not any(part in {'target','__pycache__'} for part in p.parts):
            out.add(p)
    for p in ['Cargo.toml','Cargo.lock']:
        out.add(p)
Path('evidence/reviewed-build-hashes.txt').write_text(hashlib.sha256(archive.read_bytes()).hexdigest()+'  '+str(archive)+'\n')
Path('evidence/review-smokes-complete.json').write_text(json.dumps({'verified':True,'selector_samples':1,'paired_samples':64,'paired_groups':16,'placements_per_group':2,'query_memory_cases':1,'frozen_binaries_unchanged':True},indent=2))
print('all reviewed controller smokes verified; measured executables unchanged',flush=True)

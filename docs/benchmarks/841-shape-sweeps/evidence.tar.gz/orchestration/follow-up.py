import json
import os
from pathlib import Path
import subprocess
import time

root = Path('<scratch>')
os.chdir(root)
while Path('/proc/649906').exists():
    time.sleep(10)
if not Path('evidence/public-batch/summary.json').exists():
    raise SystemExit('Public sweep incomplete; no follow-up timings started.')
steps = [
    ('public-reconciliation', ['python3','scripts/shape-sweep/evidence.py','evidence/public-batch']),
    ('recursive-run', ['python3','scripts/shape-sweep/run_variants.py','--binaries','evidence/variants','--out','evidence/recursive','--fixtures','fixtures']),
    ('recursive-reconciliation', ['python3','scripts/shape-sweep/evidence.py','evidence/recursive']),
    ('churn-run', ['python3','scripts/shape-sweep/run_diagnostics.py','--binary','evidence/query-probe','--out','evidence/churn','--fixtures','churn-scratch','--churn']),
    ('query-memory-run', ['python3','scripts/shape-sweep/run_diagnostics.py','--binary','evidence/query-probe','--out','evidence/query-memory','--fixtures','fixtures','--public-results','evidence/public-batch']),
    ('recursive-memory-run', ['python3','scripts/shape-sweep/run_diagnostics.py','--binary','evidence/query-probe','--out','evidence/recursive-memory','--fixtures','fixtures','--public-results','evidence/recursive/baseline']),
    ('churn-summary', ['python3','scripts/shape-sweep/analyze.py','churn','evidence/churn/generations.jsonl']),
    ('recursive-ratios', ['python3','scripts/shape-sweep/analyze.py','ratios','evidence/recursive/samples.jsonl']),
]
results = []
for name, command in steps:
    print(time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()), 'starting', name, flush=True)
    with Path(f'evidence/{name}.log').open('w') as log:
        status = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT).returncode
    results.append(dict(step=name,command=command,exit_status=status))
    Path('evidence/follow-up-status.json').write_text(json.dumps(results,indent=2))
    print(time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()), 'finished', name, status, flush=True)

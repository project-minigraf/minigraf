"""Continue the authorized audit only after all idle-gated regression checks pass."""
import json, subprocess, time
from pathlib import Path
assert Path.cwd().name=='841-sweep-20261105'
status=Path('evidence/review-green-status.json')
while True:
    if status.exists():
        try:
            checks=json.loads(status.read_text())
        except json.JSONDecodeError:
            time.sleep(1)
            continue
        if any(r['exit_status'] for r in checks):
            raise SystemExit('Regression check failed; inspect retained logs before resuming.')
        if [r['check'] for r in checks]==['python','native','fmt','probe']:
            break
    time.sleep(10)
for name,command in [('reviewed-smokes',['python3','-u','review-postgreen-smokes.py']),
                     ('remaining-sweep',['python3','-u','follow-up-reviewed.py'])]:
    print(time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'starting',name,flush=True)
    result=subprocess.run(command)
    print(time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'finished',name,result.returncode,flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)

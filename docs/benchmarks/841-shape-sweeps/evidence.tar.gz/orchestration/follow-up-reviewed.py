"""Operator queue: launch only after review regression checks pass and timings stop."""
import json
from pathlib import Path
import subprocess
import time

root = Path.cwd()
if root.name != '841-sweep-20261105' or not Path('evidence/public-batch/summary.json').exists():
    raise SystemExit('Wrong scratch directory or incomplete public sweep.')
rows = [json.loads(line) for line in Path('evidence/public-batch/samples.jsonl').read_text().splitlines()]
cases = json.loads(Path('evidence/public-batch/cases.json').read_text())
capped = {r['case'] for r in rows if r['disposition'] == 'timeout'}
selected = [c['id'] for c in cases if c['id'] in capped and c['family'] == 'window' and c['n'] == 5_000_000]
if not selected:
    raise SystemExit('No capped large windows; review retry selection before proceeding.')
Path('evidence/capped-windows.json').write_text(json.dumps(selected, indent=2))
steps = [
    ('public-reconciliation', ['python3','scripts/shape-sweep/evidence.py','evidence/public-batch']),
    ('window-retry-run', ['python3','scripts/shape-sweep/run.py','--binary','evidence/variants/baseline',
     '--out','evidence/window-retry','--fixtures','fixtures','--families','window',
     '--case-ids','evidence/capped-windows.json','--sessions','3','--samples','1','--timeout','600',
     '--core-revision','5a0ff549271084018c7d4e6050658e64e7e6432e']),
    ('window-retry-reconciliation', ['python3','scripts/shape-sweep/evidence.py','evidence/window-retry','--samples','1']),
    ('recursive-run', ['python3','scripts/shape-sweep/run_variants.py','--binaries','evidence/variants','--out','evidence/recursive','--fixtures','fixtures']),
    ('recursive-reconciliation', ['python3','scripts/shape-sweep/evidence.py','evidence/recursive']),
    ('recursive-ratios', ['python3','scripts/shape-sweep/analyze.py','ratios','evidence/recursive/samples.jsonl']),
    ('churn-run', ['python3','scripts/shape-sweep/run_diagnostics.py','--binary','evidence/query-probe','--out','evidence/churn','--fixtures','churn-scratch','--churn']),
    ('churn-summary', ['python3','scripts/shape-sweep/analyze.py','churn','evidence/churn/generations.jsonl']),
    ('query-memory-run', ['python3','scripts/shape-sweep/run_diagnostics.py','--binary','evidence/query-probe','--out','evidence/query-memory','--fixtures','fixtures','--public-results','evidence/public-batch']),
    ('window-retry-memory-run', ['python3','scripts/shape-sweep/run_diagnostics.py','--binary','evidence/query-probe','--out','evidence/window-retry-memory','--fixtures','fixtures','--public-results','evidence/window-retry']),
    ('recursive-memory-run', ['python3','scripts/shape-sweep/run_diagnostics.py','--binary','evidence/query-probe','--out','evidence/recursive-memory','--fixtures','fixtures','--public-results','evidence/recursive/baseline']),
]
results = []
for name, command in steps:
    print(time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()), 'starting', name, flush=True)
    started = time.time()
    with Path(f'evidence/{name}.log').open('x') as log:
        status = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT).returncode
    results.append(dict(step=name,command=command,exit_status=status,started_unix=started,finished_unix=time.time()))
    Path('evidence/follow-up-status.json').write_text(json.dumps(results,indent=2))
    print(time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()), 'finished', name, status, flush=True)
    if status:
        raise SystemExit(f'{name} failed; retained evidence, review before resuming.')

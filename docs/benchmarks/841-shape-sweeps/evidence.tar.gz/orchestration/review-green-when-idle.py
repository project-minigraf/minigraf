import json, os, subprocess, sys, time
from pathlib import Path
assert Path.cwd().name=='841-sweep-20261105'
sys.path.insert(0,str(Path('scripts/shape-sweep').resolve()))
from run import idle_samples
os.environ['PATH']=str(Path.home()/'.cargo/bin')+':'+os.environ['PATH']
log=Path('evidence/review-green-wait.jsonl')
with log.open('x') as out:
    while True:
        samples=idle_samples()
        available=all(s['idle_percent']>=95 and s['swapped_pages']==0 for s in samples)
        out.write(json.dumps({'utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'samples':samples,'available':available})+'\n');out.flush()
        print(time.strftime('%H:%M:%S',time.gmtime()),'idle range',round(min(s['idle_percent'] for s in samples),1),round(max(s['idle_percent'] for s in samples),1),'available',available,flush=True)
        if available:
            break
        time.sleep(60)
checks=[
 ('python',['python3','-m','unittest','discover','-s','scripts/shape-sweep']),
 ('native',['cargo','test','--offline','--locked','--manifest-path','scripts/shape-sweep/native/Cargo.toml']),
 ('fmt',['cargo','fmt','--manifest-path','scripts/shape-sweep/native/Cargo.toml','--','--check']),
 ('probe',['evidence/query-probe','db::shape_sweep::smoke_churn_oracles','--exact','--nocapture'])]
statuses=[]
for name,command in checks:
    with Path(f'evidence/review-{name}-green.log').open('x') as out:
        result=subprocess.run(command,stdout=out,stderr=subprocess.STDOUT)
    statuses.append({'check':name,'command':command,'exit_status':result.returncode})
    Path('evidence/review-green-status.json').write_text(json.dumps(statuses,indent=2))
    print(name,result.returncode,flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)

#!/usr/bin/env python3
"""Offline-prepared #858 physical collector. See README.md for safety boundaries.

Only schedule-run mutates AWS. AWS_PROFILE/AWS_REGION are inherited. A durable
intent and unique run name precede scheduling; ambiguous acceptance NEVER causes
a second submission. State stores redacted ARNs, restored from supplied uploads.
"""
import argparse
import copy
import datetime
import fcntl
import hashlib
import importlib.util
import io
import json
import math
import os
from pathlib import Path
import re
import subprocess
import sys
import time
import urllib.parse
import urllib.request
import uuid
import zipfile

sys.dont_write_bytecode = True
BASE = Path('<local-path>')
FLAG = 'repeat-timed-operation-twice'
ORDER = [(s, i) for i in range(1, 7) for s in ('B1', 'V', 'B2')]
READS = {'list-projects', 'get-upload', 'get-device-pool', 'get-device',
         'list-runs', 'get-run', 'list-jobs', 'list-suites', 'list-tests', 'list-artifacts'}
LIMIT = 128 * 1024 * 1024
# Only this known predecessor can migrate a pending artifact checkpoint without
# reparse: stream selection/parsing is unchanged by the download-size fix.
ARTIFACT_RESUME_DRIVER_SHA256 = 'cfceaf3e677d4d77ff3fff714960e77e956e0aeced8d9dfe819c96d56b58aade'


class Stop(Exception):
    """A recoverable stop; retain state and never silently schedule another run."""


class ArtifactTooLarge(ValueError):
    def __init__(self, size_bytes):
        super().__init__('artifact exceeds size limit')
        self.size_bytes = size_bytes


def require(condition, reason):
    if not condition:
        raise ValueError(reason)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def encoded(value):
    return (json.dumps(value, indent=2, sort_keys=True, allow_nan=False)+'\n').encode()


def atomic(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name+'.tmp')
    with temporary.open('wb') as handle:
        handle.write(data)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, path)
    fd = os.open(str(path.parent), os.O_RDONLY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def parser_default(platform):
    repo = 'minigraf-swift' if platform == 'ios' else 'minigraf-android'
    return BASE / repo / '.worktrees/858-qualification/bench/device-farm/qualification/parse_samples.py'


def load_parser(path):
    spec = importlib.util.spec_from_file_location('qualification_parser', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def parser_fingerprint(path):
    # Stream normalization/selection in this driver is part of the parser too.
    return digest(encoded(dict(driver_sha256=digest(Path(__file__).read_bytes()),
                               parser_sha256=digest(path.read_bytes()))))


def filter_for(platform, set_name):
    prefix = 'BenchmarkTests/' if platform == 'ios' else 'io.github.project_minigraf.benchmark.BenchmarkTest#'
    return prefix + ('testQualificationSlowdown' if set_name == 'V' else 'testQualificationBaseline')


class Collector:
    def __init__(self, args):
        self.args = args
        self.out = args.out.resolve()
        self.platform = args.platform
        self.build = json.loads(args.build_json.read_text())
        self.runtime = json.loads(args.runtime_json.read_text())
        self.parser_path = args.parser or parser_default(self.platform)
        self.parser = load_parser(self.parser_path)
        self.account = self.validate_inputs()
        self.job_minutes = max(1, math.ceil(args.run_timeout / 60))
        self.identity = dict(platform=self.platform, build=self.build, runtime=self.runtime,
                             app=args.app_arn, test_package=args.test_package_arn, pool=args.device_pool_arn,
                             parser_sha256=digest(self.parser_path.read_bytes()),
                             parser_fingerprint=parser_fingerprint(self.parser_path),
                             core_revision=args.core_revision, run_timeout=args.run_timeout,
                             region=os.environ.get('AWS_REGION'), profile=os.environ.get('AWS_PROFILE'))
        # Preserve the legacy account-bound input hash. Offline reparse can
        # migrate its parser component without reconstructing redacted ARNs.
        self.base_fingerprint = digest(encoded({k: v for k, v in self.identity.items()
                                               if k != 'parser_fingerprint'}))
        self.fingerprint = digest(encoded(dict(base_input_fingerprint=self.base_fingerprint,
                                               parser_fingerprint=self.identity['parser_fingerprint'])))
        self.state = None
        self.project = None

    def validate_inputs(self):
        a = self.args
        for key in ('core_revision', 'binding_revision', 'harness_revision', 'harness_sha256'):
            require(re.fullmatch('[0-9a-f]{%d}' % (64 if key.endswith('sha256') else 40),
                                 self.build.get(key, '')) is not None, 'missing/invalid build '+key)
        require(a.core_revision == self.build['core_revision'], 'core revision differs from build.json')
        require(self.build.get('profile') == 'Release' and self.build.get('slowdown_flag') == FLAG,
                'missing Release profile or pre-registered source flag')
        key = 'physical' if self.platform == 'ios' else 'arm64-v8a'
        native = self.build.get('native_artifacts', {}).get(key, {})
        require(re.fullmatch('[0-9a-f]{64}', native.get('sha256', '')) is not None,
                'missing executed native artifact hash')
        if self.platform == 'ios':
            require(native.get('architecture') == 'arm64', 'physical iPhone requires arm64')
        self.artifact_hash = native['sha256']
        require(isinstance(self.runtime, dict) and self.runtime and
                all(isinstance(v, str) and v.strip() and not re.search(r'TODO|TBD|UNKNOWN|ACTUAL_|REPLACE|[<>]', v, re.I)
                    for v in self.runtime.values()), 'runtime pins must be nonempty strings without placeholders')
        model, os_name = ('iPhone 15', 'iOS 18.5') if self.platform == 'ios' else ('Pixel 7', 'Android 14')
        require(self.runtime.get('provider') == 'Device Farm' and self.runtime.get('model') == model
                and self.runtime.get('os') == os_name, 'runtime does not pin registered physical reference')
        fields = ('os_build', 'machine', 'architecture') if self.platform == 'ios' else (
            'fingerprint', 'hardware', 'product', 'loaded_abi', 'sdk')
        require(all(self.runtime.get(k) for k in fields), 'missing physical runtime pins: '+', '.join(fields))
        if self.platform == 'ios':
            require(self.runtime['machine'] == 'iPhone15,4' and self.runtime['architecture'] == 'arm64',
                    'iPhone 15 machine/architecture mismatch')
        else:
            require(self.runtime['loaded_abi'] == 'arm64-v8a' and self.runtime['sdk'] == '34',
                    'Pixel 7 must execute arm64-v8a on API 34')
        arns = [a.app_arn, a.test_package_arn, a.device_pool_arn]
        require(all(re.fullmatch(r'arn:[a-z-]+:devicefarm:[a-z0-9-]+:\d{12}:[^\s]+', arn)
                    for arn in arns), 'invalid Device Farm ARN')
        accounts = {arn.split(':')[4] for arn in arns}
        require(len(accounts) == 1, 'inputs must share an AWS account')
        region = os.environ.get('AWS_REGION')
        require(region and all(arn.split(':')[3] == region for arn in arns),
                'AWS_REGION must match all input ARNs')
        require(os.environ.get('AWS_PROFILE'), 'AWS_PROFILE is required')
        require(0 < a.max_attempts <= 54 and math.isfinite(a.max_device_minutes)
                and a.max_device_minutes >= 0, 'invalid attempt/minute cap')
        require(math.isfinite(a.poll_interval) and a.poll_interval >= 0 and
                math.isfinite(a.run_timeout) and 0 < a.run_timeout <= 9000,
                'poll interval must be nonnegative; run timeout must be in (0, 9000] seconds')
        for s in ('B1', 'B2', 'V'):
            supplied = getattr(a, 'filter_'+s.lower())
            require(supplied is None or supplied == filter_for(self.platform, s),
                    'filter differs from pre-registered harness method for '+s)
        return accounts.pop()

    def redact(self, data):
        # Bytes work for both UTF-8 logs and binary payloads. No URLs are retained
        # in metadata. Known account IDs are removed even outside an ARN.
        data = re.sub(rb'(arn:[a-z-]+:[a-z0-9-]+:[a-z0-9-]*:)\d{12}:', rb'\1REDACTED:', data)
        return re.sub(rb'(?<!\d)'+self.account.encode()+rb'(?!\d)', b'REDACTED', data)

    def clean(self, value):
        return json.loads(self.redact(encoded(value)))

    def restore(self, arn):
        return arn.replace(':REDACTED:', ':'+self.account+':')

    def write_json(self, path, value):
        atomic(path, self.redact(encoded(value)))

    def aws(self, op, _timeout=60, **kwargs):
        require(op in READS or op == 'schedule-run', 'operation is not allowlisted')
        command = ['aws', 'devicefarm', op, '--output', 'json', '--no-paginate',
                   '--region', os.environ['AWS_REGION']]
        for key, value in kwargs.items():
            command.extend(['--'+key.replace('_', '-'), json.dumps(value) if isinstance(value, (dict, list)) else str(value)])
        # In particular, never let SDK retry a mutation whose acceptance is unknown.
        env = dict(os.environ, AWS_PAGER='', AWS_CLI_AUTO_PROMPT='off', AWS_MAX_ATTEMPTS='1')
        try:
            result = subprocess.run(command, stdin=subprocess.DEVNULL, capture_output=True,
                                    timeout=_timeout, env=env)
        except (OSError, subprocess.TimeoutExpired) as error:
            raise Stop(op+' transport failure ('+type(error).__name__+')') from error
        if result.returncode:
            # stderr may contain signed URLs, credentials or private device IDs.
            raise Stop(op+' CLI failure (exit '+str(result.returncode)+'); response not retained')
        try:
            return json.loads(result.stdout)
        except ValueError as error:
            raise Stop(op+' returned invalid JSON') from error

    def listing(self, op, key, **kwargs):
        items, tokens = [], set()
        while True:
            response = self.aws(op, **kwargs)
            items.extend(response.get(key, []))
            token = response.get('nextToken')
            if not token:
                return items
            require(token not in tokens, 'repeated pagination token in '+op)
            tokens.add(token)
            kwargs['next_token'] = token

    def slots(self):
        result = []
        for s, i in ORDER:
            attempts = [a for a in self.state['attempts'] if a['set'] == s and a['run_index'] == i]
            valid = any(a['valid'] for a in attempts)
            status = 'completed' if valid else 'unresolved' if len(attempts) == 3 and attempts[-1]['phase']=='done' else 'pending'
            result.append(dict(slot=f'{i:02d}-{s}', set=s, run_index=i, status=status))
        return result

    def save(self, rewrite_attempts=False):
        self.state['updated_at'] = now()
        # Authoritative checkpoint FIRST; derived files can be regenerated on resume.
        self.write_json(self.out/'state.json', self.state)
        attempts = self.state['attempts']
        for attempt in attempts:
            directory = self.out/self.platform/(attempt['slot']+'-'+str(attempt['attempt']))
            for filename, value in (('attempt.json', attempt), ('parsed.json', attempt['parsed'])):
                path = directory/filename
                if rewrite_attempts or attempt is attempts[-1] or not path.exists():
                    self.write_json(path, value)
        slots = self.slots()
        failed = [s['slot'] for s in slots if s['status'] != 'completed']
        total = sum(a.get('device_minutes') or 0 for a in attempts)
        log = dict(schema_version=1, platform=self.platform, attempts=attempts, slots=slots,
                   total_device_minutes=total, minutes_unknown=sum(a.get('device_minutes') is None for a in attempts),
                   failed_slots=failed, stop_reason=self.state.get('stop_reason', ''),
                   started_at=self.state['started_at'], updated_at=self.state['updated_at'])
        self.write_json(self.out/'collection-log.json', log)
        build = {key: self.build[key] for key in ('core_revision', 'binding_revision', 'harness_revision', 'profile', 'slowdown_flag')}
        build['artifact_sha256'] = {s: self.artifact_hash for s in ('B1', 'B2', 'V')}
        cases = {case: dict(blocking_reason=None, sets={s: [] for s in ('B1', 'B2', 'V')}) for case in self.parser.CASES}
        for attempt in attempts:
            for case in cases:
                cases[case]['sets'][attempt['set']].append(attempt['parsed']['cases'][case])
        config = dict(id=self.platform+'-physical-v1', platform=self.platform, kind='physical', reference=None,
                      blocking_reason=('unresolved or unattempted slots: '+', '.join(failed)) if failed else None,
                      build=build, runtime=self.runtime, cases=cases)
        self.write_json(self.out/'raw-samples.json', dict(schema_version=1, synthetic=False, configurations=[config]))
        self.checksums()

    def checksums(self):
        lines = []
        for path in sorted(self.out.rglob('*')):
            if path.is_file() and path.name not in ('SHA256SUMS', '.lock') and not path.name.endswith('.tmp'):
                lines.append(digest(path.read_bytes())+'  '+path.relative_to(self.out).as_posix())
        atomic(self.out/'SHA256SUMS', ('\n'.join(lines)+'\n').encode())

    def parse(self, text, attempt, success=True):
        return self.parser.parse_run(text, self.build, set_name=attempt['set'],
                                     run_index=attempt['run_index'], attempt=attempt['attempt'],
                                     platform='physical', exit_code=0 if success else 1)

    def invalidate(self, parsed, reason):
        parsed['valid'], parsed['reason'] = False, reason
        for entry in parsed['cases'].values():
            entry.update(valid=False, reason=reason, value_ns=None)
        return parsed

    def preflight(self):
        projects = [p for p in self.listing('list-projects', 'projects') if p.get('name') == 'Minigraf']
        require(len(projects) == 1, 'expected exactly one project named Minigraf in AWS_REGION')
        self.project = projects[0]['arn']
        require(self.project.split(':')[4] == self.account, 'project account differs from uploads')
        kinds = ('IOS_APP', 'XCTEST_TEST_PACKAGE') if self.platform == 'ios' else ('ANDROID_APP', 'INSTRUMENTATION_TEST_PACKAGE')
        for arn, kind in zip((self.args.app_arn, self.args.test_package_arn), kinds):
            upload = self.aws('get-upload', arn=arn)['upload']
            require(upload.get('status') == 'SUCCEEDED' and upload.get('type') == kind,
                    'upload is not a successful '+kind)
        pool = self.aws('get-device-pool', arn=self.args.device_pool_arn)['devicePool']
        rules = pool.get('rules', [])
        singleton = [json.loads(r['value']) for r in rules if r.get('attribute') == 'ARN' and r.get('operator') == 'IN']
        require(len(singleton) == 1 and isinstance(singleton[0], list) and len(singleton[0]) == 1,
                'minute reservation requires a pool pinned with one ARN IN [device-arn] rule')
        device = self.aws('get-device', arn=singleton[0][0])['device']
        require(self.device_matches(device), 'device pool does not select pinned physical model/OS')
        public = dict(project_arn=self.project, device_pool_arn=self.args.device_pool_arn,
                      model=device['model'], os=device['os'], job_timeout_minutes=self.job_minutes)
        self.write_json(self.out/'preflight.json', public)

    def device_matches(self, device):
        model, version, manufacturer = (('Apple iPhone 15', '18.5', 'Apple') if self.platform == 'ios'
                                        else ('Google Pixel 7', '14', 'Google'))
        return (device.get('model') == model and device.get('os') == version
                and device.get('platform') == ('IOS' if self.platform == 'ios' else 'ANDROID')
                and ('manufacturer' not in device or device['manufacturer'] == manufacturer))

    def selected_tests(self, tests, attempt):
        selected_filter = filter_for(self.platform, attempt['set'])
        method = re.split(r'[/#]', selected_filter)[-1]
        return [test for test in tests if test.get('name') in
                (method, method+'()', selected_filter, selected_filter+'()')]

    def stream_artifact(self, artifact, selected_tests):
        # Aggregated run/job listings contain Setup/Test/Teardown artifacts with
        # identical names. The artifact ARN is <test resource path>/<artifact id>.
        arn = artifact.get('arn', '')
        if ':artifact:' not in arn or len(selected_tests) != 1:
            return False
        owner = arn.replace(':artifact:', ':test:', 1).rsplit('/', 1)[0]
        if owner != selected_tests[0]['arn']:
            return False
        return self.platform != 'android' or (
            artifact.get('type') == 'DEVICE_LOG' and artifact.get('name') == 'Logcat')

    def benchmark_text(self, text):
        if self.platform == 'android':
            # Device Farm Logcat uses threadtime: date time pid tid priority tag.
            return '\n'.join(match.group(1) for line in text.splitlines()
                             if (match := re.match(
                                 r'^\S+\s+\S+\s+\d+\s+\d+\s+I\s+MinigrafBench\s*:\s*(.*)$', line)))
        # iOS syslog octal-escapes backslashes in JSON (e.g. \134/).
        # Leave prefixes, unmarked JSON and ordinary JSON escapes untouched.
        lines = []
        for line in text.splitlines(keepends=True):
            prefix, marker, payload = line.partition('MinigrafBench:')
            if marker:
                payload = re.sub(r'\\([0-7]{3})', lambda m: chr(int(m.group(1), 8)), payload)
                line = prefix+marker+payload
            lines.append(line)
        text = ''.join(lines)
        if 'MinigrafBench:' in text:
            return '\n'.join(line for line in text.splitlines() if 'MinigrafBench:' in line)
        return text if re.search(r'"type"\s*:\s*"(environment|runtime|sample|checked|complete)"', text) else ''

    def recover_intent(self, attempt):
        matches = [r for r in self.listing('list-runs', 'runs', arn=self.project) if r.get('name') == attempt['name']]
        if len(matches) != 1:
            raise Stop('ambiguous schedule acceptance: found '+str(len(matches))+
                       ' runs for durable intent; resume later, never resubmit this intent')
        attempt['run_arn'] = self.clean(matches[0]['arn'])
        attempt['phase'] = 'active'
        self.save()

    def schedule(self, attempt):
        # intent was fsynced by caller. A crash before the next line intentionally
        # stops recovery if no run is found: no idempotency token is assumed.
        test = dict(type='XCTEST' if self.platform == 'ios' else 'INSTRUMENTATION',
                    testPackageArn=self.args.test_package_arn, filter=filter_for(self.platform, attempt['set']))
        try:
            response = self.aws('schedule-run', project_arn=self.project, app_arn=self.args.app_arn,
                                device_pool_arn=self.args.device_pool_arn, name=attempt['name'], test=test,
                                execution_configuration={'jobTimeoutMinutes': self.job_minutes})
            attempt['run_arn'] = self.clean(response['run']['arn'])
            attempt['phase'] = 'active'
            self.save()
        except (Stop, KeyError):
            self.recover_intent(attempt)

    def run_metadata(self, attempt, run):
        attempt['provider'] = {k: run.get(k) for k in ('status', 'result', 'created', 'started', 'stopped')}
        minutes = run.get('deviceMinutes', {}).get('total')
        if type(minutes) in (int, float) and math.isfinite(minutes) and minutes >= 0:
            attempt['device_minutes'] = minutes
        attempt['observed_at'] = now()

    def poll(self, attempt, reconcile=False):
        while True:
            remaining = self.args.run_timeout-(time.time()-attempt['submitted_epoch'])
            # Offline driver time is not evidence of a provider timeout. A
            # resumed attempt gets one bounded status reconciliation first.
            rechecking = reconcile or attempt.get('timed_out') or attempt['phase'] == 'artifacts'
            if remaining <= 0 and not rechecking:
                self.provider_timeout(attempt)
            try:
                run = self.aws('get-run', arn=self.restore(attempt['run_arn']),
                               _timeout=60 if rechecking else min(60, remaining))['run']
            except Stop:
                if not rechecking and time.time()-attempt['submitted_epoch'] >= self.args.run_timeout:
                    self.provider_timeout(attempt)
                raise
            reconcile = False
            self.run_metadata(attempt, run)
            if run.get('status') == 'COMPLETED':
                attempt['phase'] = 'artifacts'
                self.save()
                return run
            if attempt.get('timed_out') or time.time()-attempt['submitted_epoch'] >= self.args.run_timeout:
                self.provider_timeout(attempt)
            self.save()
            remaining = self.args.run_timeout-(time.time()-attempt['submitted_epoch'])
            time.sleep(min(self.args.poll_interval, max(0, remaining)))

    def provider_timeout(self, attempt):
        attempt['timed_out'] = True
        attempt['reason'] = 'no valid stream: provider timeout; awaiting COMPLETED before any retry'
        self.invalidate(attempt['parsed'], attempt['reason'])
        self.save()
        raise Stop(attempt['reason'])

    def artifact_payloads(self, data, label):
        # ZIP members are retained individually, never extracted via provider paths.
        # Keeping original compressed bytes would retain hidden account numbers.
        if data.startswith(b'PK\x03\x04'):
            with zipfile.ZipFile(io.BytesIO(data)) as archive:
                infos = [info for info in archive.infolist() if not info.is_dir()]
                require(sum(i.file_size for i in infos) <= LIMIT, 'expanded artifact exceeds size limit')
                require(len(infos) <= 4096, 'too many archive members')
                for index, info in enumerate(infos):
                    yield str(index)+'-'+Path(info.filename).name, archive.read(info)
        else:
            yield label, data

    def download(self, url):
        scheme = urllib.parse.urlsplit(url).scheme
        require(scheme == 'https' or (self.args.allow_file_urls and scheme == 'file'), 'artifact URL must be HTTPS')
        with urllib.request.urlopen(url, timeout=60) as response:
            require(urllib.parse.urlsplit(response.geturl()).scheme == scheme, 'artifact redirect changed URL scheme')
            data = response.read(LIMIT+1)
            if len(data) > LIMIT:
                try:
                    size = max(len(data), int(response.headers.get('Content-Length', '0')))
                except (TypeError, ValueError):
                    size = len(data)
                raise ArtifactTooLarge(size)
        return data

    def artifact_error(self, error):
        detail = type(error).__name__
        if isinstance(error, ValueError):
            # Exception messages can include signed URLs; retain diagnostics,
            # but never those URLs or account IDs in the manifest.
            message = re.sub(r'https?://[^\s\'"<>]+', '[REDACTED URL]', str(error))
            detail += ': '+self.redact(message.encode()).decode()
        return detail

    def collect_artifacts(self, attempt, run):
        directory = self.out/self.platform/(attempt['slot']+'-'+str(attempt['attempt']))
        directory.mkdir(parents=True, exist_ok=True)
        manifest = dict(run_arn=attempt['run_arn'], files=[], artifacts=[], errors=[])
        self.write_json(directory/'manifest.json', manifest)
        candidates, jobs, tests, suites = [], [], [], []
        reason = ''
        try:
            jobs = self.listing('list-jobs', 'jobs', arn=self.restore(attempt['run_arn']))
            resources = [self.restore(attempt['run_arn'])]
            for job in jobs:
                resources.append(job['arn'])
                job_suites = self.listing('list-suites', 'suites', arn=job['arn'])
                suites.extend(job_suites)
                for suite in job_suites:
                    resources.append(suite['arn'])
                    suite_tests = self.listing('list-tests', 'tests', arn=suite['arn'])
                    tests.extend(suite_tests)
                    resources.extend(t['arn'] for t in suite_tests)
            attempt['jobs'] = [dict(arn=j['arn'], result=j.get('result'), status=j.get('status'),
                                    device={k: j.get('device', {}).get(k) for k in ('model', 'os', 'platform')},
                                    device_minutes=j.get('deviceMinutes', {}).get('total'),
                                    timestamps={k: j.get(k) for k in ('created', 'started', 'stopped')}) for j in jobs]
            attempt['tests'] = [{k: t.get(k) for k in ('arn', 'name', 'result', 'started', 'stopped')} for t in tests]
            selected_tests = self.selected_tests(tests, attempt)
            if len(selected_tests) != 1:
                reason = 'no valid stream: expected exactly one selected benchmark test'
            seen = set()
            for resource in resources:
                for artifact_type in ('FILE', 'LOG', 'SCREENSHOT'):
                    artifacts = self.listing('list-artifacts', 'artifacts', arn=resource, type=artifact_type)
                    for artifact in artifacts:
                        key = artifact.get('arn') or artifact.get('url')
                        if key in seen:
                            continue
                        seen.add(key)
                        metadata = {k: artifact.get(k) for k in ('arn', 'name', 'type', 'extension')}
                        metadata['resource_arn'] = resource
                        metadata['stream_source'] = self.stream_artifact(artifact, selected_tests)
                        manifest['artifacts'].append(metadata)
                        try:
                            data = self.download(artifact['url'])
                            metadata['download_sha256'] = digest(data)
                            label = (artifact.get('name') or 'artifact')+'.'+(artifact.get('extension') or 'bin')
                            for member, payload in self.artifact_payloads(data, label):
                                filename = f'{len(manifest["files"]):04d}-'+re.sub(r'[^A-Za-z0-9._-]', '_', member)[:120]
                                filename = self.redact(filename.encode()).decode()
                                retained = self.redact(payload)
                                atomic(directory/filename, retained)
                                manifest['files'].append(dict(path=filename, sha256=digest(retained),
                                                              original_sha256=digest(payload), redacted=payload != retained,
                                                              artifact_arn=artifact.get('arn')))
                                if not metadata['stream_source']:
                                    continue
                                try:
                                    text = self.benchmark_text(payload.decode('utf-8-sig'))
                                except UnicodeError:
                                    continue
                                if text:
                                    parsed = self.parse(text, attempt)
                                    candidates.append((filename, parsed))
                        except (OSError, ValueError, KeyError, zipfile.BadZipFile) as error:
                            if isinstance(error, ArtifactTooLarge) and metadata['stream_source'] is False:
                                metadata.update(status='oversized_not_retained', size_bytes=error.size_bytes)
                            else:
                                manifest['errors'].append('artifact download/extraction failure: '+self.artifact_error(error))
                        self.write_json(directory/'manifest.json', manifest)
        except (Stop, ValueError, KeyError) as error:
            manifest['errors'].append('provider artifact enumeration failure: '+self.artifact_error(error))
        finally:
            self.write_json(directory/'manifest.json', manifest)

        parsed = self.evaluate_streams(attempt, candidates, manifest, run, jobs, tests, suites, reason)
        attempt.update(parsed=parsed, valid=parsed['valid'], reason=parsed['reason'],
                       phase='done', finished_at=now(), elapsed_seconds=time.time()-attempt['submitted_epoch'])
        self.save()

    def evaluate_streams(self, attempt, candidates, manifest, run, jobs, tests, suites,
                         reason='', offline=False):
        valid = [(name, p) for name, p in candidates if p['valid']]
        parsed = copy.deepcopy((valid or candidates)[0][1]) if candidates else self.parse('', attempt)
        if valid:
            attempt['observed_complete_stream'] = True
        if not offline and attempt.get('observed_complete_stream') and (manifest['errors'] or not valid):
            # Do not manufacture a no-valid-stream retry out of a download outage
            # after seeing a complete stream. Reconcile the SAME run on resume.
            reason = 'artifact retrieval incomplete after observing a complete stream; resume same run'
            if not valid and not reason:
                parsed = copy.deepcopy(attempt['parsed'])
            attempt.update(parsed=self.invalidate(parsed, reason), valid=False,
                           reason=reason, phase='artifacts')
            self.save()
            raise Stop(reason)
        if valid:
            records = parsed['records']
            # Identical mirrored exports are one stream, never concatenate them.
            # An incomplete prefix is allowed only as a redundant copy. Different
            # UUIDs, duplicated streams, suffixes, malformed records or mixed modes fail.
            for name, other in candidates:
                if other['records'] != records and not (
                    other['reason'] == 'no valid stream: missing, extra or duplicate records' and
                    0 < len(other['records']) < len(records) and other['records'] == records[:len(other['records'])]):
                    reason = 'no valid stream: conflicting/mixed artifact streams'
                    break
        if not valid:
            reason = parsed['reason']
        if manifest['errors']:
            reason = 'no valid stream: '+ '; '.join(manifest['errors'])
        if len(jobs) != 1 or not all(self.device_matches(j.get('device', {})) for j in jobs):
            reason = 'no valid stream: actual device model/OS differs from pinned single physical reference'
        if run.get('result') != 'PASSED' or not jobs or any(j.get('result') != 'PASSED' for j in jobs) or any(t.get('result') != 'PASSED' for t in tests+suites):
            reason = 'no valid stream: provider/job/test failure (including teardown)'
        if attempt.get('timed_out'):
            reason = 'no valid stream: provider timeout'
        if valid and not reason:
            runtime = parsed['runtime']
            expected_os = '18.5' if self.platform == 'ios' else '14'
            fields = ('os_build', 'machine', 'architecture') if self.platform == 'ios' else ('fingerprint', 'hardware', 'product', 'loaded_abi', 'sdk')
            if runtime.get('os') != expected_os or any(str(runtime.get(k)) != self.runtime[k] for k in fields):
                reason = 'no valid stream: runtime build/configuration differs from pinned inputs'
            run_id = parsed['environment']['run_id']
            if any(a is not attempt and (a.get('parsed', {}).get('environment') or {}).get('run_id') == run_id
                   for a in self.state['attempts']):
                reason = 'no valid stream: duplicate/stale process run identity'
            attempt['process_run_id'] = run_id
        if reason:
            self.invalidate(parsed, reason)
        return parsed

    def new_attempt(self, s, i, number):
        slot = f'{i:02d}-{s}'
        a = dict(slot=slot, set=s, run_index=i, attempt=number, phase='intent',
                 valid=False, reason='no valid stream: interrupted/pending provider attempt',
                 name='m858-'+self.state['collection_id']+'-'+slot+'-'+str(number),
                 run_arn=None, submitted_at=now(), submitted_epoch=time.time(), device_minutes=None)
        a['parsed'] = self.invalidate(self.parse('', a), a['reason'])
        self.state['attempts'].append(a)
        self.save()
        return a

    def execute(self):
        plan = dict(platform=self.platform, project_name='Minigraf', runtime=self.runtime,
                    slots=[dict(slot=f'{i:02d}-{s}', set=s, run_index=i,
                                filter=filter_for(self.platform, s)) for s, i in ORDER],
                    maximum_attempts=self.args.max_attempts, maximum_device_minutes=self.args.max_device_minutes,
                    job_timeout_minutes=self.job_minutes, retries_per_slot=2)
        if self.args.dry_run:
            print(self.redact(encoded(plan)).decode(), end='')
            return 0
        self.out.mkdir(parents=True, exist_ok=True)
        with (self.out/'.lock').open('a') as lock:
            try:
                fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError as error:
                raise Stop('another collector owns this output directory') from error
            path = self.out/'state.json'
            if self.args.resume:
                require(path.exists(), '--resume requires state.json')
                self.state = json.loads(path.read_text())
                require('rebuild' not in self.state or self.state['rebuild'].get('completed_at'),
                        'rebuild-state is incomplete; finish recovery before collect --resume')
                if self.state.get('input_fingerprint') != self.fingerprint:
                    old_parser = digest(encoded(dict(driver_sha256=ARTIFACT_RESUME_DRIVER_SHA256,
                                                      parser_sha256=self.identity['parser_sha256'])))
                    old_input = digest(encoded(dict(base_input_fingerprint=self.base_fingerprint,
                                                     parser_fingerprint=old_parser)))
                    pending_artifacts = any(a['phase'] == 'artifacts' and a.get('observed_complete_stream')
                                            for a in self.state['attempts'])
                    if self.state.get('input_fingerprint') == old_input and pending_artifacts:
                        # Authenticate every frozen input and the parser via the
                        # old fingerprint. Do not clear errors or finish attempts:
                        # their existing runs must pass fresh artifact retrieval.
                        self.state['input_fingerprint'] = self.fingerprint
                        self.state['inputs']['parser_fingerprint'] = self.identity['parser_fingerprint']
                        self.state['artifact_resume_migration'] = dict(previous_input_fingerprint=old_input,
                                                                       migrated_at=now())
                require(self.state.get('input_fingerprint') == self.fingerprint, 'resume inputs/parser differ from frozen state')
            else:
                require(not path.exists(), 'state already exists; use --resume')
                require(not any(p.name != '.lock' for p in self.out.iterdir()), 'output directory is not empty')
                self.state = dict(schema_version=1, input_fingerprint=self.fingerprint,
                                  base_input_fingerprint=self.base_fingerprint,
                                  inputs=self.clean(self.identity), collection_id=uuid.uuid4().hex,
                                  started_at=now(), attempts=[])
            self.state['stop_reason'] = ''
            self.save()
            self.write_json(self.out/'build.json', self.build)
            self.write_json(self.out/'runtime.json', self.runtime)
            atomic(self.out/'parse_samples.py', self.parser_path.read_bytes())
            try:
                self.preflight()
                for s, i in ORDER:
                    while True:
                        attempts = [a for a in self.state['attempts'] if a['set']==s and a['run_index']==i]
                        pending = next((a for a in reversed(attempts) if a['phase'] != 'done'), None)
                        # Reconcile already submitted extra attempts even when
                        # reparse satisfied this slot. Never schedule a new one.
                        if any(a['valid'] for a in attempts) and pending is None:
                            break
                        if pending:
                            attempt = pending
                            if attempt['phase'] == 'intent':
                                self.recover_intent(attempt)
                        else:
                            if len(attempts) >= 3:
                                break
                            all_attempts = self.state['attempts']
                            if len(all_attempts) >= self.args.max_attempts:
                                raise Stop('max-attempts cap reached')
                            if any(a['device_minutes'] is None for a in all_attempts):
                                raise Stop('device minutes unavailable; cannot admit another run within cap')
                            used = sum(a['device_minutes'] for a in all_attempts)
                            if used + self.job_minutes > self.args.max_device_minutes:
                                raise Stop('max-device-minutes cap: insufficient remaining minutes for next run reservation')
                            attempt = self.new_attempt(s, i, len(attempts)+1)
                            self.schedule(attempt)
                        run = self.poll(attempt, reconcile=pending is not None)
                        self.collect_artifacts(attempt, run)
                self.save()
            except (Stop, ValueError, KeyError, OSError) as error:
                self.state['stop_reason'] = str(error) if isinstance(error, (Stop, ValueError)) else type(error).__name__
                self.save()
                print(self.redact(self.state['stop_reason'].encode()).decode(), file=sys.stderr)
                return 2
            except KeyboardInterrupt:
                self.state['stop_reason'] = 'interrupted; resume reconciles existing attempt before scheduling'
                self.save()
                return 130
            return 0 if all(s['status']=='completed' for s in self.slots()) else 2


def reparse(out):
    """Re-evaluate retained evidence only; never construct a network collector."""
    out = out.resolve()
    with (out/'.lock').open('a') as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise Stop('another collector owns this output directory') from error
        collector = Collector.__new__(Collector)
        collector.out = out
        collector.state = state = json.loads((out/'state.json').read_text())
        inputs = state['inputs']
        collector.platform = inputs['platform']
        collector.build, collector.runtime = inputs['build'], inputs['runtime']
        collector.account = 'REDACTED'
        collector.parser_path = out/'parse_samples.py'
        require(digest(collector.parser_path.read_bytes()) == inputs['parser_sha256'],
                'retained qualification parser differs from frozen inputs')
        collector.parser = load_parser(collector.parser_path)
        key = 'physical' if collector.platform == 'ios' else 'arm64-v8a'
        collector.artifact_hash = collector.build['native_artifacts'][key]['sha256']
        old_fingerprint = inputs.get('parser_fingerprint', inputs['parser_sha256'])
        new_fingerprint = parser_fingerprint(collector.parser_path)
        timestamp = now()
        changes = []
        for attempt in state['attempts']:
            directory = out/collector.platform/(attempt['slot']+'-'+str(attempt['attempt']))
            old_reason, old_valid = attempt['reason'], attempt['valid']
            candidates = []
            try:
                manifest = json.loads((directory/'manifest.json').read_text())
                sources = {a['arn'] for a in manifest['artifacts'] if a.get('stream_source') is True}
                for item in manifest['files']:
                    path = (directory/item['path']).resolve()
                    require(path.is_relative_to(directory.resolve()), 'retained artifact escapes attempt directory')
                    if not path.is_file():
                        manifest['errors'].append('retained artifact missing: '+item['path'])
                        continue
                    if item.get('artifact_arn') not in sources:
                        continue
                    try:
                        text = collector.benchmark_text(path.read_bytes().decode('utf-8-sig'))
                    except UnicodeError:
                        continue
                    if text:
                        candidates.append((item['path'], collector.parse(text, attempt)))
            except (OSError, ValueError, KeyError) as error:
                manifest = dict(errors=['retained artifact read failure: '+type(error).__name__])
            tests = attempt.get('tests', [])
            reason = '' if len(collector.selected_tests(tests, attempt)) == 1 else (
                'no valid stream: expected exactly one selected benchmark test')
            parsed = collector.evaluate_streams(attempt, candidates, manifest,
                                                attempt.get('provider', {}), attempt.get('jobs', []),
                                                tests, attempt.get('suites', []), reason, offline=True)
            minutes = attempt.get('device_minutes')
            if type(minutes) not in (int, float) or not math.isfinite(minutes) or minutes < 0:
                collector.invalidate(parsed, 'no valid stream: device minutes unavailable')
            if attempt.get('provider', {}).get('status') != 'COMPLETED':
                collector.invalidate(parsed, 'no valid stream: interrupted/pending provider attempt')
            # These failures are independent of parsing. Some historically used
            # the "no valid stream" prefix too; that prefix alone is insufficient.
            nonparse = ('provider', 'actual device', 'artifact retrieval',
                        'artifact download/extraction', 'artifact enumeration',
                        'retained artifact', 'device minutes', 'process/teardown')
            if not old_valid and old_reason and (
                    not old_reason.startswith('no valid stream: ') or
                    any(part in old_reason for part in nonparse)):
                collector.invalidate(parsed, old_reason)
            attempt.update(parsed=parsed, valid=parsed['valid'], reason=parsed['reason'],
                           reparsed_at=timestamp)
            changes.append(dict(slot=attempt['slot'], attempt=attempt['attempt'],
                                reparsed_at=timestamp, old_reason=old_reason, new_reason=attempt['reason'],
                                old_valid=old_valid, new_valid=attempt['valid'],
                                old_parser_fingerprint=old_fingerprint,
                                new_parser_fingerprint=new_fingerprint))
        state.setdefault('reparse_log', []).extend(changes)
        inputs['parser_fingerprint'] = new_fingerprint
        # This is the only migration path for an existing frozen fingerprint.
        base = state.setdefault('base_input_fingerprint', state['input_fingerprint'])
        state['input_fingerprint'] = digest(encoded(dict(base_input_fingerprint=base,
                                                        parser_fingerprint=new_fingerprint)))
        state['reparsed_at'] = timestamp
        collector.save(rewrite_attempts=True)
        for change in changes:
            print(f"{change['slot']}-{change['attempt']}: "
                  f"{change['old_reason'] or 'valid'} -> {change['new_reason'] or 'valid'}")
        print('Satisfied slots: '+', '.join(s['slot'] for s in collector.slots() if s['status'] == 'completed'))
        return 0


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    collect = sub.add_parser('collect')
    collect.add_argument('--platform', required=True, choices=('ios', 'android'))
    for name in ('app-arn', 'test-package-arn', 'device-pool-arn', 'core-revision'):
        collect.add_argument('--'+name, required=True)
    for name in ('build-json', 'runtime-json', 'out'):
        collect.add_argument('--'+name, required=True, type=Path)
    collect.add_argument('--parser', type=Path, help='existing platform qualification/parse_samples.py')
    for s in ('b1', 'b2', 'v'):
        collect.add_argument('--filter-'+s, help='optional explicit pinned harness filter')
    collect.add_argument('--poll-interval', type=float, default=30)
    collect.add_argument('--run-timeout', type=float, default=1800, help='seconds from durable scheduling intent')
    collect.add_argument('--max-attempts', type=int, default=54)
    collect.add_argument('--max-device-minutes', type=float, default=600)
    collect.add_argument('--resume', action='store_true')
    collect.add_argument('--dry-run', action='store_true')
    collect.add_argument('--allow-file-urls', action='store_true', help='offline fixtures only; permit local file artifacts')
    rebuild = sub.add_parser('rebuild-state', help='read-only recovery of existing Device Farm runs')
    for action in collect._actions:
        if action.dest in ('help', 'resume', 'dry_run', 'allow_file_urls'):
            continue
        action = copy.copy(action)
        if action.dest in ('app_arn', 'test_package_arn', 'device_pool_arn'):
            action.required = False
        rebuild._add_action(action)
    rebuild.set_defaults(resume=False, dry_run=False, allow_file_urls=False)
    rebuild.add_argument('--collection-id', required=True)
    rebuild.add_argument('--project-arn', required=True)
    for name in ('app-name', 'test-package-name', 'pool-name'):
        rebuild.add_argument('--'+name)
    rebuild.add_argument('--superseded-attempt', action='append', default=[],
                         help='explicit historical artifacts-phase attempt, e.g. 02-B1-2')
    summary = sub.add_parser('summary')
    summary.add_argument('--out', type=Path, required=True)
    offline = sub.add_parser('reparse', help='re-evaluate retained artifacts without network access')
    offline.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    try:
        if args.command == 'rebuild-state':
            from rebuild_state import rebuild
            return rebuild(args)
        if args.command == 'reparse':
            return reparse(args.out)
        if args.command == 'summary':
            state = json.loads((args.out/'state.json').read_text())
            attempts = state['attempts']
            failed = [f'{i:02d}-{s}' for s, i in ORDER if not any(a['valid'] and a['set']==s and a['run_index']==i for a in attempts)]
            print(json.dumps(dict(total_device_minutes=sum(a.get('device_minutes') or 0 for a in attempts),
                                  minutes_unknown=sum(a.get('device_minutes') is None for a in attempts),
                                  failed_slots=failed, stop_reason=state.get('stop_reason', '')), indent=2))
            return 0
        return Collector(args).execute()
    except (ValueError, OSError, KeyError, Stop) as error:
        # Do not print user paths, raw responses or ARN-bearing exceptions here.
        message = str(error) if isinstance(error, (ValueError, Stop)) else type(error).__name__
        message = re.sub(r'\b\d{12}\b', 'REDACTED', message)
        print('collection refused: '+message, file=sys.stderr)
        return 2


if __name__ == '__main__':
    sys.modules.setdefault('df_collect', sys.modules[__name__])
    raise SystemExit(main())

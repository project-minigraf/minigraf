"""Offline integration tests. The only 'aws' used is the executable created here."""
import copy
import contextlib
import importlib.util
import io
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import tempfile
import time
from types import SimpleNamespace
import unittest
import zipfile

if '--fake-aws' not in sys.argv:
    from unittest.mock import Mock, patch
    import df_collect as driver
    from df_collect import Collector, filter_for

ROOT = Path(__file__).resolve().parent
BASE = Path('<local-path>')
ACCOUNT = '123456789012'
ARN = 'arn:aws:devicefarm:us-west-2:' + ACCOUNT + ':'
sys.dont_write_bytecode = True
SAMPLES = ROOT/'fixtures'/'devicefarm'


def real_sample(name, directory=SAMPLES):
    # The supplied redaction replaced a numeric memory value with bare ACCT.
    text = (directory/name).read_text()
    return json.loads(re.sub(r'("memory"\s*:\s*)ACCT\b', r'\g<1>0', text))


class DeviceResponseTests(unittest.TestCase):
    def test_ios_process_name_without_benchmark_marker_is_not_a_stream(self):
        collector = Collector.__new__(Collector)
        collector.platform = 'ios'
        message = json.dumps([dict(type='Message', data='Sandbox: MinigrafBenchmark(608) deny(1)')])
        self.assertEqual(collector.benchmark_text(message), '')
        self.assertEqual(collector.benchmark_text(message+'\nMinigrafBench: {"type":"sample"}'),
                         'MinigrafBench: {"type":"sample"}')

    def test_ios_octal_unescape_is_limited_to_marker_payload(self):
        collector = Collector.__new__(Collector)
        collector.platform = 'ios'
        raw = r'prefix\134 MinigrafBench: {"id":"binding\134/swift-ios\134/prepared_execute\134/1k"}'
        self.assertEqual(collector.benchmark_text(raw),
                         r'prefix\134 MinigrafBench: {"id":"binding\/swift-ios\/prepared_execute\/1k"}')
        untouched = r'MinigrafBench: \12 \888 \u1234'
        self.assertEqual(collector.benchmark_text(untouched), untouched)
        plain = r'{"type":"sample","id":"\134"}'+'\n'
        self.assertEqual(collector.benchmark_text(plain), plain)
        collector.platform = 'android'
        self.assertEqual(collector.benchmark_text('11-19 10:48:38.433 1 2 I '+raw.split(' ', 1)[1]),
                         raw.split('MinigrafBench: ', 1)[1])

    def test_every_captured_response_through_driver_helpers(self):
        collector = Collector.__new__(Collector)
        collector.platform = 'android'
        originals = Path('/tmp/858-rebuild/tools-real')
        directory = originals if originals.is_dir() else SAMPLES
        loaded = {}
        for path in sorted(directory.glob('*.json')):
            with self.subTest(sample=path.name):
                response = real_sample(path.name, directory)
                retained = copy.deepcopy(response)
                if 'run' in retained:
                    retained['run']['parsingResultUrl'] = 'URL'
                self.assertEqual(real_sample(path.name), retained)
                loaded[path.name] = response
                if 'run' in response:
                    attempt = dict(submitted_epoch=time.time(), phase='active', run_arn='redacted')
                    collector.args = SimpleNamespace(run_timeout=60)
                    collector.aws = Mock(return_value=response)
                    collector.save = Mock()
                    collector.restore = lambda arn: arn
                    self.assertEqual(collector.poll(attempt), response['run'])
                    self.assertEqual(attempt['phase'], 'artifacts')
                    self.assertEqual(attempt['provider']['result'], 'PASSED')
                    self.assertEqual(attempt['device_minutes'], response['run']['deviceMinutes']['total'])
                    self.assertNotEqual(attempt['device_minutes'], response['run']['deviceMinutes']['metered'])
                elif 'device' in response:
                    self.assertTrue(collector.device_matches(response['device']))
                else:
                    key = next(iter(response))
                    collector.aws = Mock(return_value=response)
                    items = collector.listing('list-'+key, key, arn='redacted')
                    self.assertEqual(items, response[key])
                    if key == 'jobs':
                        self.assertTrue(collector.device_matches(items[0]['device']))
                        self.assertEqual(items[0]['counters']['total'], 3)
        self.assertEqual(set(loaded), {p.name for p in SAMPLES.glob('*.json')})
        self.assertEqual(len(loaded), 6)
        suites = loaded['list-suites.json']['suites']
        self.assertEqual([s['name'] for s in suites[::2]], ['Setup Suite', 'Teardown Suite'])
        # Test responses were not captured; derive their resource paths from the
        # observed suites/artifacts and exercise method-only name selection.
        tests = [dict(arn=s['arn'].replace(':suite:', ':test:')+'/00000', name=name)
                 for s, name in zip(suites, ('Setup Test', 'testQualificationBaseline', 'Teardown Test'))]
        selected = collector.selected_tests(tests, {'set': 'B1'})
        self.assertEqual(selected, [tests[1]])
        artifacts = loaded['list-artifacts-job.json']['artifacts']
        candidates = [a for a in artifacts if collector.stream_artifact(a, selected)]
        self.assertEqual([a['arn'] for a in candidates], [artifacts[3]['arn']])
        self.assertEqual(candidates[0]['extension'], 'logcat')
        self.assertFalse(collector.stream_artifact(candidates[0], selected*2))
        self.assertEqual(list(collector.artifact_payloads(b'log', 'Logcat.logcat')),
                         [('Logcat.logcat', b'log')])

    def test_real_android_logcat_is_parsed_as_tagged_json(self):
        collector = Collector.__new__(Collector)
        collector.platform = 'android'
        collector.build, _, _ = fixture('android')
        spec = importlib.util.spec_from_file_location('real_log_parser', parser_path('android'))
        collector.parser = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(collector.parser)
        source = Path('/tmp/smk-and2/io.github.proj_verifyAndMeasu_Logcat.logcat')
        if not source.exists():
            source = SAMPLES/'android-smoke.logcat'
        raw = source.read_text()
        expected = [json.loads(line.split(' I MinigrafBench: ', 1)[1])
                    for line in raw.splitlines() if ' I MinigrafBench: ' in line]
        self.assertGreater(len(expected), 0)
        text = collector.benchmark_text(raw)
        self.assertEqual([json.loads(line) for line in text.splitlines()], expected)
        parsed = collector.parse(text, dict(set='B1', run_index=1, attempt=1))
        self.assertEqual(parsed['records'], expected)
        # This is a smoke run, not a full 157-record qualification run.
        self.assertFalse(parsed['valid'])
        self.assertEqual(collector.benchmark_text('OtherTag: MinigrafBench: {}\n{"type":"sample"}'), '')

    def test_exact_provider_device_identity(self):
        collector = Collector.__new__(Collector)
        for platform, model, manufacturer, version in (
                ('android', 'Google Pixel 7', 'Google', '14'),
                ('ios', 'Apple iPhone 15', 'Apple', '18.5')):
            collector.platform = platform
            device = real_sample('get-device-android.json')['device']
            device.update(model=model, manufacturer=manufacturer,
                          platform=platform.upper(), os=version)
            with self.subTest(platform=platform):
                self.assertTrue(collector.device_matches(device))
                without_manufacturer = dict(device)
                del without_manufacturer['manufacturer']
                self.assertTrue(collector.device_matches(without_manufacturer))
                for field, value in (('model', model.split(' ', 1)[1]),
                                     ('os', version+'.0'), ('platform', platform),
                                     ('manufacturer', 'Other'), ('manufacturer', None)):
                    with self.subTest(field=field, value=value):
                        self.assertFalse(collector.device_matches(dict(device, **{field: value})))


def parser_path(platform):
    repo = 'minigraf-swift' if platform == 'ios' else 'minigraf-android'
    return BASE / repo / '.worktrees/858-qualification/bench/device-farm/qualification/parse_samples.py'


def fixture(platform):
    spec = importlib.util.spec_from_file_location('fixture_parser', parser_path(platform))
    parser = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(parser)
    build = dict(core_revision='a'*40, binding_revision='b'*40, harness_revision='b'*40,
                 harness_sha256='c'*64, profile='Release',
                 slowdown_flag='repeat-timed-operation-twice')
    if platform == 'ios':
        build['native_artifacts'] = {'physical': {'sha256': 'd'*64, 'architecture': 'arm64'}}
        runtime = dict(type='runtime', platform='physical', machine='iPhone15,4', os='18.5',
                       os_build='22F76', architecture='arm64', compiled_simulator=False)
        identity = {key: build[key] for key in parser.IDENTITY}
        identity['native_sha256'] = 'd'*64
        env = dict(model='iPhone15,4', os='18.5', build=identity)
        pins = dict(provider='Device Farm', model='iPhone 15', os='iOS 18.5',
                    os_build='22F76', machine='iPhone15,4', architecture='arm64')
    else:
        build['native_artifacts'] = {'arm64-v8a': {'sha256': 'd'*64}}
        runtime = dict(type='runtime', platform='physical', model='Pixel 7', os='14', sdk=34,
                       fingerprint='google/panther/panther:14/UP1A/test:user/release-keys',
                       hardware='panther', product='panther', ro_kernel_qemu='', ro_boot_qemu='',
                       abis=['arm64-v8a'], loaded_abi='arm64-v8a', native_sha256='d'*64,
                       native_identity='proc-maps-extracted-elf')
        env = {key: value for key, value in runtime.items() if key not in ('type', 'platform')}
        env['build'] = build
        pins = dict(provider='Device Farm', model='Pixel 7', os='Android 14',
                    fingerprint=runtime['fingerprint'], hardware='panther', product='panther',
                    loaded_abi='arm64-v8a', sdk='34')
    env.update(type='environment', mode='qualification', variant='baseline', platform='physical',
               run_id='fixture', profile='Release', double_work=False)
    records = [env, runtime]
    for case in parser.CASES:
        n = 1 if case in ('file_transact/1k', 'log_writer_append_finish/1k') else 20
        for i in range(10):
            records.append(dict(type='sample', id=parser.PREFIX+case, sample=i,
                                iterations=n, total_ns=(i+1)*n, ns_per_op=i+1))
        records.append(dict(type='checked', id=parser.PREFIX+case))
    records.append(dict(type='complete', mode='qualification', variant='baseline',
                        platform='physical', run_id='fixture', count=14,
                        ids=[parser.PREFIX+c for c in parser.CASES]))
    return build, pins, records


def fake_aws():
    root = Path(os.environ['FAKE_ROOT'])
    config = json.loads((root/'fake-config.json').read_text())
    path = root/'provider.json'
    state = json.loads(path.read_text()) if path.exists() else {'runs': [], 'calls': []}
    args = sys.argv[2:]
    assert args[0] == 'devicefarm'
    op = args[1]
    state['calls'].append(args)

    def opt(name, default=None):
        return args[args.index('--'+name)+1] if '--'+name in args else default

    def save():
        path.write_text(json.dumps(state))

    def crash(stage):
        if config.get('crash') == stage and not state.get('crashed'):
            state['crashed'] = True
            save()
            os.kill(os.getppid(), signal.SIGKILL)
            sys.exit(0)

    device = real_sample('get-device-android.json')['device']
    if config['platform'] == 'ios':
        device.update(model='Apple iPhone 15', name='Apple iPhone 15',
                      manufacturer='Apple', os='18.5', platform='IOS')

    def response_sample(name, run=None):
        value = json.dumps(real_sample(name)).replace('ACCT', ACCOUNT)
        if run:
            original = real_sample('get-run-android-smoke.json')['run']['arn'].split(':run:')[1]
            value = value.replace(original, run['arn'].split(':run:')[1])
        return json.loads(value)

    def public_run(run):
        return {k: v for k, v in run.items() if k not in ('behavior', 'test')}

    if op == 'list-projects':
        result = {'projects': [{'name': 'Minigraf', 'arn': ARN+'project:p'}]}
    elif op == 'get-upload':
        kind = ('IOS_APP' if config['platform']=='ios' else 'ANDROID_APP') if opt('arn').endswith(':app') else (
            'XCTEST_TEST_PACKAGE' if config['platform']=='ios' else 'INSTRUMENTATION_TEST_PACKAGE')
        kind = config.get('upload_types', {}).get(opt('arn').rsplit(':', 1)[-1], kind)
        result = {'upload': {'arn': opt('arn'), 'status': 'SUCCEEDED', 'type': kind}}
    elif op == 'get-device-pool':
        result = {'devicePool': {'rules': [{'attribute': 'ARN', 'operator': 'IN',
                                           'value': json.dumps([device['arn']])}]}}
    elif op == 'get-device':
        result = {'device': device}
    elif op == 'schedule-run':
        crash('before-schedule')
        idx = len(state['runs'])
        behavior = config.get('behaviors', [])[idx] if idx < len(config.get('behaviors', [])) else 'valid'
        run = response_sample('get-run-'+config['platform']+'-smoke.json')['run']
        run.update(arn=ARN+'run:p/r'+str(idx), name=opt('name'),
                   result='ERRORED' if behavior == 'failure' else 'PASSED',
                   deviceMinutes=dict(total=1.0, metered=0.5, unmetered=0.0),
                   behavior=behavior, test=json.loads(opt('test')))
        state['runs'].append(run)
        save()
        crash('schedule')
        scheduled = public_run(run)
        scheduled.update(status='SCHEDULING', result='PENDING')
        result = {'run': scheduled}
    elif op == 'list-runs':
        result = {'runs': [public_run(r) for r in state['runs']]}
    else:
        idx = int(re.search(r'/r(\d+)(?:/|$)', opt('arn')).group(1))
        run = copy.deepcopy(state['runs'][idx])
        behavior = run['behavior']
        if op == 'get-run':
            if config.get('stall_get_run'):
                time.sleep(2)
            crash('poll')
            if behavior == 'timeout' and not config.get('complete_timeout'):
                run['status'] = 'RUNNING'
            result = {'run': public_run(run)}
        elif op == 'list-jobs':
            if behavior == 'wrong-device':
                device['model'] = 'Wrong device'
            if behavior == 'wrong-os':
                device['os'] = '99'
            result = response_sample('list-jobs-android-smoke.json', run)
            result['jobs'][0].update(result=run['result'], device=device,
                                     name=device['name'], deviceMinutes=run['deviceMinutes'])
        elif op == 'list-suites':
            result = response_sample('list-suites.json', run)
            if config['platform'] == 'ios':
                result['suites'][1]['name'] = 'BenchmarkTests'
            for suite in result['suites']:
                suite['result'] = run['result']
        elif op == 'list-tests':
            index = int(opt('arn').rsplit('/', 1)[1])
            # No captured list-tests response was supplied: reuse suite lifecycle
            # fields, with a test resource ARN and method-only name.
            test = response_sample('list-suites.json', run)['suites'][index]
            test.update(arn=opt('arn').replace(':suite:', ':test:')+'/00000',
                        name=('Setup Test', re.split(r'[/#]', run['test']['filter'])[-1],
                              'Teardown Test')[index], result=run['result'],
                        type=run['test']['type'])
            if config.get('wrong_test') and index == 1:
                test['name'] = 'testQualificationOther'
            result = {'tests': [test]}
        elif op == 'list-artifacts':
            artifacts = response_sample('list-artifacts-job.json', run)['artifacts']
            if config.get('mirrored_logcat'):
                mirror = dict(artifacts[3])
                mirror['arn'] = mirror['arn'].rsplit('/', 1)[0]+'/00006'
                artifacts.append(mirror)
            records = copy.deepcopy(config['records'])
            variant = 'slowdown' if 'Slowdown' in run['test']['filter'] else 'baseline'
            for rec in (records[0], records[-1]):
                rec.update(variant=variant, run_id='run-'+str(idx))
            records[0]['double_work'] = variant == 'slowdown'
            if behavior == 'truncated':
                records.pop()
            if behavior == 'build-drift':
                records[0]['build']['core_revision'] = 'f'*40
            if behavior == 'duplicate':
                records *= 2
            if behavior == 'stale':
                records[0]['run_id'] = records[-1]['run_id'] = 'run-0'
            result = {'artifacts': []}
            for artifact in artifacts:
                resource_path = opt('arn').split(':', 5)[5].split(':', 1)[1]
                artifact_path = artifact['arn'].split(':artifact:')[1]
                if not artifact_path.startswith(resource_path+'/'):
                    continue
                category = 'LOG' if artifact['type'] in ('DEVICE_LOG', 'INSTRUMENTATION_OUTPUT') else 'FILE'
                if opt('type') != category:
                    continue
                suite_index = int(artifact_path.split('/')[3])
                stream = ''
                if artifact['type'] == 'DEVICE_LOG':
                    is_selected = suite_index == 1
                    if (is_selected and not config.get('no_selected_stream')) or (
                            not is_selected and config.get('lifecycle_streams')):
                        emitted = copy.deepcopy(records)
                        if not is_selected:
                            emitted[0]['run_id'] = emitted[-1]['run_id'] = 'lifecycle-'+str(suite_index)
                        prefix = '11-19 10:48:38.433 28602 28628 I ' if config['platform'] == 'android' else ''
                        stream = '\n'.join(prefix+'MinigrafBench: '+json.dumps(r) for r in emitted)
                    if config['platform'] == 'ios':
                        artifact.update(name='Test Output', type='TEST_LOG', extension='txt')
                elif artifact['type'] == 'INSTRUMENTATION_OUTPUT' and config.get('instrumentation_stream'):
                    stream = 'MinigrafBench: {"type":"environment","run_id":"wrong-source"}'
                raw = root/('artifact-'+str(idx)+'-'+artifact_path.replace('/', '-')+'.log')
                raw.write_text('provider '+run['arn']+'\n'+stream)
                if config.get('zip') and artifact['type'] == 'DEVICE_LOG':
                    archive = raw.with_suffix('.zip')
                    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
                        z.writestr('../../unsafe/'+ACCOUNT+'/logcat.log', raw.read_bytes())
                    raw = archive
                artifact['url'] = raw.as_uri()
                result['artifacts'].append(artifact)
            if opt('type') == 'SCREENSHOT' and config.get('missing_screenshot'):
                result['artifacts'].append(dict(arn=run['arn'].replace(':run:', ':artifact:')+'/00000/00001/00000/00099',
                                                name='Screenshot', extension='png', type='SCREENSHOT',
                                                url=(root/'not-yet-available.png').as_uri()))
        else:
            raise AssertionError('Forbidden/unimplemented call: '+op)
    if config.get('paginate') and op.startswith('list-') and not opt('next-token'):
        key = next(iter(result))
        result = {key: [], 'nextToken': 'second-page'}
    save()
    print(json.dumps(result))


class ReparseTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix='reparse-test-', dir=ROOT)
        self.addCleanup(self.tmp.cleanup)
        self.out = Path(self.tmp.name)
        build, runtime, self.records = fixture('ios')
        self.args = SimpleNamespace(out=self.out, platform='ios', build_json=self.out/'build.json',
                                    runtime_json=self.out/'runtime.json', parser=parser_path('ios'),
                                    app_arn=ARN+'upload:app', test_package_arn=ARN+'upload:tests',
                                    device_pool_arn=ARN+'devicepool:p', core_revision='a'*40,
                                    max_attempts=54, max_device_minutes=600, run_timeout=1800,
                                    poll_interval=0, filter_b1=None, filter_b2=None, filter_v=None,
                                    resume=True, dry_run=False)
        self.args.build_json.write_text(json.dumps(build))
        self.args.runtime_json.write_text(json.dumps(runtime))
        self.environment = patch.dict(os.environ, AWS_PROFILE='offline', AWS_REGION='us-west-2')
        self.environment.start()
        self.addCleanup(self.environment.stop)
        self.collector = Collector(self.args)
        (self.out/'parse_samples.py').write_bytes(parser_path('ios').read_bytes())
        self.state = dict(schema_version=1, inputs=self.collector.clean(self.collector.identity),
                          input_fingerprint=driver.digest(driver.encoded({
                              k: v for k, v in self.collector.identity.items() if k != 'parser_fingerprint'})),
                          collection_id='offline',
                          started_at=driver.now(), attempts=[])
        self.state['inputs'].pop('parser_fingerprint', None)

    def attempt(self, number=1, reason='no valid stream: conflicting/mixed artifact streams',
                phase='done', run_index=1, stream='mirror'):
        a = dict(slot=f'{run_index:02d}-B1', set='B1', run_index=run_index, attempt=number,
                 reason=reason, valid=False, phase=phase, run_arn=ARN+f'run:p/r{run_index}-{number}',
                 submitted_epoch=time.time(), device_minutes=1.25,
                 provider=dict(status='COMPLETED', result='PASSED'),
                 jobs=[dict(result='PASSED', device=dict(model='Apple iPhone 15', os='18.5', platform='IOS'))],
                 tests=[dict(name='testQualificationBaseline', result='PASSED')])
        records = copy.deepcopy(self.records)
        for rec in (records[0], records[-1]):
            rec['run_id'] = f'run-{run_index}-{number}'
        plain = '\n'.join('MinigrafBench: '+json.dumps(r).replace('/', r'\/') for r in records)
        syslog = plain.replace('\\', r'\134')
        if stream == 'conflict':
            syslog = syslog.replace('"total_ns": 20', '"total_ns": 21', 1)
        elif stream == 'prefix':
            syslog = '\n'.join(syslog.splitlines()[:20])
        a['parsed'] = self.collector.invalidate(self.collector.parse(plain, a), reason)
        self.state['attempts'].append(a)
        directory = self.out/'ios'/(a['slot']+'-'+str(number))
        directory.mkdir(parents=True)
        manifest = dict(errors=[], artifacts=[], files=[])
        for name, text, source in [('automation.txt', plain, True), ('syslog.syslog', syslog, True),
                                   ('messages.json', '[{"type":"Message","data":"MinigrafBenchmark(608)"}]', True),
                                   ('setup.syslog', plain.replace('"sample": 0', '"sample": 99'), False)]:
            (directory/name).write_text(text)
            manifest['artifacts'].append(dict(arn=name, stream_source=source))
            manifest['files'].append(dict(path=name, artifact_arn=name, sha256=driver.digest(text.encode())))
        (directory/'manifest.json').write_text(json.dumps(manifest))
        (directory/'parsed.json').write_text(json.dumps(a['parsed']))
        (directory/'attempt.json').write_text(json.dumps(a))
        return a

    def reparse(self):
        (self.out/'state.json').write_text(json.dumps(self.state))
        with patch.object(sys, 'argv', ['df_collect.py', 'reparse', '--out', str(self.out)]), \
                patch.object(Collector, 'aws', side_effect=AssertionError('network forbidden')), \
                patch.object(Collector, 'download', side_effect=AssertionError('download forbidden')), \
                contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
            try:
                result = driver.main()
            except SystemExit as error:
                result = error.code
        self.assertEqual(result, 0, 'offline reparse must succeed')
        self.state = json.loads((self.out/'state.json').read_text())

    def test_reparse_mirrors_prefixes_extra_attempts_and_audit(self):
        self.attempt(1)
        self.attempt(2, stream='prefix')
        self.attempt(3, stream='conflict')
        original = copy.deepcopy(self.state)
        self.reparse()
        self.assertEqual([a['valid'] for a in self.state['attempts']], [True, True, False])
        self.assertEqual(len(self.state['attempts']), 3)
        self.assertEqual(self.state['attempts'][2]['reason'], original['attempts'][2]['reason'])
        self.assertNotEqual(self.state['input_fingerprint'], original['input_fingerprint'])
        self.assertEqual(self.state['input_fingerprint'], Collector(self.args).fingerprint)
        for old, new, entry in zip(original['attempts'], self.state['attempts'], self.state['reparse_log']):
            self.assertEqual(entry['old_reason'], old['reason'])
            self.assertEqual(entry['new_reason'], new['reason'])
            self.assertTrue(entry['reparsed_at'])
            self.assertNotEqual(entry['old_parser_fingerprint'], entry['new_parser_fingerprint'])
            self.assertEqual(new['device_minutes'], old['device_minutes'])
            directory = self.out/'ios'/(new['slot']+'-'+str(new['attempt']))
            self.assertEqual(json.loads((directory/'parsed.json').read_text()), new['parsed'])
            self.assertEqual(json.loads((directory/'attempt.json').read_text()), new)
        log = json.loads((self.out/'collection-log.json').read_text())
        self.assertEqual(log['slots'][0]['status'], 'completed')
        self.assertEqual(log['total_device_minutes'], 3.75)
        self.reparse()
        self.assertEqual(len(self.state['reparse_log']), 6)
        self.assertEqual(self.state['reparse_log'][-1]['old_parser_fingerprint'],
                         self.state['reparse_log'][-1]['new_parser_fingerprint'])

    def test_reparse_preserves_nonparse_failures(self):
        reasons = ['no valid stream: provider/job/test failure (including teardown)',
                   'no valid stream: actual device model/OS differs from pinned single physical reference',
                   'no valid stream: provider timeout',
                   'artifact retrieval incomplete after observing a complete stream; resume same run',
                   'no valid stream: artifact download/extraction failure: OSError']
        for i, reason in enumerate(reasons, 1):
            self.attempt(reason=reason, run_index=i, phase='artifacts' if i == 4 else 'done')
        self.reparse()
        self.assertEqual([a['reason'] for a in self.state['attempts']], reasons)
        self.assertTrue(all(not a['valid'] for a in self.state['attempts']))
        self.assertEqual(self.state['attempts'][3]['phase'], 'artifacts')

    def test_reparse_checks_stored_metadata_and_missing_files(self):
        self.attempt(run_index=1)['jobs'][0]['result'] = 'FAILED'
        self.attempt(run_index=2)['tests'][0]['result'] = 'FAILED'
        self.attempt(run_index=3)['jobs'][0]['device']['os'] = '99'
        self.attempt(run_index=4)['timed_out'] = True
        self.attempt(run_index=5)['device_minutes'] = None
        self.attempt(run_index=6)
        (self.out/'ios/06-B1-1/syslog.syslog').unlink()
        self.reparse()
        self.assertTrue(all(not a['valid'] for a in self.state['attempts']))
        for a, keyword in zip(self.state['attempts'], ['provider', 'provider', 'device', 'timeout', 'minutes', 'artifact']):
            self.assertIn(keyword, a['reason'])

    def test_resume_cannot_migrate_fingerprint_without_reparse(self):
        self.attempt()
        path = self.out/'state.json'
        path.write_text(json.dumps(self.state))
        before = path.read_bytes()
        with patch.object(self.collector, 'aws', side_effect=AssertionError('network forbidden')):
            with self.assertRaisesRegex(ValueError, 'inputs/parser differ'):
                self.collector.execute()
        self.assertEqual(path.read_bytes(), before)

    def test_reparse_keeps_account_bound_resume_fingerprint(self):
        self.attempt()
        self.reparse()
        self.assertEqual(self.state['input_fingerprint'], Collector(self.args).fingerprint)
        for field in ('app_arn', 'test_package_arn', 'device_pool_arn'):
            setattr(self.args, field, getattr(self.args, field).replace(ACCOUNT, '999999999999'))
        self.assertNotEqual(self.state['input_fingerprint'], Collector(self.args).fingerprint)

    def test_resume_reconciles_pending_extra_run_of_satisfied_slot(self):
        first = self.attempt(1)
        first.update(valid=True, reason='')
        pending = self.attempt(2, phase='artifacts',
                               reason='artifact retrieval incomplete after observing a complete stream; resume same run')
        self.state['input_fingerprint'] = self.collector.fingerprint
        (self.out/'state.json').write_text(json.dumps(self.state))
        self.args.max_attempts = 2
        def finish(a, run):
            self.assertEqual(a['run_arn'], pending['run_arn'])
            a.update(phase='done', valid=True, reason='')
        with patch.object(self.collector, 'preflight'), \
                patch.object(self.collector, 'schedule', side_effect=AssertionError('must not schedule')), \
                patch.object(self.collector, 'poll', return_value=pending['provider']) as poll, \
                patch.object(self.collector, 'collect_artifacts', side_effect=finish) as fetch, \
                contextlib.redirect_stderr(io.StringIO()):
            self.assertEqual(self.collector.execute(), 2)
            self.assertEqual(fetch.call_count, 1)
            self.assertEqual(poll.call_args.kwargs, {'reconcile': True})
            self.assertEqual(len(self.collector.state['attempts']), 2)
            self.collector.execute()
            self.assertEqual(fetch.call_count, 1)


class ArtifactDownloadTests(unittest.TestCase):
    setUp = ReparseTests.setUp
    attempt = ReparseTests.attempt

    def prepare(self):
        self.args.allow_file_urls = False
        self.args.max_attempts = 1
        self.pending = self.attempt(
            phase='artifacts',
            reason='artifact retrieval incomplete after observing a complete stream; resume same run')
        self.pending['observed_complete_stream'] = True
        self.state.update(input_fingerprint=self.collector.fingerprint,
                          base_input_fingerprint=self.collector.base_fingerprint)
        self.state['inputs'] = self.collector.clean(self.collector.identity)
        self.collector.state = self.state
        self.directory = self.out/'ios/01-B1-1'
        self.stream = (self.directory/'automation.txt').read_bytes()
        self.limit = len(self.stream) + 100
        self.test_arn = ARN+'test:p/r1-1/job/benchmark/test'
        self.artifacts = [
            dict(arn=ARN+'artifact:p/r1-1/job/setup/test/syslog', name='Syslog',
                 type='DEVICE_LOG', extension='syslog', url='https://example.test/setup'),
            dict(arn=self.test_arn.replace(':test:', ':artifact:')+'/output', name='Test Output',
                 type='TEST_LOG', extension='txt', url='https://example.test/stream')]
        self.responses = []
        self.header = None
        self.stream_oversized = False
        self.download_error = None

        def aws(op, **kwargs):
            if op == 'get-run':
                self.assertEqual(kwargs['arn'], self.pending['run_arn'])
                return {'run': dict(self.pending['provider'], deviceMinutes={'total': 1.25})}
            if op == 'list-jobs':
                return {'jobs': [dict(self.pending['jobs'][0], arn=ARN+'job:p/r1-1/job')]}
            if op == 'list-suites':
                return {'suites': [dict(arn=ARN+'suite:p/r1-1/job/benchmark', result='PASSED')]}
            if op == 'list-tests':
                return {'tests': [dict(arn=self.test_arn, name='testQualificationBaseline', result='PASSED')]}
            if op == 'list-artifacts':
                return {'artifacts': self.artifacts if kwargs['type'] == 'LOG' else []}
            raise AssertionError('unexpected provider operation: '+op)

        def urlopen(url, **kwargs):
            setup = url.endswith('/setup')
            if setup and self.download_error:
                raise self.download_error
            oversized = setup or self.stream_oversized
            response = io.BytesIO(b'x'*(self.limit+20) if oversized else self.stream)
            response.geturl = lambda: url
            response.headers = {} if self.header is None else {'Content-Length': self.header}
            read = response.read

            def bounded_read(size=-1):
                self.assertGreater(size, 0, 'download must use a bounded read')
                self.assertLessEqual(size, self.limit+1)
                data = read(size)
                response.bytes_read += len(data)
                self.assertLessEqual(response.bytes_read, self.limit+1)
                return data

            response.bytes_read = 0
            response.read = bounded_read
            self.responses.append(response)
            return response

        for mock in (patch.object(self.collector, 'aws', side_effect=aws),
                     patch.object(driver.urllib.request, 'urlopen', side_effect=urlopen),
                     patch.object(driver, 'LIMIT', self.limit)):
            mock.start()
            self.addCleanup(mock.stop)

    def manifest(self):
        return json.loads((self.directory/'manifest.json').read_text())

    def test_nonstream_oversize_is_not_retained_and_stream_completes(self):
        self.prepare()
        for header, expected_size in ((None, self.limit+1), (str(self.limit*10), self.limit*10),
                                      ('invalid', self.limit+1), ('-1', self.limit+1),
                                      ('1', self.limit+1)):
            with self.subTest(content_length=header):
                self.header = header
                self.collector.collect_artifacts(self.pending, self.pending['provider'])
                manifest = self.manifest()
                self.assertEqual(manifest['errors'], [])
                oversized, stream = manifest['artifacts']
                self.assertEqual(oversized['status'], 'oversized_not_retained')
                self.assertEqual(oversized['size_bytes'], expected_size)
                self.assertEqual(oversized['arn'], self.collector.clean(self.artifacts[0]['arn']))
                self.assertEqual((oversized['name'], oversized['type']), ('Syslog', 'DEVICE_LOG'))
                self.assertFalse(oversized['stream_source'])
                self.assertNotIn('download_sha256', oversized)
                self.assertEqual([f['artifact_arn'] for f in manifest['files']], [stream['arn']])
                self.assertTrue(self.pending['valid'])
                self.assertEqual(self.pending['phase'], 'done')
                self.assertTrue(all(r.closed for r in self.responses))

    def test_oversized_stream_remains_a_hard_failure(self):
        self.prepare()
        self.stream_oversized = True
        with self.assertRaises(driver.Stop):
            self.collector.collect_artifacts(self.pending, self.pending['provider'])
        self.assertEqual(self.pending['phase'], 'artifacts')
        self.assertFalse(self.pending['valid'])
        manifest = self.manifest()
        self.assertEqual(len(manifest['errors']), 1)
        self.assertIn('artifact exceeds size limit', manifest['errors'][0])
        self.assertNotEqual(manifest['artifacts'][1].get('status'), 'oversized_not_retained')

    def test_value_error_message_is_preserved_and_redacted(self):
        self.prepare()
        self.download_error = ValueError('bad artifact '+ARN+'artifact:private '
                                         'https://example.test/log?secret=credential')
        with self.assertRaises(driver.Stop):
            self.collector.collect_artifacts(self.pending, self.pending['provider'])
        error = self.manifest()['errors'][0]
        self.assertIn('ValueError: bad artifact', error)
        self.assertIn(':REDACTED:artifact:private', error)
        self.assertNotIn(ACCOUNT, error)
        self.assertNotIn('secret', error)
        self.assertNotIn('credential', error)

    def test_nonstream_archive_expansion_limit_is_still_an_error(self):
        self.prepare()
        data = io.BytesIO()
        with zipfile.ZipFile(data, 'w', zipfile.ZIP_DEFLATED) as archive:
            archive.writestr('large.log', b'x'*(self.limit+1))
        with patch.object(self.collector, 'download', side_effect=[data.getvalue(), self.stream]):
            with self.assertRaises(driver.Stop):
                self.collector.collect_artifacts(self.pending, self.pending['provider'])
        self.assertIn('expanded artifact exceeds size limit', self.manifest()['errors'][0])
        self.assertNotIn('status', self.manifest()['artifacts'][0])

    def test_download_accepts_exact_limit(self):
        self.prepare()
        self.stream = b'x'*self.limit
        self.assertEqual(self.collector.download('https://example.test/stream'), self.stream)

    def legacy_checkpoint(self):
        # Exact pre-fix driver fingerprint, with unchanged parser and input pins.
        old_parser = driver.digest(driver.encoded(dict(
            driver_sha256='cfceaf3e677d4d77ff3fff714960e77e956e0aeced8d9dfe819c96d56b58aade',
            parser_sha256=driver.digest(self.collector.parser_path.read_bytes()))))
        self.state['inputs']['parser_fingerprint'] = old_parser
        self.state['input_fingerprint'] = driver.digest(driver.encoded(dict(
            base_input_fingerprint=self.collector.base_fingerprint, parser_fingerprint=old_parser)))
        (self.directory/'manifest.json').write_text(json.dumps(dict(
            artifacts=[], files=[], errors=['artifact download/extraction failure: ValueError'])))
        (self.out/'state.json').write_text(json.dumps(self.state))

    def test_resume_pre_fix_oversize_checkpoint_refetches_same_run(self):
        self.prepare()
        self.legacy_checkpoint()
        with patch.object(self.collector, 'preflight'), \
                patch.object(self.collector, 'schedule', side_effect=AssertionError('must not schedule')), \
                contextlib.redirect_stderr(io.StringIO()):
            self.assertEqual(self.collector.execute(), 2)  # Remaining slots hit the attempt cap.
            state = json.loads((self.out/'state.json').read_text())
            self.assertEqual(len(state['attempts']), 1)
            completed = state['attempts'][0]
            self.assertEqual(completed['run_arn'], self.collector.clean(self.pending['run_arn']))
            self.assertTrue(completed['valid'], completed['reason'])
            self.assertEqual(completed['phase'], 'done')
            self.assertEqual(state['input_fingerprint'], self.collector.fingerprint)
            self.assertEqual(self.manifest()['errors'], [])
            self.assertEqual(self.collector.execute(), 2)
            self.assertEqual(len(self.responses), 2)  # Completed attempt is not fetched again.

    def test_resume_pre_fix_checkpoint_does_not_clear_other_download_errors(self):
        self.prepare()
        self.download_error = ValueError('unrelated retrieval failure')
        self.legacy_checkpoint()
        with patch.object(self.collector, 'preflight'), \
                patch.object(self.collector, 'schedule', side_effect=AssertionError('must not schedule')), \
                contextlib.redirect_stderr(io.StringIO()):
            self.assertEqual(self.collector.execute(), 2)
        attempt = self.collector.state['attempts'][0]
        self.assertFalse(attempt['valid'])
        self.assertEqual(attempt['phase'], 'artifacts')
        self.assertIn('unrelated retrieval failure', self.manifest()['errors'][0])

    def test_pending_resume_rejects_unknown_driver_or_changed_input_fingerprint(self):
        self.prepare()
        for fingerprint in ('0'*64, driver.digest(driver.encoded(dict(
                base_input_fingerprint='changed-pins',
                parser_fingerprint=self.collector.identity['parser_fingerprint'])))):
            self.state['input_fingerprint'] = fingerprint
            path = self.out/'state.json'
            path.write_text(json.dumps(self.state))
            before = path.read_bytes()
            with self.assertRaisesRegex(ValueError, 'inputs/parser differ'):
                self.collector.execute()
            self.assertEqual(path.read_bytes(), before)


class CollectionTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix='test-', dir=ROOT)
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.out = self.root/'out'
        executable = self.root/'aws'
        executable.write_text('#!'+sys.executable+'\nimport runpy,sys\nsys.argv.insert(1,"--fake-aws")\nrunpy.run_path('+repr(str(Path(__file__).resolve()))+',run_name="__main__")\n')
        executable.chmod(0o755)
        self.env = dict(os.environ, PATH=str(self.root)+os.pathsep+os.environ['PATH'],
                        FAKE_ROOT=str(self.root), AWS_PROFILE='offline', AWS_REGION='us-west-2',
                        PYTHONDONTWRITEBYTECODE='1')
        self.configure()

    def configure(self, platform='ios', **kw):
        self.platform = platform
        build, runtime, records = fixture(platform)
        for name, value in [('build', build), ('runtime', runtime)]:
            (self.root/(name+'.json')).write_text(json.dumps(value))
        self.config = dict(platform=platform, records=records, **kw)
        (self.root/'fake-config.json').write_text(json.dumps(self.config))

    def run_driver(self, *extra, expected=0):
        command = [sys.executable, '-B', str(ROOT/'df_collect.py'), 'collect', '--platform', self.platform,
                   '--app-arn', ARN+'upload:app', '--test-package-arn', ARN+'upload:tests',
                   '--device-pool-arn', ARN+'devicepool:p', '--build-json', str(self.root/'build.json'),
                   '--runtime-json', str(self.root/'runtime.json'), '--core-revision', 'a'*40,
                   '--out', str(self.out), '--poll-interval', '0', '--allow-file-urls', *extra]
        result = subprocess.run(command, env=self.env, stdin=subprocess.DEVNULL,
                                capture_output=True, text=True, timeout=120)
        self.assertEqual(result.returncode, expected, result.stdout+'\n'+result.stderr)
        return result

    def provider(self):
        return json.loads((self.root/'provider.json').read_text())

    def log(self):
        return json.loads((self.out/'collection-log.json').read_text())

    def test_normal_order_both_platforms(self):
        for platform in ('ios', 'android'):
            with self.subTest(platform=platform):
                self.configure(platform)
                self.out = self.root/('out-'+platform)
                (self.root/'provider.json').unlink(missing_ok=True)
                self.run_driver()
                log = self.log()
                self.assertEqual([(a['set'], a['run_index']) for a in log['attempts']],
                                 [(s, i) for i in range(1,7) for s in ('B1','V','B2')])
                self.assertTrue(all(a['valid'] for a in log['attempts']))
                self.assertEqual(log['total_device_minutes'], 18)
                self.assertEqual(log['failed_slots'], [])
                runs = self.provider()['runs']
                self.assertEqual(len(runs), 18)
                for run, attempt in zip(runs, log['attempts']):
                    method = 'testQualificationSlowdown' if attempt['set']=='V' else 'testQualificationBaseline'
                    prefix = 'BenchmarkTests/' if platform=='ios' else 'io.github.project_minigraf.benchmark.BenchmarkTest#'
                    self.assertEqual(run['test']['filter'], prefix+method)
                    self.assertEqual(run['test']['type'], 'XCTEST' if platform=='ios' else 'INSTRUMENTATION')
                    self.assertNotIn('parameters', run['test'])
                raw = json.loads((self.out/'raw-samples.json').read_text())
                config = raw['configurations'][0]
                self.assertEqual(len(config['cases']), 14)
                for case in config['cases'].values():
                    for entries in case['sets'].values():
                        self.assertEqual(len(entries), 6)
                        self.assertTrue(all(e['value_ns']==5.5 and len(e['sample_means_ns'])==10 for e in entries))
                self.assertTrue((self.out/'SHA256SUMS').is_file())

    def test_mismatched_upload_types_refused_before_schedule(self):
        types = ('IOS_APP', 'XCTEST_TEST_PACKAGE', 'ANDROID_APP', 'INSTRUMENTATION_TEST_PACKAGE')
        for platform, expected_types in (('ios', types[:2]), ('android', types[2:])):
            for role, expected_type in zip(('app', 'tests'), expected_types):
                for wrong_type in types:
                    if wrong_type == expected_type:
                        continue
                    with self.subTest(platform=platform, role=role, upload_type=wrong_type):
                        self.configure(platform, upload_types={role: wrong_type})
                        self.out = self.root/('-'.join((platform, role, wrong_type)))
                        (self.root/'provider.json').unlink(missing_ok=True)
                        result = self.run_driver(expected=2)
                        self.assertIn('upload is not a successful '+expected_type, result.stderr)
                        provider = self.provider()
                        self.assertEqual(provider['runs'], [])
                        self.assertFalse(any(call[1] == 'schedule-run' for call in provider['calls']))

    def test_failure_retry_and_valid_never_replaced(self):
        self.configure(behaviors=['failure'])
        self.run_driver()
        attempts = self.log()['attempts']
        self.assertEqual(len(attempts), 19)
        self.assertFalse(attempts[0]['valid'])
        self.assertTrue(attempts[0]['reason'])
        self.assertEqual([(a['set'],a['attempt']) for a in attempts[:3]], [('B1',1),('B1',2),('V',1)])
        self.run_driver('--resume')
        self.assertEqual(len(self.provider()['runs']), 19)

    def test_retry_exhaustion_continues_later_slots(self):
        self.configure(behaviors=['truncated']*3)
        self.run_driver(expected=2)
        log = self.log()
        self.assertEqual(len(log['attempts']), 20)
        self.assertEqual(log['failed_slots'], ['01-B1'])
        self.assertEqual(log['slots'][0]['status'], 'unresolved')

    def test_wrong_device_is_invalid(self):
        self.configure(behaviors=['wrong-device'])
        self.run_driver('--max-attempts','1', expected=2)
        a = self.log()['attempts'][0]
        self.assertFalse(a['valid'])
        self.assertIn('device', a['reason'])

    def test_resume_interruption_poll_and_schedule_acceptance(self):
        for stage in ('poll','schedule'):
            with self.subTest(stage=stage):
                self.configure(crash=stage)
                self.out = self.root/('out-'+stage)
                (self.root/'provider.json').unlink(missing_ok=True)
                self.run_driver(expected=-signal.SIGKILL)
                self.assertEqual(len(self.provider()['runs']), 1)
                self.run_driver('--resume')
                self.assertEqual(len(self.provider()['runs']), 18)
                self.assertEqual(len(self.log()['attempts']), 18)

    def test_account_redaction_in_every_retained_file(self):
        self.run_driver('--max-attempts','1', expected=2)
        for path in self.out.rglob('*'):
            if path.is_file():
                self.assertNotIn(ACCOUNT.encode(), path.read_bytes(), str(path))
        self.assertIn('REDACTED', (self.out/'state.json').read_text())

    def test_only_selected_test_logcat_supplies_android_stream(self):
        self.configure(platform='android', lifecycle_streams=True, instrumentation_stream=True,
                       mirrored_logcat=True)
        self.run_driver('--max-attempts', '1', expected=2)
        self.assertTrue(self.log()['attempts'][0]['valid'], self.log()['attempts'][0]['reason'])
        directory = self.out/'android'/'01-B1-1'
        manifest = json.loads((directory/'manifest.json').read_text())
        logs = [f for f in manifest['files'] if f['path'].endswith('Logcat.logcat')]
        self.assertEqual(len(logs), 4)
        self.assertEqual(len({f['path'] for f in logs}), 4)
        self.assertEqual(len({f['artifact_arn'] for f in logs}), 4)
        self.assertEqual(len({(directory/f['path']).read_bytes() for f in logs}), 3)

    def test_ios_ignores_other_tests_streams(self):
        self.configure(platform='ios', lifecycle_streams=True)
        self.run_driver('--max-attempts', '1', expected=2)
        self.assertTrue(self.log()['attempts'][0]['valid'], self.log()['attempts'][0]['reason'])

    def test_setup_teardown_cannot_replace_missing_selected_stream(self):
        self.configure(platform='android', lifecycle_streams=True, no_selected_stream=True)
        self.run_driver('--max-attempts', '1', expected=2)
        attempt = self.log()['attempts'][0]
        self.assertFalse(attempt['valid'])
        self.assertFalse(attempt.get('observed_complete_stream', False))
        self.assertIsNone(attempt['parsed']['environment'])

    def test_wrong_test_cannot_supply_stream(self):
        self.configure(platform='android', wrong_test=True)
        self.run_driver('--max-attempts', '1', expected=2)
        self.assertFalse(self.log()['attempts'][0]['valid'])

    def test_dry_run_no_aws_no_state(self):
        result = self.run_driver('--dry-run')
        self.assertIn('B1', result.stdout)
        self.assertFalse((self.root/'provider.json').exists())
        self.assertFalse(self.out.exists())

    def test_caps(self):
        self.run_driver('--max-attempts','2', expected=2)
        self.assertEqual(len(self.provider()['runs']), 2)
        self.out = self.root/'budget-out'
        (self.root/'provider.json').unlink()
        self.run_driver('--max-device-minutes','1', expected=2)
        self.assertEqual(len(self.provider()['runs']), 0)
        self.assertIn('minute', self.log()['stop_reason'])

    def test_invalid_streams_and_stale_process_identity(self):
        for behavior in ('build-drift','duplicate','stale'):
            with self.subTest(behavior=behavior):
                self.configure(behaviors=['valid', behavior])
                self.out = self.root/behavior
                (self.root/'provider.json').unlink(missing_ok=True)
                self.run_driver('--max-attempts','2', expected=2)
                self.assertFalse(self.log()['attempts'][1]['valid'])

    def test_missing_pins_fail_before_aws(self):
        build = json.loads((self.root/'build.json').read_text())
        del build['core_revision']
        (self.root/'build.json').write_text(json.dumps(build))
        self.run_driver(expected=2)
        self.assertFalse((self.root/'provider.json').exists())

    def test_timeout_stops_until_provider_completion(self):
        self.configure(behaviors=['timeout'])
        self.run_driver('--run-timeout','0.01', expected=2)
        self.assertEqual(len(self.provider()['runs']), 1)
        self.assertIn('timeout', self.log()['attempts'][0]['reason'])
        self.config['complete_timeout'] = True
        (self.root/'fake-config.json').write_text(json.dumps(self.config))
        self.run_driver('--run-timeout','0.01','--resume','--max-attempts','2', expected=2)
        self.assertEqual(len(self.provider()['runs']), 2)
        self.assertFalse(self.log()['attempts'][0]['valid'])

    def test_ambiguous_schedule_never_resubmitted(self):
        self.configure(crash='before-schedule')
        self.run_driver(expected=-signal.SIGKILL)
        for _ in range(2):
            self.run_driver('--resume', expected=2)
        calls = self.provider()['calls']
        self.assertEqual(sum(c[1]=='schedule-run' for c in calls), 1)
        self.assertEqual(len(self.provider()['runs']), 0)
        self.assertIn('ambiguous', self.log()['stop_reason'])

    def test_paginated_archive_collection_and_checksums(self):
        import hashlib
        self.configure(platform='android', paginate=True, zip=True)
        self.run_driver('--max-attempts','1', expected=2)
        self.assertTrue(self.log()['attempts'][0]['valid'])
        for line in (self.out/'SHA256SUMS').read_text().splitlines():
            checksum, name = line.split('  ',1)
            data = (self.out/name).read_bytes()
            self.assertEqual(hashlib.sha256(data).hexdigest(), checksum)
            self.assertNotIn(ACCOUNT.encode(), data)
        self.assertFalse((self.out/'unsafe').exists())

    def test_wrong_os_and_resume_pin_drift(self):
        self.configure(behaviors=['wrong-os'])
        self.run_driver('--max-attempts','1', expected=2)
        self.assertFalse(self.log()['attempts'][0]['valid'])
        pins = json.loads((self.root/'runtime.json').read_text())
        pins['os_build'] = 'different'
        (self.root/'runtime.json').write_text(json.dumps(pins))
        count = len(self.provider()['calls'])
        self.run_driver('--resume', expected=2)
        self.assertEqual(len(self.provider()['calls']), count)

    def test_stale_identity_from_failed_attempt_is_rejected(self):
        self.configure(behaviors=['failure','stale'])
        self.run_driver('--max-attempts','2', expected=2)
        self.assertFalse(self.log()['attempts'][1]['valid'])
        self.assertIn('stale', self.log()['attempts'][1]['reason'])

    def test_summary_reads_authoritative_state_without_aws(self):
        self.run_driver('--max-attempts','1', expected=2)
        calls = len(self.provider()['calls'])
        result = subprocess.run([sys.executable,'-B',str(ROOT/'df_collect.py'),'summary','--out',str(self.out)],
                                stdin=subprocess.DEVNULL, capture_output=True, text=True, env=self.env)
        self.assertEqual(result.returncode,0,result.stderr)
        summary = json.loads(result.stdout)
        self.assertEqual(summary['total_device_minutes'],1)
        self.assertEqual(len(summary['failed_slots']),17)
        self.assertEqual(len(self.provider()['calls']), calls)

    def test_valid_stream_not_replaced_for_unavailable_screenshot(self):
        self.configure(missing_screenshot=True)
        self.run_driver('--max-attempts','2', expected=2)
        self.assertEqual(len(self.provider()['runs']), 1)
        retained = self.log()['attempts'][0]
        self.assertEqual(retained['phase'], 'artifacts')
        self.config['missing_screenshot'] = False
        (self.root/'fake-config.json').write_text(json.dumps(self.config))
        self.run_driver('--max-attempts','2','--resume', expected=2)
        self.assertEqual(len(self.provider()['runs']), 2)
        self.assertTrue(self.log()['attempts'][0]['valid'])
        self.assertEqual(self.log()['attempts'][0]['run_arn'], retained['run_arn'])
        self.assertEqual(sum(c[1] == 'schedule-run' for c in self.provider()['calls']), 2)
        self.assertEqual(self.log()['attempts'][1]['set'], 'V')

    def test_minute_cap_boundary(self):
        self.run_driver('--run-timeout','60','--max-device-minutes','2', expected=2)
        self.assertEqual(len(self.provider()['runs']), 2)
        self.assertEqual(self.log()['total_device_minutes'], 2)

    def test_placeholder_runtime_refused(self):
        pins = json.loads((self.root/'runtime.json').read_text())
        pins['os_build'] = 'ACTUAL_PRE_REGISTERED_BUILD'
        (self.root/'runtime.json').write_text(json.dumps(pins))
        self.run_driver('--max-attempts','1', expected=2)
        self.assertFalse((self.root/'provider.json').exists())

    def test_poll_transport_cannot_outlive_run_deadline(self):
        self.configure(behaviors=['timeout'], stall_get_run=True)
        started = time.monotonic()
        self.run_driver('--run-timeout','0.5', expected=2)
        self.assertLess(time.monotonic()-started, 1.8)
        self.assertIn('timeout', self.log()['attempts'][0]['reason'])

    def test_resume_does_not_timeout_run_completed_while_driver_was_down(self):
        self.configure(crash='poll')
        self.run_driver(expected=-signal.SIGKILL)
        state_path = self.out/'state.json'
        state = json.loads(state_path.read_text())
        state['attempts'][0]['submitted_epoch'] -= 3600  # simulate downtime, not device runtime
        state_path.write_text(json.dumps(state))
        self.run_driver('--resume','--max-attempts','1', expected=2)
        self.assertTrue(self.log()['attempts'][0]['valid'])
        self.assertEqual(len(self.provider()['runs']), 1)

    def test_resume_regenerates_receipts_from_authoritative_state(self):
        self.run_driver('--max-attempts','1', expected=2)
        directory = self.out/'ios'/'01-B1-1'
        for name in ('attempt.json', 'parsed.json'):
            (directory/name).unlink()
        self.run_driver('--resume','--max-attempts','1', expected=2)
        self.assertTrue((directory/'attempt.json').exists())
        self.assertTrue(json.loads((directory/'parsed.json').read_text())['valid'])
        self.assertEqual(len(self.provider()['runs']), 1)


if __name__ == '__main__':
    if len(sys.argv)>1 and sys.argv[1]=='--fake-aws':
        fake_aws()
    else:
        unittest.main()

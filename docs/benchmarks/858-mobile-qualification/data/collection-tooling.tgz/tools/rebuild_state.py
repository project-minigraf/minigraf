"""Read-only reconstruction using the collector's original artifact validator."""
import copy
import datetime
import fcntl
import json
import os
from pathlib import Path
import re
import time
import df_collect as d

READ_ONLY = frozenset(('list-runs', 'list-jobs', 'list-suites', 'list-tests',
                      'list-artifacts', 'list-uploads', 'list-device-pools', 'get-run'))

def timestamp(value):
    d.require(isinstance(value, str), 'run creation time is missing')
    parsed = datetime.datetime.fromisoformat(value.replace('Z', '+00:00'))
    d.require(parsed.tzinfo is not None, 'run timestamp lacks timezone')
    return parsed.timestamp()


def ordered_runs(runs, collection_id):
    d.require(re.fullmatch('[0-9a-f]{32}', collection_id), 'collection id must be 32 lowercase hex digits')
    prefix = 'm858-'+collection_id+'-'
    selected = []
    for run in runs:
        name = run.get('name', '')
        if not name.startswith(prefix):
            continue
        match = re.fullmatch(re.escape(prefix)+r'(0[1-6])-(B1|V|B2)-([1-3])', name)
        d.require(match is not None, 'collection run has malformed slot or exceeds two retries')
        i, s, attempt = int(match[1]), match[2], int(match[3])
        selected.append(dict(slot=f'{i:02d}-{s}', set=s, run_index=i, attempt=attempt,
                             created_epoch=timestamp(run.get('created')), run=run))
    selected.sort(key=lambda row: (row['created_epoch'], row['run'].get('arn', '')))
    seen, arns = {}, set()
    for row in selected:
        arn = row['run'].get('arn')
        d.require(isinstance(arn, str) and arn not in arns, 'missing or duplicate run ARN')
        arns.add(arn)
        number = seen.get(row['slot'], 0)+1
        d.require(row['attempt'] == number, 'duplicate, missing, or out-of-order attempt number for '+row['slot'])
        seen[row['slot']] = number
    return selected


def resolve_inputs(args, listing, project):
    uploads = listing('list-uploads', 'uploads', arn=project)
    kinds = ('IOS_APP', 'XCTEST_TEST_PACKAGE') if args.platform == 'ios' else ('ANDROID_APP', 'INSTRUMENTATION_TEST_PACKAGE')
    for attr, name_attr, kind in zip(('app_arn', 'test_package_arn'), ('app_name', 'test_package_name'), kinds):
        supplied = getattr(args, attr)
        matches = [x for x in uploads if (x.get('arn') == supplied if supplied else x.get('name') == getattr(args, name_attr)) and x.get('type') == kind]
        d.require(len(matches) == 1 and matches[0].get('status') == 'SUCCEEDED',
                  'expected one successful named '+kind+' upload; supply an explicit ARN if ambiguous')
        setattr(args, attr, matches[0]['arn'])
    pools = listing('list-device-pools', 'devicePools', arn=project)
    pools = [x for x in pools if (x.get('arn') == args.device_pool_arn if args.device_pool_arn else x.get('name') == args.pool_name)]
    d.require(len(pools) == 1, 'expected exactly one named device pool')
    pool = pools[0]
    rules = [json.loads(x['value']) for x in pool.get('rules', []) if x.get('attribute') == 'ARN' and x.get('operator') == 'IN']
    d.require(len(rules) == 1 and isinstance(rules[0], list) and len(rules[0]) == 1,
              'device pool must pin one device ARN')
    args.device_pool_arn = pool['arn']
    return rules[0][0]


class ReadOnlyCollector(d.Collector):
    def __init__(self, args):
        self.serials = set()
        super().__init__(args)

    def aws(self, op, _timeout=60, **kwargs):
        d.require(op in READ_ONLY, 'rebuild-state operation is not read-only allowlisted')
        # Bypass the legacy operation allowlist, never the recovery allowlist.
        command = ['aws', 'devicefarm', op, '--profile', os.environ['AWS_PROFILE'],
                   '--region', os.environ['AWS_REGION'], '--output', 'json', '--no-paginate']
        for key, value in kwargs.items():
            command.extend(['--'+key.replace('_', '-'), str(value)])
        try:
            result = d.subprocess.run(command, stdin=d.subprocess.DEVNULL, capture_output=True,
                                      timeout=_timeout, env=dict(os.environ, AWS_PAGER='',
                                      AWS_CLI_AUTO_PROMPT='off', AWS_MAX_ATTEMPTS='1'))
        except (OSError, d.subprocess.TimeoutExpired) as error:
            raise d.Stop(op+' transport failure ('+type(error).__name__+')') from None
        if result.returncode:
            # Preserve a useful sanitized error, never URLs or response bodies.
            message = re.sub(r'https?://[^\s\'"<>]+', '[REDACTED URL]', result.stderr.decode(errors='replace'))
            message = re.sub(r'\b\d{12}\b', 'REDACTED', message)
            raise d.Stop(op+' CLI failure: '+message[:800].strip())
        response = json.loads(result.stdout)
        self.remember_serials(response)
        return response

    def remember_serials(self, value):
        if isinstance(value, dict):
            for key, item in value.items():
                if re.sub('[^a-z]', '', key.lower()) in ('serial', 'serialnumber', 'deviceserial', 'udid'):
                    if isinstance(item, str) and item:
                        self.serials.add(item)
                else:
                    self.remember_serials(item)
        elif isinstance(value, list):
            for item in value:
                self.remember_serials(item)

    def redact(self, data):
        data = super().redact(data)
        for serial in sorted(self.serials, key=len, reverse=True):
            data = data.replace(serial.encode(), b'REDACTED')
        data = re.sub(rb'\b00008[0-9A-Fa-f]{3}-[0-9A-Fa-f]{16}\b', b'REDACTED', data)
        data = re.sub(rb'(?i)((?:device[_ -]?)?serial(?:[_ -]?number)?|udid)(["\x27]?\s*[:=]\s*["\x27]?)([A-Za-z0-9_-]{6,})',
                      rb'\1\2REDACTED', data)
        return data

    def initialize(self, collection_id, rows):
        self.state = dict(schema_version=1, input_fingerprint=self.fingerprint,
                          base_input_fingerprint=self.base_fingerprint, inputs=self.clean(self.identity),
                          collection_id=collection_id, started_at=rows[0]['run']['created'], attempts=[],
                          rebuild=dict(rebuilt_at=d.now(), timestamp_source='provider created/started/stopped',
                                       historical_driver_phase='unavailable unless explicitly supplied'), stop_reason='')
        self.write_json(self.out/'build.json', self.build)
        self.write_json(self.out/'runtime.json', self.runtime)
        d.atomic(self.out/'parse_samples.py', self.parser_path.read_bytes())
        self.save()

    def mark_superseded(self, attempt):
        attempt['recovered_evidence_valid'] = attempt['parsed']['valid']
        reason = 'historical artifacts-phase attempt superseded (explicit recovery input)'
        attempt.update(valid=False, reason=reason, phase='done', historical_phase='artifacts', superseded=True)
        self.invalidate(attempt['parsed'], reason)

    def recover_attempt(self, row, run, superseded=False):
        d.require(run.get('arn') == row['run']['arn'] and run.get('name') == row['run']['name'],
                  'get-run identity differs from run inventory')
        d.require(run.get('appUpload') == self.args.app_arn,
                  'historical run app upload differs from current inputs or is missing')
        d.require(run.get('devicePoolArn') == self.args.device_pool_arn,
                  'historical run device pool differs from current inputs or is missing')
        attempt = {key: row[key] for key in ('slot', 'set', 'run_index', 'attempt')}
        attempt.update(name=run['name'], run_arn=self.clean(run['arn']), phase='artifacts',
                       valid=False, reason='no valid stream: pending artifact recovery',
                       submitted_at=run['created'], submitted_epoch=row['created_epoch'],
                       started_at=run.get('started'), finished_at=run.get('stopped'), device_minutes=None)
        attempt['parsed'] = self.invalidate(self.parse('', attempt), attempt['reason'])
        self.state['attempts'].append(attempt)
        self.run_metadata(attempt, run)
        self.save()
        if run.get('status') != 'COMPLETED':
            attempt['phase'] = 'active'
            self.state['stop_reason'] = 'provider run still active; recovery never polls or schedules'
            self.save()
            raise d.Stop(self.state['stop_reason'])
        jobs = self.listing('list-jobs', 'jobs', arn=run['arn'])
        self.remember_serials(jobs)
        # Obtain serials before any retained artifact, even with a fixture client.
        old_listing = self.listing
        def cached_jobs(op, key, **kwargs):
            return jobs if op == 'list-jobs' else old_listing(op, key, **kwargs)
        self.listing = cached_jobs
        try:
            try:
                self.collect_artifacts(attempt, run)
            except d.Stop:
                if not superseded or attempt['phase'] != 'artifacts':
                    raise
        finally:
            self.listing = old_listing
        if len(jobs) != 1 or jobs[0].get('device', {}).get('arn') != self.pinned_device:
            reason = 'no valid stream: actual device ARN differs from pinned pool device'
            attempt.update(valid=False, reason=reason)
            self.invalidate(attempt['parsed'], reason)
        if superseded:
            self.mark_superseded(attempt)
        attempt.update(started_at=run.get('started'), finished_at=run.get('stopped'),
                       recovered_at=d.now(), elapsed_seconds=(timestamp(run['stopped'])-row['created_epoch']) if run.get('stopped') else None)
        self.save(rewrite_attempts=True)
        return attempt


def rebuild(args):
    os.environ.setdefault('AWS_PROFILE', 'minigraf-devicefarm')
    os.environ.setdefault('AWS_REGION', 'us-west-2')
    d.require(os.environ['AWS_PROFILE'] == 'minigraf-devicefarm' and os.environ['AWS_REGION'] == 'us-west-2',
              'recovery requires minigraf-devicefarm/us-west-2')
    d.require(re.fullmatch(r'arn:aws:devicefarm:us-west-2:\d{12}:project:[0-9a-f-]+', args.project_arn),
              'a complete project ARN is required (no list-projects calls)')
    # Bootstrap the same guarded client before upload discovery supplies inputs.
    bootstrap = ReadOnlyCollector.__new__(ReadOnlyCollector)
    bootstrap.serials = set()
    bootstrap.account = args.project_arn.split(':')[4]
    defaults = (('qual-a566cb2-MinigrafBenchmark.ipa', 'qual-a566cb2-BenchmarkTests.xctest.zip', 'iphone15-ios185-858')
                if args.platform == 'ios' else ('qual-minigraf-device-farm-release.apk', 'qual-minigraf-device-farm-androidTest.apk', 'pixel7-android14-858'))
    for key, value in zip(('app_name', 'test_package_name', 'pool_name'), defaults):
        if getattr(args, key) is None:
            setattr(args, key, value)
    rows = ordered_runs(bootstrap.listing('list-runs', 'runs', arn=args.project_arn), args.collection_id)
    d.require(rows, 'no matching collection runs returned by complete project inventory')
    pin = resolve_inputs(args, bootstrap.listing, args.project_arn)
    collector = ReadOnlyCollector(args)
    d.require(collector.account == bootstrap.account, 'project and upload accounts differ')
    collector.project, collector.pinned_device = args.project_arn, pin
    superseded = set(args.superseded_attempt or [])
    names = {x['slot']+'-'+str(x['attempt']) for x in rows}
    d.require(superseded <= names, 'superseded attempt was not found in provider inventory')
    out = collector.out
    out.mkdir(parents=True, exist_ok=True)
    with (out/'.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        path = out/'state.json'
        if path.exists():
            collector.state = json.loads(path.read_text())
            d.require(collector.state.get('collection_id') == args.collection_id and
                      collector.state.get('input_fingerprint') == collector.fingerprint,
                      'existing recovery state has different collection or inputs')
            # Verify its exact inventory prefix before continuing a partial rebuild.
            done = collector.state['attempts']
            for i, attempt in enumerate(done):
                d.require(i < len(rows) and collector.restore(attempt['run_arn']) == rows[i]['run']['arn'],
                          'existing state is not a prefix of chronological provider inventory')
                d.require(attempt.get('superseded', False) == (attempt['slot']+'-'+str(attempt['attempt']) in superseded)
                          or attempt['phase'] != 'done', 'superseded recovery inputs changed')
            while done and done[-1]['phase'] != 'done':
                done.pop()
            d.require(all(a['phase'] == 'done' for a in done), 'unfinished attempt inside completed history')
        else:
            d.require(not any(p.name != '.lock' for p in out.iterdir()), 'recovery output must be empty')
            collector.initialize(args.collection_id, rows)
        collector.state['stop_reason'] = ''
        for row in rows[len(collector.state['attempts']):]:
            run = collector.aws('get-run', arn=row['run']['arn'])['run']
            attempt = collector.recover_attempt(row, run, row['slot']+'-'+str(row['attempt']) in superseded)
            print(f"{attempt['slot']}-{attempt['attempt']}: {attempt['reason'] or 'valid'}", flush=True)
        collector.state['rebuild']['completed_at'] = d.now()
        collector.save(rewrite_attempts=True)
        print('Satisfied slots: '+', '.join(x['slot'] for x in collector.slots() if x['status'] == 'completed'))
    # Successful reconstruction can have missing collection slots.
    return 0

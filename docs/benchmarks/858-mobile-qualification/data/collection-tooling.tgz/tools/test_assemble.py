"""Synthetic fixtures only; never import samples from a collection."""
import copy
import hashlib
import json
from pathlib import Path
import shutil
import statistics
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parent
CASES = ('prepared_execute/1k', 'cursor_batch_1/1k', 'cursor_batch_256/1k',
         'set_roundtrip/2', 'predicate/1k', 'aggregate/1k', 'prepare/point',
         'register_predicate/first', 'register_aggregate/first',
         'fact_log_batch_256/1k', 'options_error/negative_cache',
         'options_readonly_open/1k', 'file_transact/1k', 'log_writer_append_finish/1k')
SETS = ('B1', 'V', 'B2')


def put(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj) + '\n')


class AssembleTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(dir=ROOT)
        self.addCleanup(self.tmp.cleanup)
        self.base = Path(self.tmp.name)
        self.physical = self.base / 'physical'
        self.ci = self.base / 'ci'
        self.out = self.base / 'out'
        self.build_path = self.base / 'build.json'
        self.platform = 'android'
        self.build = dict(core_revision='a'*40, binding_revision='b'*40,
                          harness_revision='b'*40, profile='Release',
                          slowdown_flag='repeat-timed-operation-twice',
                          native_artifacts={'arm64-v8a': {'sha256': 'c'*64},
                                            'x86_64': {'sha256': 'd'*64}})
        self.host = dict(ImageOS='ubuntu24', ImageVersion='synthetic-image',
                         RUNNER_OS='Linux', RUNNER_ARCH='X64', host_arch='x86_64',
                         host_kernel='synthetic-kernel', GITHUB_SHA='b'*40,
                         GITHUB_WORKFLOW_SHA='b'*40, runs_per_set=6, retries_per_slot=2)
        self.runtime = dict(runner_image='synthetic-image', host_arch='x86_64',
                            host_kernel='synthetic-kernel', emulator_version='synthetic-emulator',
                            emulator_package={'Pkg.Revision': 'synthetic', 'Pkg.BuildId': 'synthetic'},
                            image='system-images;android-34;google_apis;x86_64',
                            system_image_package={'Pkg.Revision': '14', 'AndroidVersion.ApiLevel': '34', 'SystemImage.Abi': 'x86_64'},
                            device_profile='pixel_7', backend='KVM', kvm_present=True,
                            acceleration_active=True, accel_check_exit=0,
                            accel_check_output='KVM installed and usable',
                            live_kvm_fd_targets=['/dev/kvm'], translation='none: x86_64 guest on x86_64 host',
                            boot_policy='synthetic cold boot and force stop',
                            guest={'ro.product.cpu.abi': 'x86_64', 'ro.build.version.sdk': '34',
                                   'ro.build.version.release': '14', 'ro.build.fingerprint': 'synthetic-fingerprint'})
        self.make_fixture()

    def make_fixture(self):
        put(self.build_path, self.build)
        put(self.ci / 'host.json', self.host)
        put(self.ci / 'resolved-config.json', dict(core_ref='a'*40, schedule='B1,V,B2', collect=True))
        for name, content in [('emulator-version.txt', 'synthetic-emulator'),
                              ('accel-check.txt', 'KVM installed and usable'),
                              ('avd-list.txt', 'pixel_7')]:
            (self.ci / name).write_text(content)
        physical = dict(id=self.platform+'-physical-v1', platform=self.platform, kind='physical',
                        reference=None, blocking_reason=None,
                        build={k: self.build[k] for k in ('core_revision', 'binding_revision', 'harness_revision', 'profile', 'slowdown_flag')},
                        runtime={'provider': 'synthetic', 'model': 'synthetic', 'os': 'synthetic'},
                        cases={c: {'blocking_reason': None, 'sets': {s: [] for s in SETS}} for c in CASES})
        physical['build']['artifact_sha256'] = {s: 'c'*64 for s in SETS}
        for i in range(1, 7):
            for s in SETS:
                run = self.write_attempt(i, s, 1)
                for c in CASES:
                    physical['cases'][c]['sets'][s].append(copy.deepcopy(run['cases'][c]))
        put(self.physical / 'raw-samples.json', dict(schema_version=1, synthetic=True, configurations=[physical]))
        put(self.physical / 'build.json', self.build)

    def write_attempt(self, i, s, a, valid=True, empty_identity=False):
        path = self.ci / 'runs' / ('%02d-%s-attempt-%d' % (i, s, a))
        reason = '' if valid else 'synthetic validation failure'
        attempt = dict(run_index=i, set=s, attempt=a, valid=valid, reason=reason, exit_code=0,
                       test='testQualificationSlowdown' if s == 'V' else 'testQualificationBaseline')
        env = dict(build=copy.deepcopy(self.build), profile='Release', mode='qualification',
                   double_work=s == 'V', variant='slowdown' if s == 'V' else 'baseline',
                   platform='emulator', native_sha256='d'*64, loaded_abi='x86_64')
        rt = dict(platform='emulator', loaded_abi='x86_64', native_sha256='d'*64,
                  os='14', sdk=34, fingerprint='synthetic-fingerprint')
        if self.platform == 'ios':
            env.update(platform='simulator', simulator_device_type=self.build['simulator_device_type'],
                       simulator_runtime=self.build['simulator_runtime'])
            env['build'] = {k: self.build[k] for k in ('core_revision', 'binding_revision', 'harness_revision')}
            env['build']['native_sha256'] = 'd'*64
            rt = dict(platform='simulator', compiled_simulator=True, architecture='arm64',
                      **{k: self.build[k] for k in ('simulator_device_type', 'simulator_runtime', 'simulator_runtime_build', 'simulator_runtime_version')})
            attempt.update(runner_image=self.host['ImageVersion'], simulator={k: self.build[k] for k in rt if k.startswith('simulator_')})
        cases = {}
        for c in CASES:
            samples = [100 + i + n for n in range(10)] if valid else [100 + i]
            cases[c] = dict(run_index=i, attempt=a, valid=valid, reason=reason,
                            value_ns=statistics.median(samples) if valid else None,
                            sample_means_ns=samples)
        run = dict(schema_version=1, set=s, valid=valid, reason=reason, cases=cases,
                   environment=None if empty_identity else env,
                   runtime=None if empty_identity else rt, records=[])
        put(path / 'attempt.json', attempt)
        put(path / 'run.json', run)
        if self.platform == 'android':
            put(path / 'runtime.json', self.runtime)
        (path / 'raw.log').write_text('synthetic raw evidence\n')
        return run

    def invoke(self, error=None, earliest_valid_attempt=False):
        p = subprocess.run([sys.executable, '-B', str(ROOT/'assemble.py'), '--platform', self.platform,
                            '--physical-dir', str(self.physical), '--ci-evidence', str(self.ci),
                            '--build-json', str(self.build_path), '--out', str(self.out)]
                           + (['--earliest-valid-attempt'] if earliest_valid_attempt else []),
                           stdin=subprocess.DEVNULL, capture_output=True, text=True)
        if error:
            self.assertNotEqual(p.returncode, 0)
            self.assertIn(error, p.stderr)
            self.assertFalse((self.out/'raw-samples.json').exists())
            return
        self.assertEqual(p.returncode, 0, p.stderr)
        return json.loads((self.out/'raw-samples.json').read_text())

    def test_valid_and_provenance(self):
        d = self.invoke()
        original = json.loads((self.physical/'raw-samples.json').read_text())
        self.assertEqual(d['configurations'][0], original['configurations'][0])
        candidate = d['configurations'][1]
        self.assertEqual(candidate['id'], 'android-emulator-v1')
        self.assertEqual(candidate['reference'], 'android-physical-v1')
        self.assertEqual(candidate['build']['artifact_sha256'], dict.fromkeys(SETS, 'd'*64))
        self.assertEqual(len(candidate['cases']), 14)
        for c in candidate['cases'].values():
            for attempts in c['sets'].values():
                self.assertEqual(len(attempts), 6)
                for a in attempts:
                    self.assertEqual(a['value_ns'], statistics.median(a['sample_means_ns']))
        provenance = json.loads((self.out/'provenance.json').read_text())
        paths = {x['path']: x['sha256'] for x in provenance['inputs']}
        expected = [*self.physical.rglob('*'), *self.ci.rglob('*'), self.build_path]
        for p in expected:
            if p.is_file():
                self.assertEqual(paths[str(p.resolve())], hashlib.sha256(p.read_bytes()).hexdigest())
        self.assertIn('--platform ios', (self.out/'README.md').read_text())

    def test_invalid_then_valid_retry(self):
        self.write_attempt(1, 'B1', 1, False, True)
        self.write_attempt(1, 'B1', 2)
        c = self.invoke()['configurations'][1]
        self.assertIsNone(c['blocking_reason'])
        for case in c['cases'].values():
            a = case['sets']['B1']
            self.assertEqual([x['valid'] for x in a[:2]], [False, True])
            self.assertEqual(len(a), 7)
            self.assertIsNone(a[0]['value_ns'])
            self.assertEqual(a[0]['sample_means_ns'], [101])

    def test_unresolved_after_retries(self):
        for a in range(1, 4):
            self.write_attempt(1, 'B1', a, False, True)
        c = self.invoke()['configurations'][1]
        self.assertIn('unresolved', c['blocking_reason'])
        for case in c['cases'].values():
            self.assertEqual(len(case['sets']['B1']), 8)
            self.assertEqual(sum(x['valid'] for x in case['sets']['B1']), 5)

    def test_pair_build_mismatch(self):
        d = json.loads(self.build_path.read_text()); d['binding_revision'] = 'e'*40
        put(self.build_path, d)
        self.invoke('mismatched build identity')

    def test_attempt_build_mismatch(self):
        p = self.ci/'runs/02-V-attempt-1/run.json'
        d = json.loads(p.read_text()); d['environment']['build']['core_revision'] = 'e'*40
        put(p, d)
        self.invoke('mismatched build identity')

    def test_wrong_executed_artifact(self):
        p = self.ci/'runs/02-V-attempt-1/run.json'
        d = json.loads(p.read_text()); d['runtime']['native_sha256'] = 'c'*64
        put(p, d)
        self.invoke('mismatched build identity')

    def test_duplicate_slot(self):
        shutil.copytree(self.ci/'runs/01-B1-attempt-1', self.ci/'runs/duplicate')
        self.invoke('duplicate slot')

    def test_missing_slot(self):
        shutil.rmtree(self.ci/'runs/01-B1-attempt-1')
        self.invoke('missing slot')

    def test_retry_of_valid_slot_refused(self):
        self.write_attempt(1, 'B1', 2)
        self.invoke('valid attempt retried')

    def add_physical_attempt(self, attempt, valid=True, value=200):
        path = self.physical/'raw-samples.json'
        doc = json.loads(path.read_text())
        for case in doc['configurations'][0]['cases'].values():
            case['sets']['B1'].append(dict(
                run_index=1, attempt=attempt, valid=valid,
                reason='' if valid else 'hand-abandoned',
                value_ns=value if valid else None))
        put(path, doc)

    def test_physical_retry_of_valid_slot_refused_by_default(self):
        self.add_physical_attempt(2)
        self.invoke('valid attempt retried')

    def test_earliest_valid_keeps_first_of_three_and_audits_later(self):
        self.add_physical_attempt(2, value=1)
        self.add_physical_attempt(3, value=300)
        path = self.physical/'raw-samples.json'
        original = path.read_bytes()
        source = json.loads(original)['configurations'][0]
        # Reverse input order to ensure selection uses attempt number alone.
        for case in source['cases'].values():
            case['sets']['B1'].reverse()
        put(path, dict(schema_version=1, synthetic=True, configurations=[source]))
        original = path.read_bytes()
        result = self.invoke(earliest_valid_attempt=True)
        self.assertEqual(result['policy'], 'earliest-valid-attempt')
        self.assertEqual(path.read_bytes(), original)
        expected = []
        for name in CASES:
            actual = result['configurations'][0]['cases'][name]['sets']
            before = source['cases'][name]['sets']
            self.assertEqual(actual['B1'], [x for x in before['B1'] if x['attempt'] == 1])
            self.assertEqual(actual['V'], before['V'])
            self.assertEqual(actual['B2'], before['B2'])
            for item in before['B1']:
                if item['attempt'] > 1:
                    expected.append(dict(platform=self.platform, config=source['id'], case=name,
                                         set='B1', **{k: item[k] for k in
                                         ('run_index', 'attempt', 'valid', 'reason', 'value_ns')}))
        self.assertEqual(result['superseded_attempts'], expected)
        self.assertIn('--earliest-valid-attempt', (self.out/'README.md').read_text())

    def test_earliest_valid_supersedes_abandoned_invalid(self):
        self.add_physical_attempt(2, valid=False)
        result = self.invoke(earliest_valid_attempt=True)
        self.assertEqual(len(result['superseded_attempts']), len(CASES))
        for item in result['superseded_attempts']:
            self.assertEqual(item['attempt'], 2)
            self.assertFalse(item['valid'])
            self.assertEqual(item['reason'], 'hand-abandoned')
            self.assertIsNone(item['value_ns'])
        for case in result['configurations'][0]['cases'].values():
            self.assertEqual(len(case['sets']['B1']), 6)
            self.assertTrue(all(x['attempt'] == 1 and x['valid'] for x in case['sets']['B1']))

    def test_earliest_valid_invalid_then_valid_then_valid(self):
        self.write_attempt(1, 'B1', 1, False, True)
        self.write_attempt(1, 'B1', 2)
        self.write_attempt(1, 'B1', 3)
        result = self.invoke(earliest_valid_attempt=True)
        candidate = result['configurations'][1]
        self.assertIsNone(candidate['blocking_reason'])
        for case in candidate['cases'].values():
            slot = [x for x in case['sets']['B1'] if x['run_index'] == 1]
            self.assertEqual([x['attempt'] for x in slot], [1, 2])
            self.assertEqual([x['valid'] for x in slot], [False, True])
        self.assertEqual(len(result['superseded_attempts']), len(CASES))
        for item in result['superseded_attempts']:
            self.assertEqual(item['config'], candidate['id'])
            self.assertEqual(item['attempt'], 3)
            self.assertTrue(item['valid'])

    def test_earliest_valid_gap_still_rejected(self):
        self.add_physical_attempt(3)
        self.invoke('retry gap', earliest_valid_attempt=True)

    def test_earliest_valid_ci_gap_still_rejected(self):
        self.write_attempt(1, 'B1', 3)
        self.invoke('retry gap', earliest_valid_attempt=True)

    def test_earliest_valid_duplicate_still_rejected(self):
        self.add_physical_attempt(1)
        self.invoke('duplicate slot attempt', earliest_valid_attempt=True)

    def test_earliest_valid_preserves_unresolved_slots(self):
        for a in range(1, 4):
            self.write_attempt(1, 'B1', a, False, True)
        result = self.invoke(earliest_valid_attempt=True)
        self.assertIn('unresolved', result['configurations'][1]['blocking_reason'])
        self.assertEqual(result['superseded_attempts'], [])
        for case in result['configurations'][1]['cases'].values():
            self.assertEqual(len(case['sets']['B1']), 8)

    def test_earliest_valid_without_later_attempts_unchanged(self):
        default = self.invoke()
        self.assertNotIn('policy', default)
        self.assertNotIn('superseded_attempts', default)
        self.out = self.base/'policy-out'
        result = self.invoke(earliest_valid_attempt=True)
        self.assertEqual(result['configurations'], default['configurations'])
        self.assertEqual(result['superseded_attempts'], [])

    def test_runtime_drift_refused(self):
        p = self.ci/'runs/02-V-attempt-1/runtime.json'
        d = json.loads(p.read_text()); d['runner_image'] = 'changed-image'
        put(p, d)
        self.invoke('runtime')

    def test_ios_synthetic(self):
        shutil.rmtree(self.ci)
        self.platform = 'ios'
        self.build.update(native_artifacts={'physical': {'sha256': 'c'*64, 'architecture': 'arm64'},
                                            'simulator': {'sha256': 'd'*64, 'architecture': 'arm64'}},
                          native_slices={'aarch64-apple-ios': 'c'*64, 'aarch64-apple-ios-sim': 'd'*64},
                          runner_image='macos15', runner_image_version='synthetic-image',
                          xcode='Xcode synthetic', host_architecture='arm64', translation='none',
                          simulator_device_type='com.apple.CoreSimulator.SimDeviceType.iPhone-15',
                          simulator_runtime='com.apple.CoreSimulator.SimRuntime.iOS-18-6',
                          simulator_runtime_build='synthetic-build', simulator_runtime_version='18.6')
        self.host.update(ImageOS='macos15', RUNNER_OS='macOS', RUNNER_ARCH='ARM64',
                         host_arch='arm64', schedule='B1,V,B2', core_revision='a'*40)
        self.make_fixture()
        (self.ci/'xcode-version.txt').write_text('Xcode synthetic')
        (self.ci/'sw-vers.txt').write_text('ProductVersion: synthetic\nBuildVersion: synthetic')
        put(self.ci/'selection.json', {k: v for k, v in self.build.items() if k.startswith('simulator_')})
        c = self.invoke()['configurations'][1]
        self.assertEqual(c['id'], 'ios-simulator-v1')
        self.assertEqual(c['build']['artifact_sha256']['V'], 'd'*64)
        self.assertEqual(c['runtime']['abi'], 'aarch64-apple-ios-sim')
        self.assertNotIn('udid', c['runtime'])


if __name__ == '__main__':
    unittest.main()

"""Fail-closed text and tar.gz scanner; diagnostics contain paths and rule IDs only.

Tar members are decompressed and scanned in memory, never extracted to disk.
Unsupported encodings, binary content, unreadable inputs, unsafe archive members,
and symlinks are failures, rather than silently skipped inputs.
"""
import argparse
import json
from pathlib import Path, PurePosixPath
import re
import stat
import sys
import tarfile
import zlib

UDID = re.compile(rb'00008[0-9A-Fa-f]{3}-[0-9A-Fa-f]{16}')
FIELD = re.compile(rb'''(?i)(serial(_number)?|udid)["']?\s*[:=]\s*["']?(?!REDACTED)[A-Za-z0-9_-]{6,}''')
FIELD_TOKEN = re.compile(rb'''(?i)(?:serial(?:_number)?|udid)["']?\s*[:=]\s*["']?([A-Za-z0-9_-]{6,})''')
# Capture a complete token before checking REDACTED (no prefix exemptions).
DESTINATION = re.compile(rb'''-destination id=(?:"[^"\r\n]*"|'[^'\r\n]*'|[^\s"'<>;,]+|)''')
RULES = (
    ('udid_pattern', UDID),
    ('serial_udid_field', FIELD),
    ('arn_account', re.compile(rb'''arn:aws[^\s"'<>]*[0-9]{12}[^\s"'<>]*''')),
    ('aws_signed_url', re.compile(rb'X-Amz-(?:Signature|Credential)', re.I)),
    ('local_home_path', re.compile(rb'/home/(?!runner/)')),
    ('local_tmp_path', re.compile(rb'/tmp/858')),
)


def load_extra(path):
    if path is None:
        return ()
    # Bytes are intentional: literals are not regexes and are never logged.
    return tuple(line for line in Path(path).read_bytes().splitlines() if line)


def text_bytes(data):
    try:
        text = data.decode('utf-8')
    except UnicodeError:
        return False
    return not any(ord(c) < 32 and c not in '\t\r\n\f\b\x1b' for c in text)


def scan_bytes(data, extra=()):
    hits = {name for name, pattern in RULES if pattern.search(data)}
    if any(match.group(1) != b'REDACTED' for match in FIELD_TOKEN.finditer(data)):
        hits.add('serial_udid_field')
    for match in DESTINATION.finditer(data):
        value = match.group().split(b'=', 1)[1].strip(b'"\'')
        if value != b'REDACTED':
            hits.add('destination_id')
    if any(literal in data for literal in extra):
        hits.add('extra_forbidden')
    return sorted(hits)


def safe_label(label, extra):
    data = label.encode('utf-8', errors='surrogatepass')
    if scan_bytes(data, extra) or not text_bytes(data):
        return '<redacted-path>'
    return label


def safe_member(name):
    p = PurePosixPath(name)
    return bool(name) and not p.is_absolute() and '..' not in p.parts and '\\' not in name and not re.match(r'^[A-Za-z]:', name)


def scan_path(path, extra=()):
    """Return (safe relative file/member name, rule) tuples, including I/O failures."""
    path = Path(path)
    findings = []

    def add(label, rule):
        findings.append((safe_label(label, extra), rule))

    def check(data, label):
        for rule in scan_bytes(data, extra):
            add(label, rule)
        if not text_bytes(data):
            add(label, 'binary_or_unsupported_encoding')

    def archive(file, label):
        seen = set()
        try:
            # Fully consume gzip to verify CRC/truncation, including its trailer.
            import gzip
            with gzip.open(file, 'rb') as stream:
                while stream.read(1024 * 1024):
                    pass
            with tarfile.open(file, 'r:gz') as tf:
                for member in tf:
                    member_label = label + '!' + member.name
                    check(member.name.encode('utf-8', errors='surrogatepass'), member_label)
                    for key, value in member.pax_headers.items():
                        check((key + '=' + value).encode('utf-8', errors='surrogatepass'), member_label)
                    for value in (member.uname, member.gname, member.linkname):
                        check(value.encode('utf-8', errors='surrogatepass'), member_label)
                    if not safe_member(member.name) or member.name in seen:
                        add(member_label, 'unsafe_archive_member')
                    seen.add(member.name)
                    if member.isdir():
                        continue
                    if not member.isfile():
                        add(member_label, 'unsupported_archive_member')
                        continue
                    stream = tf.extractfile(member)
                    if stream is None:
                        add(member_label, 'archive_read_error')
                        continue
                    with stream:
                        data = stream.read()
                    if len(data) != member.size:
                        add(member_label, 'archive_read_error')
                    check(data, member_label)
                for key, value in tf.pax_headers.items():
                    check((key + '=' + value).encode('utf-8', errors='surrogatepass'), label)
        except (OSError, ValueError, EOFError, tarfile.TarError, UnicodeError, zlib.error):
            add(label, 'archive_read_error')

    def visit(file, label):
        try:
            mode = file.lstat().st_mode
            for rule in scan_bytes(label.encode('utf-8', errors='surrogatepass'), extra):
                add(label, rule)
            if stat.S_ISLNK(mode):
                add(label, 'symlink')
            elif stat.S_ISDIR(mode):
                for child in sorted(file.iterdir()):
                    visit(child, child.name if label == '.' else label + '/' + child.name)
            elif stat.S_ISREG(mode):
                if file.name.endswith(('.tgz', '.tar.gz')):
                    archive(file, label)
                else:
                    check(file.read_bytes(), label)
            else:
                add(label, 'unsupported_file')
        except (OSError, ValueError):
            add(label, 'file_read_error')

    visit(path, '.' if path.is_dir() else path.name)
    return sorted(set(findings))


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('paths', nargs='+', type=Path)
    parser.add_argument('--extra-forbidden-file', type=Path)
    args = parser.parse_args(argv)
    try:
        extra = load_extra(args.extra_forbidden_file)
    except (OSError, ValueError):
        print('<extra-forbidden-file>\textra_file_read_error')
        return 1
    findings = []
    for path in args.paths:
        findings.extend(scan_path(path, extra))
    for label, rule in findings:
        print(json.dumps(label, ensure_ascii=True) + '\t' + rule)
    print('scan_hits=' + str(len(findings)))
    return int(bool(findings))


if __name__ == '__main__':
    sys.exit(main())

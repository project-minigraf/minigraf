"""Read-only reference validation; never print numerical or decision results."""
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

sys.dont_write_bytecode = True
root = Path('/tmp/858-rebuild/tools')
reference = Path('<local-path>')
spec = importlib.util.spec_from_file_location('qualification_decide', reference)
decide = importlib.util.module_from_spec(spec)
spec.loader.exec_module(decide)
doc = decide.load_raw(root/'out-android')
physical, candidate = doc['configurations']
assert not decide.build_errors(physical, candidate), 'reference build/runtime validation failed'
summary = []
for config in doc['configurations']:
    assert set(config['cases']) == set(decide.CATEGORIES), 'case IDs differ from reference'
    structure = None
    for case in config['cases'].values():
        current = {}
        for set_name, attempts in case['sets'].items():
            _, audit, errors = decide.extract_attempts(attempts)
            assert not errors, 'reference attempt validator found errors'
            current[set_name] = [(a['run_index'], a['attempt'], a['valid']) for a in attempts]
        assert structure is None or current == structure, 'case attempt structure differs'
        structure = current
    attempts = [(s, *a) for s, items in structure.items() for a in items]
    summary.append(dict(id=config['id'], cases=len(config['cases']),
                        slots=len({(s, i) for s, i, a, valid in attempts}),
                        attempts=len(attempts), valid=sum(valid for s, i, a, valid in attempts),
                        invalid=sum(not valid for s, i, a, valid in attempts)))
# decide() is the reference structural validator as well as decision engine.
# Its return value is deliberately neither printed nor inspected for outcomes.
decide.decide(doc)
with (root/'decide.stderr').open('w') as error_log:
    result = subprocess.run([sys.executable, '-B', str(reference), str(root/'out-android'),
                             '--output', str(root/'android-decision')],
                            stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=error_log)
assert result.returncode == 0, 'decide.py CLI failed; stderr retained without display'
verification = dict(configurations=summary, reference_loader_validator='accepted', decide_exit_code=result.returncode)
(root/'verification.json').write_text(json.dumps(verification, indent=2) + '\n')
print(json.dumps(verification, indent=2))

#!/usr/bin/env python3
"""Assemble SCHEMA v1 mobile decision input offline, using Python stdlib only.

The physical fragment is preserved, not recollected. CI run.json supplies the
collector's whole-stream validity; raw logs remain checksummed evidence. This
program does not reclassify failed streams or select observations by value.
"""
import argparse
import copy
import hashlib
import json
import math
from pathlib import Path
import re
import shlex
import statistics
import sys

SETS = ('B1', 'V', 'B2')
CASES = ('prepared_execute/1k', 'cursor_batch_1/1k', 'cursor_batch_256/1k',
         'set_roundtrip/2', 'predicate/1k', 'aggregate/1k', 'prepare/point',
         'register_predicate/first', 'register_aggregate/first',
         'fact_log_batch_256/1k', 'options_error/negative_cache',
         'options_readonly_open/1k', 'file_transact/1k', 'log_writer_append_finish/1k')
IDENTITY = ('core_revision', 'binding_revision', 'harness_revision', 'profile', 'slowdown_flag')
SIM_PINS = ('simulator_device_type', 'simulator_runtime',
            'simulator_runtime_build', 'simulator_runtime_version')
SANDBOX = Path('/tmp/858-rebuild/tools')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def unique_pairs(pairs):
    obj = {}
    for key, value in pairs:
        require(key not in obj, 'duplicate JSON key: ' + key)
        obj[key] = value
    return obj


def read_json(path):
    try:
        return json.loads(path.read_text(encoding='utf-8'), object_pairs_hook=unique_pairs,
                          parse_constant=lambda _: (_ for _ in ()).throw(ValueError('nonfinite JSON token')))
    except (ValueError, OSError) as error:
        raise ValueError('cannot read ' + str(path) + ': ' + str(error)) from error


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def pin(value, label):
    if isinstance(value, (dict, list)):
        value = json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)
    elif isinstance(value, bool):
        value = 'true' if value else 'false'
    elif value is not None:
        value = str(value)
    require(isinstance(value, str) and value.strip() and 'TODO' not in value,
            'missing/unpinned runtime: ' + label)
    return value.strip()


def equal(actual, expected, label, category='mismatched build identity'):
    require(actual == expected, category + ': ' + label)


def check_identity(build, expected=None, partial=False):
    require(isinstance(build, dict), 'mismatched build identity: absent build manifest')
    for field in IDENTITY:
        if partial and field not in build:
            continue
        v = build.get(field)
        if field.endswith('_revision'):
            require(isinstance(v, str) and re.fullmatch('[0-9a-f]{40}', v),
                    'mismatched build identity: invalid ' + field)
        else:
            equal(v, 'Release' if field == 'profile' else 'repeat-timed-operation-twice', field)
        if expected is not None:
            equal(v, expected[field], field)
    if partial:
        for field in IDENTITY[:3]:
            equal(build.get(field), expected[field], field)


def artifact(build, platform, physical=False):
    key = ('arm64-v8a' if physical else 'x86_64') if platform == 'android' else ('physical' if physical else 'simulator')
    entry = build.get('native_artifacts', {}).get(key, {})
    sha = entry.get('sha256')
    require(isinstance(sha, str) and re.fullmatch('[0-9a-f]{64}', sha),
            'mismatched build identity: absent executed artifact for ' + key)
    if platform == 'ios':
        slice_key = 'aarch64-apple-ios' if physical else 'aarch64-apple-ios-sim'
        equal(build.get('native_slices', {}).get(slice_key), sha, slice_key)
        equal(entry.get('architecture'), 'arm64', key + ' architecture')
    return sha


def validate_attempt(item, label, samples_required=False):
    require(isinstance(item, dict), label + ': attempt must be an object')
    i, a = item.get('run_index'), item.get('attempt')
    require(type(i) is int and 1 <= i <= 6 and type(a) is int and 1 <= a <= 3,
            label + ': slot/attempt outside registered bounds')
    require(type(item.get('valid')) is bool and isinstance(item.get('reason'), str),
            label + ': missing valid flag or reason')
    require('value_ns' in item, label + ': missing value_ns')
    if item['valid']:
        value = item['value_ns']
        require(type(value) in (int, float) and math.isfinite(value) and value > 0,
                label + ': invalid run value')
        samples = item.get('sample_means_ns')
        if samples is not None or samples_required:
            require(isinstance(samples, list) and len(samples) == 10 and all(
                type(v) in (int, float) and math.isfinite(v) and v > 0 for v in samples),
                label + ': valid stream must have ten finite positive sample means')
            require(statistics.median(samples) == value, label + ': inconsistent sample median')
    else:
        require(bool(item['reason'].strip()) and item['value_ns'] is None,
                label + ': invalid attempt needs reason and null value_ns')
    return i, a


def validate_slots(attempts, label, earliest_valid_attempt=False):
    slots = {i: [] for i in range(1, 7)}
    seen = set()
    for item in attempts:
        i, a = item['run_index'], item['attempt']
        require((i, a) not in seen, 'duplicate slot attempt: ' + label)
        seen.add((i, a))
        slots[i].append(item)
    unresolved = []
    for i, items in slots.items():
        require(items, 'missing slot: %s/%d' % (label, i))
        items.sort(key=lambda x: x['attempt'])
        require([x['attempt'] for x in items] == list(range(1, len(items)+1)),
                'missing slot attempt or retry gap: ' + label)
        if not earliest_valid_attempt:
            require(not any(x['valid'] for x in items[:-1]), 'valid attempt retried: ' + label)
        if not any(x['valid'] for x in items):
            unresolved.append('%s/%d' % (label, i))
    return unresolved


def physical_fragment(directory, platform, build, earliest_valid_attempt=False):
    doc = read_json(directory / 'raw-samples.json')
    require(type(doc.get('schema_version')) is int and doc['schema_version'] == 1
            and type(doc.get('synthetic')) is bool, 'physical fragment must use SCHEMA version 1')
    configs = doc.get('configurations')
    require(isinstance(configs, list) and len(configs) == 1,
            'physical fragment must contain exactly one configuration')
    physical = configs[0]
    require(physical.get('platform') == platform and physical.get('kind') == 'physical'
            and physical.get('reference') is None, 'physical platform/kind/reference mismatch')
    require(isinstance(physical.get('id'), str) and re.fullmatch('[a-z0-9][a-z0-9-]*', physical['id']),
            'invalid physical configuration id')
    check_identity(physical.get('build'), build)
    expected_hash = artifact(build, platform, physical=True)
    for s in SETS:
        equal(physical['build'].get('artifact_sha256', {}).get(s), expected_hash, 'physical artifact ' + s)
    if (directory/'build.json').exists():
        physical_build = read_json(directory/'build.json')
        check_identity(physical_build, build)
        equal(artifact(physical_build, platform, physical=True), expected_hash, 'physical build artifact')
    require(isinstance(physical.get('runtime'), dict) and physical['runtime'], 'missing physical runtime')
    for k, v in physical['runtime'].items():
        require(isinstance(v, str), 'physical runtime must contain strings')
        pin(v, k)
    require(set(physical.get('cases', {})) == set(CASES), 'missing or unknown physical case')
    first_structure = None
    for case in CASES:
        entry = physical['cases'][case]
        require(set(entry.get('sets', {})) == set(SETS), 'missing or unknown physical set')
        structure = {}
        for s in SETS:
            items = entry['sets'][s]
            require(isinstance(items, list), 'physical attempts must be a list')
            for item in items:
                validate_attempt(item, 'physical/' + case + '/' + s)
            validate_slots(items, 'physical/' + s, earliest_valid_attempt)
            structure[s] = sorted((x['run_index'], x['attempt'], x['valid'], x['reason']) for x in items)
        if first_structure is None:
            first_structure = structure
        equal(structure, first_structure, 'inconsistent physical whole-stream validity', 'invalid attempts')
    return doc, physical


def host_pins(ci, platform, build):
    host = read_json(ci/'host.json')
    for key in ('GITHUB_SHA', 'GITHUB_WORKFLOW_SHA'):
        equal(host.get(key), build['binding_revision'], 'host ' + key)
    equal(host.get('runs_per_set'), 6, 'runs per set', 'protocol mismatch')
    equal(host.get('retries_per_slot'), 2, 'retry cap', 'protocol mismatch')
    if 'core_revision' in host:
        equal(host['core_revision'], build['core_revision'], 'host core revision')
    for config_path in (ci/'resolved-config.json', ci/'runs/config.json'):
        if config_path.exists():
            cfg = read_json(config_path)
            equal(cfg.get('core_ref'), build['core_revision'], 'resolved core revision')
            equal(cfg.get('schedule'), 'B1,V,B2', 'schedule', 'protocol mismatch')
            equal(cfg.get('collect'), True, 'collection enabled', 'protocol mismatch')
    if 'schedule' in host:
        equal(host['schedule'], 'B1,V,B2', 'host schedule', 'protocol mismatch')
    runtime = {'provider': 'GitHub Actions', 'runner_label': 'ubuntu-24.04' if platform == 'android' else 'macos-15'}
    for dest, source in (('runner_image', 'ImageOS'), ('runner_image_version', 'ImageVersion'),
                         ('runner_os', 'RUNNER_OS'), ('runner_arch', 'RUNNER_ARCH')):
        runtime[dest] = pin(host.get(source), source)
    if platform == 'android':
        for key in ('host_arch', 'host_kernel'):
            runtime[key] = pin(host.get(key), key)
        for key, name in (('emulator_version_evidence', 'emulator-version.txt'),
                          ('acceleration_evidence', 'accel-check.txt'), ('avd_evidence', 'avd-list.txt')):
            runtime[key] = pin((ci/name).read_text(), name)
        require((ci/'resolved-config.json').exists(), 'missing resolved-config.json')
    else:
        for field, key in (('runner_image', 'ImageOS'), ('runner_image_version', 'ImageVersion')):
            equal(build.get(field), host[key], field, 'runtime mismatch')
        runtime['xcode'] = pin(build.get('xcode'), 'xcode')
        equal((ci/'xcode-version.txt').read_text().strip(), runtime['xcode'], 'Xcode', 'runtime mismatch')
        runtime['host_os'] = pin((ci/'sw-vers.txt').read_text(), 'sw-vers')
        runtime['host_arch'] = pin(build.get('host_architecture'), 'host_architecture')
        equal(runtime['host_arch'], 'arm64', 'host architecture', 'runtime mismatch')
        equal(host['RUNNER_ARCH'], 'ARM64', 'runner architecture', 'runtime mismatch')
        runtime['translation'] = pin(build.get('translation'), 'translation')
        runtime['abi'] = 'aarch64-apple-ios-sim'
        selection = read_json(ci/'selection.json')
        for k in SIM_PINS:
            runtime[k] = pin(build.get(k), k)
            equal(selection.get(k), build[k], k, 'runtime mismatch')
    return host, runtime


def android_pins(data, host):
    equal(data.get('runner_image'), host['ImageVersion'], 'runner image', 'runtime mismatch')
    for key in ('host_arch', 'host_kernel'):
        equal(data.get(key), host[key], key, 'runtime mismatch')
    for key in ('kvm_present', 'acceleration_active'):
        equal(data.get(key), True, key, 'runtime mismatch')
    equal(data.get('accel_check_exit'), 0, 'acceleration check', 'runtime mismatch')
    equal(data.get('backend'), 'KVM', 'acceleration backend', 'runtime mismatch')
    require('/dev/kvm' in data.get('live_kvm_fd_targets', []), 'runtime: missing live KVM evidence')
    guest = data.get('guest', {})
    equal(guest.get('ro.product.cpu.abi'), 'x86_64', 'guest ABI', 'runtime mismatch')
    equal(data.get('host_arch'), 'x86_64', 'host ABI', 'runtime mismatch')
    pins = {k: pin(data.get(k), k) for k in (
        'emulator_version', 'emulator_package', 'image', 'system_image_package', 'device_profile',
        'backend', 'kvm_present', 'acceleration_active', 'accel_check_output', 'live_kvm_fd_targets',
        'translation', 'boot_policy')}
    for dest, source in (('abi', 'ro.product.cpu.abi'), ('api_level', 'ro.build.version.sdk'),
                         ('os', 'ro.build.version.release'), ('fingerprint', 'ro.build.fingerprint')):
        pins[dest] = pin(guest.get(source), source)
    for key in ('Pkg.Revision', 'AndroidVersion.ApiLevel', 'SystemImage.Abi'):
        pin(data.get('system_image_package', {}).get(key), key)
    equal(data['system_image_package']['SystemImage.Abi'], pins['abi'], 'system image ABI', 'runtime mismatch')
    equal(data['system_image_package']['AndroidVersion.ApiLevel'], pins['api_level'], 'system image API', 'runtime mismatch')
    return pins


def check_run_identity(run, platform, build, sha, s, runtime):
    env, live = run.get('environment'), run.get('runtime')
    if run['valid']:
        require(isinstance(env, dict) and isinstance(live, dict), 'mismatched build identity: valid stream lacks identity')
    if env is not None:
        check_identity(env.get('build'), build, partial=True)
        equal(env.get('profile'), 'Release', 'executing profile')
        equal(env.get('double_work'), s == 'V', 'enabled slowdown flag')
        equal(env.get('variant'), 'slowdown' if s == 'V' else 'baseline', 'variant')
        equal(env.get('mode'), 'qualification', 'stream mode')
        equal(env.get('platform'), 'emulator' if platform == 'android' else 'simulator', 'executing platform')
        actual_sha = env.get('native_sha256') if platform == 'android' else env['build'].get('native_sha256')
        equal(actual_sha, sha, 'executing native artifact')
        if platform == 'android':
            equal(env.get('loaded_abi'), 'x86_64', 'loaded ABI')
        else:
            for k in ('simulator_device_type', 'simulator_runtime'):
                equal(env.get(k), runtime[k], k, 'runtime mismatch')
    if live is not None:
        equal(live.get('platform'), 'emulator' if platform == 'android' else 'simulator', 'live platform', 'runtime mismatch')
        if platform == 'android':
            equal(live.get('native_sha256'), sha, 'live native artifact')
            for key, dest in (('loaded_abi', 'abi'), ('sdk', 'api_level'), ('os', 'os'), ('fingerprint', 'fingerprint')):
                equal(str(live.get(key)), runtime[dest], key, 'runtime mismatch')
        else:
            equal(live.get('compiled_simulator'), True, 'compiled simulator', 'runtime mismatch')
            equal(live.get('architecture'), 'arm64', 'simulator architecture', 'runtime mismatch')
            for key in SIM_PINS:
                equal(live.get(key), runtime[key], key, 'runtime mismatch')
    # Existing failed runs without an emitted identity remain failed. Never
    # invent identity/values for them or extract a replacement from their log.


def candidate_config(ci, platform, build, physical, earliest_valid_attempt=False):
    sha = artifact(build, platform)
    host, runtime = host_pins(ci, platform, build)
    candidate = dict(id=platform + ('-emulator-v1' if platform == 'android' else '-simulator-v1'),
                     platform=platform, kind='simulated', reference=physical['id'], blocking_reason=None,
                     build={**{k: build[k] for k in IDENTITY}, 'artifact_sha256': dict.fromkeys(SETS, sha)},
                     runtime=runtime,
                     cases={c: {'blocking_reason': None, 'sets': {s: [] for s in SETS}} for c in CASES})
    runs_dir = ci/'runs'
    require(runs_dir.is_dir(), 'missing slot directory: ' + str(runs_dir))
    dirs = [p for p in sorted(runs_dir.iterdir()) if p.is_dir() and p.name != 'smoke']
    manifests, seen = [], set()
    # First pass catches duplicate metadata even if a directory was renamed.
    for p in dirs:
        meta = read_json(p/'attempt.json')
        i, s, a = meta.get('run_index'), meta.get('set'), meta.get('attempt')
        require(type(i) is int and 1 <= i <= 6 and s in SETS and type(a) is int and 1 <= a <= 3,
                'slot/attempt outside registered bounds: ' + str(p))
        require((i, s, a) not in seen, 'duplicate slot attempt: ' + str(p))
        seen.add((i, s, a))
        manifests.append((i, SETS.index(s), a, p, meta))
    for i in range(1, 7):
        for s in SETS:
            require(any(t[:2] == (i, s) for t in seen), 'missing slot: %s/%d' % (s, i))
    pins = None
    audit = []
    slot_attempts = {s: [] for s in SETS}
    for i, _, a, p, meta in sorted(manifests):
        s = meta['set']
        require(p.name == '%02d-%s-attempt-%d' % (i, s, a), 'directory/slot mismatch: ' + str(p))
        run = read_json(p/'run.json')
        equal(run.get('set'), s, 'run set', 'slot mismatch')
        require(type(run.get('valid')) is bool, 'run validity must be boolean')
        require(type(meta.get('valid')) is bool, 'attempt validity must be boolean')
        equal(run['valid'], meta['valid'], 'whole-stream validity', 'invalid attempts')
        require(isinstance(run.get('reason'), str) and isinstance(meta.get('reason'), str), 'missing attempt reason')
        equal(run['reason'], meta['reason'], 'attempt reason', 'invalid attempts')
        require(run['valid'] or run['reason'].strip(), 'invalid attempt needs a reason')
        if run['valid']:
            equal(meta.get('exit_code'), 0, 'valid attempt exit code', 'invalid attempts')
        if platform == 'android':
            observed = android_pins(read_json(p/'runtime.json'), host)
            if pins is None:
                pins = observed
                runtime.update(observed)
            equal(observed, pins, 'attempt configuration changed', 'runtime mismatch')
        else:
            equal(meta.get('runner_image'), host['ImageVersion'], 'attempt image', 'runtime mismatch')
            for k in SIM_PINS:
                equal(meta.get('simulator', {}).get(k), runtime[k], 'attempt ' + k, 'runtime mismatch')
            if (p/'runtime.json').exists():
                extra = read_json(p/'runtime.json')
                for k in SIM_PINS:
                    if k in extra:
                        equal(extra[k], runtime[k], 'attempt runtime ' + k, 'runtime mismatch')
        check_run_identity(run, platform, build, sha, s, runtime)
        cases = run.get('cases')
        require(isinstance(cases, dict) and not set(cases)-set(CASES), 'unknown or invalid CI cases')
        if run['valid']:
            require(set(cases) == set(CASES), 'valid run missing cases')
        for c in CASES:
            item = copy.deepcopy(cases.get(c, dict(run_index=i, attempt=a, valid=False,
                                                 reason=run['reason'], value_ns=None)))
            for k, v in (('run_index', i), ('attempt', a), ('valid', run['valid']), ('reason', run['reason'])):
                equal(item.get(k), v, 'case ' + k, 'inconsistent whole-stream attempts')
            validate_attempt(item, str(p) + '/' + c, samples_required=True)
            if item['valid']:
                item['value_ns'] = statistics.median(item['sample_means_ns'])
            candidate['cases'][c]['sets'][s].append(item)
        slot_attempts[s].append(dict(run_index=i, attempt=a, valid=run['valid']))
        audit.append({'path': str(p), 'run_index': i, 'set': s, 'attempt': a, 'valid': run['valid'],
                      'identity_present': run.get('environment') is not None})
    unresolved = []
    for s in SETS:
        unresolved.extend(validate_slots(slot_attempts[s], s, earliest_valid_attempt))
    if unresolved:
        candidate['blocking_reason'] = 'unresolved CI slots (all attempts retained): ' + ', '.join(unresolved)
    return candidate, audit


def select_earliest_valid(configurations):
    """Retain invalid predecessors and the first valid attempt in each slot.

    Called only after validating every original attempt and slot. Audit values
    are copied verbatim, never consulted to choose an attempt.
    """
    superseded = []
    for config in configurations:
        for case, entry in config['cases'].items():
            for s, items in entry['sets'].items():
                first_valid = {}
                for item in items:
                    if item['valid']:
                        i, a = item['run_index'], item['attempt']
                        first_valid[i] = min(first_valid.get(i, a), a)
                retained = []
                for item in items:
                    first = first_valid.get(item['run_index'])
                    if first is not None and item['attempt'] > first:
                        superseded.append(dict(
                            platform=config['platform'], config=config['id'], case=case, set=s,
                            **{k: copy.deepcopy(item[k]) for k in
                               ('run_index', 'attempt', 'valid', 'reason', 'value_ns')}))
                    else:
                        retained.append(item)
                entry['sets'][s] = retained
    return superseded


def inventory(physical_dir, ci, build_path):
    paths = {build_path}
    for root in (physical_dir, ci):
        require(root.is_dir(), 'missing input directory: ' + str(root))
        for p in root.rglob('*'):
            require(not p.is_symlink(), 'input symlinks are not supported: ' + str(p))
            if p.is_file():
                paths.add(p)
    return [{'path': str(p), 'sha256': digest(p)} for p in sorted(paths)]


def readme(args):
    command = shlex.join(['python3', '-B', str(Path(__file__).resolve()), '--platform', args.platform,
                          '--physical-dir', str(args.physical_dir), '--ci-evidence', str(args.ci_evidence),
                          '--build-json', str(args.build_json), '--out', str(args.out)]
                         + (['--earliest-valid-attempt'] if args.earliest_valid_attempt else []))
    retention = ('The earliest-valid-attempt policy retains invalid predecessors and the first\n'
                 'valid attempt by attempt number in each slot. Later attempts are excluded\n'
                 'from decision input and copied to the top-level superseded_attempts audit\n'
                 '(one entry per case); audit values are not used in computation. Slots\n'
                 'without a valid attempt retain all attempts. Physical source files are unchanged.\n'
                 'Retained valid CI values are exact medians of the ten original sample means.'
                 if args.earliest_valid_attempt else
                 'The physical configuration is retained unchanged. All CI\n'
                 'attempts are retained; valid values are exact medians of the ten original\n'
                 'sample means.')
    retry_error = '' if args.earliest_valid_attempt else 'retries of valid runs, '
    return f'''# Offline mobile decision input

SCHEMA.md version 1. {retention} Invalid/partial streams stay invalid. No statistics or decisions
are printed by the assembler. A successful assembly is not qualification.

Reproduce this assembly:

```sh
{command} < /dev/null
```

Assemble iOS later (replace the three quoted placeholders with actual paths;
choose the fresh collection under /tmp/qs3, never the defective /tmp/qs2 run):

```sh
python3 -B /tmp/858-rebuild/tools/assemble.py --platform ios --physical-dir '<dir>' --ci-evidence '<dir>' --build-json '<file>' --out /tmp/858-rebuild/tools/out-ios < /dev/null
```

The physical directory must contain its SCHEMA v1 raw-samples.json fragment.
The CI directory is the qualification-evidence directory containing host.json
and runs/NN-SET-attempt-K. For iOS it also contains selection.json,
xcode-version.txt and sw-vers.txt. Use that same fresh collection's
binding/bench/device-farm/build/dist/build.json for --build-json. It must match
the uploaded package used for the physical collection. Android instead uses
binding/bench/device-farm/build/evidence/build.json. Native hashes come from
the executed x86_64 library / aarch64-apple-ios-sim slice, independently of the
physical artifact. Runtime pins come from actual evidence, not protocol examples.
The evidence pins still need review against the pre-registration.

Only /tmp/858-rebuild/tools is writable. Input and output directories must be
disjoint; existing result files are refused, so use a fresh output directory.
provenance.json lists SHA-256 for every file under both input directories and
the supplied build manifest, plus the assembler's own hash. Raw logs and failed
streams remain in their original locations; this output is not an archive copy.
The assembler checks available emitted identities even on failed attempts;
failed attempts without an emitted identity are recorded as such in provenance.
It does not reparse or repair collector validity from raw logs. Missing slots,
duplicate attempts, {retry_error}identity mismatches and runtime drift
are errors. Present unresolved slots remain present with an explicit blocker.
'''


def assemble(args):
    for key in ('physical_dir', 'ci_evidence', 'build_json', 'out'):
        setattr(args, key, Path(getattr(args, key)).resolve())
    require(args.out == SANDBOX or SANDBOX in args.out.parents, 'output must be under /tmp/858-rebuild/tools/')
    for root in (args.physical_dir, args.ci_evidence):
        require(args.out != root and root not in args.out.parents and args.out not in root.parents,
                'input/output directories must be disjoint')
    require(args.build_json != args.out and args.out not in args.build_json.parents, 'build manifest overlaps output')
    for name in ('raw-samples.json', 'provenance.json', 'README.md'):
        require(not (args.out/name).exists() and not (args.out/name).is_symlink(), 'output already exists: ' + str(args.out/name))
    inputs = inventory(args.physical_dir, args.ci_evidence, args.build_json)
    build = read_json(args.build_json)
    check_identity(build)
    physical_doc, physical = physical_fragment(args.physical_dir, args.platform, build, args.earliest_valid_attempt)
    candidate, audit = candidate_config(args.ci_evidence, args.platform, build, physical, args.earliest_valid_attempt)
    result = {**physical_doc, 'configurations': [physical, candidate]}
    if args.earliest_valid_attempt:
        result['policy'] = 'earliest-valid-attempt'
        result['superseded_attempts'] = select_earliest_valid(result['configurations'])
    provenance = dict(schema_version=1, platform=args.platform, inputs=inputs,
                      assembler={'path': str(Path(__file__).resolve()), 'sha256': digest(Path(__file__))},
                      ci_attempts=audit)
    # Serialize before making output files; reject nonfinite partial data too.
    output_text = json.dumps(result, sort_keys=True, indent=2, allow_nan=False) + '\n'
    provenance_text = json.dumps(provenance, sort_keys=True, indent=2, allow_nan=False) + '\n'
    require(inventory(args.physical_dir, args.ci_evidence, args.build_json) == inputs,
            'inputs changed during assembly; retry from a stable collection')
    args.out.mkdir(parents=True, exist_ok=True)
    for name, text in (('raw-samples.json', output_text), ('provenance.json', provenance_text), ('README.md', readme(args))):
        with (args.out/name).open('x', encoding='utf-8', newline='\n') as dest:
            dest.write(text)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--platform', choices=('android', 'ios'), required=True)
    parser.add_argument('--earliest-valid-attempt', action='store_true',
                        help='keep the first valid attempt by number per slot and audit later attempts')
    for option in ('physical-dir', 'ci-evidence', 'build-json', 'out'):
        parser.add_argument('--' + option, required=True)
    args = parser.parse_args()
    try:
        assemble(args)
    except (ValueError, OSError, TypeError, KeyError, OverflowError) as error:
        print('assemble: ' + str(error), file=sys.stderr)
        return 2
    return 0


if __name__ == '__main__':
    sys.exit(main())

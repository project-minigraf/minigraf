# Device Farm response audit

The six JSON fixtures copy the shapes of every response supplied in
`/tmp/858-rebuild/tools-real/`. Only two redactions are normalized: bare `ACCT` in
numeric `device.memory` becomes `0` so the files are valid JSON; signed
`run.parsingResultUrl` values become `URL`. The driver never reads either field.
`android-smoke.logcat` retains the actual MinigrafBench threadtime lines from
`/tmp/smk-and2/io.github.proj_verifyAndMeasu_Logcat.logcat`, plus a log header.
The real-response tests load the original files when available, check the
fixture copies, and otherwise use these retained copies.

| Response | Every consumed field / assumption | Audit result |
| --- | --- | --- |
| get-device | `device.model`, `os`, `platform`; optional `manufacturer` | Provider model is `Google Pixel 7`, OS `14`, platform `ANDROID`, manufacturer `Google`. User also confirmed `Apple iPhone 15` / `18.5` / `IOS` / Apple. Strict provider identity now uses those values. Runtime JSON still uses the harness's separate model naming. |
| get-run | `run.status`, `result`, `created`, `started`, `stopped`, `deviceMinutes.total` | Both captures use `COMPLETED` / `PASSED`, ISO timestamp strings, and nested minute totals. Existing parsing agrees. Total is deliberately not metered minutes. `counters.total=3` includes setup/test/teardown and must not be interpreted as three benchmark tests; counters are not consumed by the driver. |
| list-jobs | `jobs[].arn`, `result`, `status`, nested `device`, `deviceMinutes.total`, optional timestamps | Nested device has the same provider identity shape. Fake jobs now copy the captured object, including counters and timestamp fields; missing started/stopped remains acceptable. |
| list-suites | `suites[].arn`, `result` | Three suites: Setup Suite, benchmark class, Teardown Suite. Fixture now preserves all three, names, counters, timestamps, status, minutes and messages. All suites/tests still participate in provider failure checks. |
| list-tests | `tests[].arn`, `name`, `result`, optional started/stopped | No capture supplied. Synthetic tests use resource paths implied by captured artifact ARNs and method-only names; selection accepts the exact method, optionally `()`, or the full pinned filter. Missing/ambiguous selected tests cannot supply a stream. |
| list-artifacts | `artifacts[].arn`, `name`, `type`, `extension`, `url` | Listing categories FILE/LOG/SCREENSHOT differ from returned artifact types: DEVICE_LOG, INSTRUMENTATION_OUTPUT, VIDEO, RAW_FILE. Logcat has extension `logcat`; instrumentation has `AndroidFileExtensions.instrumentation_output`. All are retained as supplied. The old fake returned type LOG and name app-output. |
| get-upload | `upload.status`, `type` | No capture supplied. Existing SUCCEEDED and platform-specific IOS_APP/XCTEST_TEST_PACKAGE or ANDROID_APP/INSTRUMENTATION_TEST_PACKAGE checks retained; fixtures remain synthetic. |
| get-device-pool | `devicePool.rules[].attribute`, `operator`, JSON-encoded `value` | No capture supplied. Existing singleton ARN/IN rule validation retained; fixture remains synthetic. Public device ARN has an empty account segment, matching get-device. |
| schedule-run | `run.arn` | No capture supplied. Fixture copies the captured run shape, substitutes a unique ARN/name, and models initial SCHEDULING/PENDING rather than immediate completion. These initial enum values remain synthetic; only run.arn is consumed. |
| list-runs / pagination | `runs[].name`, `arn`; list keys and `nextToken` | No capture of list-runs or pagination supplied. Synthetic pagination and intent-recovery tests retained. |

Artifact ownership is determined from the captured hierarchy:
`artifact:<project>/<run>/<job>/<suite>/<test>/<artifact>` maps to
`test:<project>/<run>/<job>/<suite>/<test>`. The first listing that returns an
artifact may be run/job-wide, so listing resource alone cannot identify its
owning test. Only artifacts owned by the selected method supply candidates;
Android additionally requires DEVICE_LOG / Logcat and extracts only
`<date> <time> <pid> <tid> I MinigrafBench: {json}` records. Setup/teardown and
Instrumentation Output cannot substitute for the selected test's Logcat.
The old content-only scan ignored ownership and source type.

Artifact filenames already had a unique numeric prefix; this is retained and
regression-tested with multiple identical Logcat names, including two distinct
artifacts for the selected test. Each retained file now also records its
artifact ARN, and each artifact records whether it is an eligible stream source.
Mirrored complete streams are not concatenated. Conflicting selected streams
still fail validation.

No network requests or real AWS operations were used in this audit. Operations
without supplied captures are explicitly unverified against live responses.

"""Rebuild sanitized evidence bundles using only the supplied retention lists.

Input files are read-only. Outputs are staged beneath --out and published only
after the independent scanner succeeds. No source content is printed on errors.
"""
import argparse
import gzip
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import re
import stat
import subprocess
import sys
import tarfile
import tempfile

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('archive_scanner', HERE / 'scan_archive.py')
scanner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(scanner)
SOURCE_PREFIX = '<evidence-root>/'
TOOLS_PREFIX = '/tmp/858-rebuild/tools/'
LIST_ROOT = Path('<scratchpad>')
FIELD_VALUE = re.compile(rb'''(?i)((?:serial(?:_number)?|udid)["']?\s*[:=]\s*["']?)[A-Za-z0-9_-]+''')
# Recognize Unix, drive-letter, UNC and file:// paths, excluding normal URLs.
ABSOLUTE = re.compile(r'''(?:^|[\s"'`(<\[=:])/(?=[^\s"'`)>\],;])|(?:^|[\s"'`(<\[=:])[A-Za-z]:[\\/]|\\\\|file://''')


class BuildError(Exception):
    """Only constant, content-free error messages may be raised."""


def digest(data):
    return hashlib.sha256(data).hexdigest()


def redact(data):
    if not scanner.text_bytes(data):
        raise BuildError('binary_or_unsupported_encoding')
    data = scanner.UDID.sub(b'REDACTED', data)
    data = scanner.DESTINATION.sub(b'-destination id=REDACTED', data)
    return FIELD_VALUE.sub(lambda m: m.group(1) + b'REDACTED', data)


def read_file(path):
    if not stat.S_ISREG(path.lstat().st_mode):
        raise BuildError('nonregular_input')
    return path.read_bytes()


def files_under(root):
    """Use explicit traversal so unreadable directories cannot be skipped."""
    if not stat.S_ISDIR(root.lstat().st_mode):
        raise BuildError('invalid_input_directory')
    result = []
    for child in sorted(root.iterdir()):
        mode = child.lstat().st_mode
        if stat.S_ISDIR(mode):
            result.extend(files_under(child))
        elif stat.S_ISREG(mode):
            result.append(child)
        else:
            raise BuildError('nonregular_input')
    return result


def qualify_root(ci):
    direct = ci / 'qualification-evidence'
    if direct.exists():
        return direct
    # The provided CI inputs wrap this directory in a run directory.
    candidates = sorted({p.parent for p in files_under(ci) if p.parent.name == 'qualification-evidence'})
    # Also support qualification directories with only nested contents.
    if not candidates:
        candidates = sorted({ancestor for p in files_under(ci) for ancestor in p.parents
                             if ancestor != ci and ancestor.is_relative_to(ci)
                             and ancestor.name == 'qualification-evidence'})
    if len(candidates) != 1:
        raise BuildError('ambiguous_or_missing_qualification_evidence')
    return candidates[0]


def write_tar(path, members):
    with path.open('wb') as raw:
        with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0, compresslevel=9) as zipped:
            with tarfile.open(fileobj=zipped, mode='w', format=tarfile.PAX_FORMAT) as archive:
                for name, data in sorted(members):
                    if not scanner.safe_member(name):
                        raise BuildError('unsafe_archive_path')
                    info = tarfile.TarInfo(name)
                    info.size = len(data)
                    info.mtime = info.uid = info.gid = 0
                    info.uname = info.gname = ''
                    info.mode = 0o644
                    archive.addfile(info, io.BytesIO(data))


def rewrite_metadata(data, is_json=False):
    if not scanner.text_bytes(data):
        raise BuildError('binary_metadata')
    text = data.decode('utf-8').replace(SOURCE_PREFIX, '').replace(TOOLS_PREFIX, '')
    values = [text]
    if is_json:
        obj = json.loads(text)
        def strings(value):
            if isinstance(value, str):
                yield value
            elif isinstance(value, dict):
                for k, v in value.items():
                    yield k
                    yield from strings(v)
            elif isinstance(value, list):
                for v in value:
                    yield from strings(v)
        decoded_strings = list(strings(obj))
        if any(value.startswith('/') for value in decoded_strings):
            raise BuildError('absolute_path_in_metadata')
        values.extend(decoded_strings)
    for value in values:
        # Remove URL tokens before testing slash-rooted paths.
        without_urls = re.sub(r'\b(?:https?|s3)://[^\s"\'<>]+', '', value)
        if ABSOLUTE.search(without_urls):
            raise BuildError('absolute_path_in_metadata')
    return text.encode('utf-8')


README_TEXT = '''# {platform} decision input

`raw-samples.json` is the decision input read by `decide.py` and `reproduce.py`
(SCHEMA.md). `provenance.json` records the source files, hashes and pins used to
assemble it, with paths relative to the evidence root. The archive was built by
`build_archive.py` (see `collection-tooling.tgz`): retained text artifacts are
redacted for device identifiers and every output is scanned before it is
published. `device-farm-file-manifest.tsv` lists every collected file with its
original size and SHA-256 and whether it is retained.
'''


def build(platform, out, *, source_root=Path(SOURCE_PREFIX), assembled_root=HERE,
          list_root=LIST_ROOT, extra_forbidden_file=None):
    if platform not in ('android', 'ios'):
        raise BuildError('invalid_platform')
    out = Path(out)
    source_root, assembled_root, list_root = map(Path, (source_root, assembled_root, list_root))
    try:
        # Never publish into an input directory or traverse an output symlink.
        for parent in (out, *out.parents):
            if parent.is_symlink():
                raise BuildError('symlink_output')
        for protected in (source_root, assembled_root / ('assembled-' + platform), list_root):
            if out.resolve().is_relative_to(protected.resolve()) or protected.resolve().is_relative_to(out.resolve()):
                raise BuildError('output_overlaps_input')
        if out.exists() and any(out.iterdir()):
            raise BuildError('output_not_empty')
        extra = scanner.load_extra(extra_forbidden_file)
        df = source_root / ('df-' + platform)
        all_files = files_under(df)
        listed = read_file(list_root / (platform + '-med.txt')).decode('utf-8').splitlines()
        if not listed or any(not x or not scanner.safe_member(x) for x in listed) or len(set(listed)) != len(listed):
            raise BuildError('invalid_retention_list')
        retained = {Path(name).as_posix() for name in listed}
        if len(retained) != len(listed):
            raise BuildError('duplicate_retention_path')
        actual = {p.relative_to(df).as_posix() for p in all_files}
        if not retained <= actual:
            raise BuildError('missing_retained_input')
        members, rows = [], []
        redacted_df = redacted_ci = 0
        for path in sorted(all_files, key=lambda p: p.relative_to(df).as_posix()):
            name = path.relative_to(df).as_posix()
            if any(c in name for c in '\t\r\n'):
                raise BuildError('invalid_manifest_path')
            # Hash even excluded files, without trying to interpret their content.
            size = 0
            original_hash = hashlib.sha256()
            data = bytearray() if name in retained else None
            with path.open('rb') as source:
                while True:
                    block = source.read(1024 * 1024)
                    if not block:
                        break
                    size += len(block)
                    original_hash.update(block)
                    if data is not None:
                        data.extend(block)
            status, archived_hash = 'not_retained', ''
            if data is not None:
                clean = redact(bytes(data))
                changed = clean != data
                redacted_df += int(changed)
                status = 'retained_redacted' if changed else 'retained_unchanged'
                archived_hash = digest(clean)
                members.append((name, clean))
            rows.append((name, str(size), original_hash.hexdigest(), status, archived_hash))
        ci = qualify_root(source_root / ('ci-' + platform))
        ci_members = []
        ci_binary_rows = []
        for path in files_under(ci):
            original = read_file(path)
            if not scanner.text_bytes(original):
                # Binary members (Xcode result bundles) cannot be inspected or redacted by a
                # byte scan: leave them out of the archive and list size and SHA-256 only.
                ci_binary_rows.append(('qualification-evidence/' + path.relative_to(ci).as_posix(),
                                       str(len(original)), digest(original)))
                continue
            clean = redact(original)
            redacted_ci += int(clean != original)
            ci_members.append(('qualification-evidence/' + path.relative_to(ci).as_posix(), clean))
        if not ci_members:
            raise BuildError('empty_qualification_evidence')
        assembled = assembled_root / ('assembled-' + platform)
        raw = read_file(assembled / 'raw-samples.json')
        metadata = {'provenance.json': rewrite_metadata(read_file(assembled / 'provenance.json'), True),
                    'README.md': README_TEXT.format(platform=platform).encode('utf-8')}
        out.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(prefix='.staging-', dir=out) as temp:
            stage = Path(temp)
            write_tar(stage / 'device-farm-physical-evidence.tgz', members)
            write_tar(stage / 'ci-simulator-evidence.tgz', ci_members)
            manifest = 'path\tsize_original\tsha256_original\tstatus\tsha256_archived\n'
            manifest += ''.join('\t'.join(row) + '\n' for row in rows)
            (stage / 'device-farm-file-manifest.tsv').write_bytes(manifest.encode('utf-8'))
            (stage / 'ci-simulator-binary-manifest.tsv').write_bytes(
                ('path\tsize\tsha256\n' + ''.join('\t'.join(r) + '\n' for r in ci_binary_rows)).encode('utf-8'))
            (stage / 'raw-samples.json').write_bytes(raw)
            if digest(read_file(stage / 'raw-samples.json')) != digest(read_file(assembled / 'raw-samples.json')):
                raise BuildError('raw_samples_identity_failed')
            for name, data in metadata.items():
                (stage / name).write_bytes(data)
            # Invoke the standalone scanner; it scans extracted member bytes too.
            command = [sys.executable, '-I', '-B', str(HERE / 'scan_archive.py'), str(stage)]
            if extra_forbidden_file is not None:
                command += ['--extra-forbidden-file', str(extra_forbidden_file)]
            checked = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            if checked.returncode or scanner.scan_path(stage, extra):
                raise BuildError('output_scan_failed')
            for path in sorted(stage.iterdir()):
                path.replace(out / path.name)
        findings = scanner.scan_path(out, extra)
        if findings:
            raise BuildError('output_scan_failed')
        return {'files_redacted': redacted_df + redacted_ci,
                'df_files_redacted': redacted_df, 'ci_files_redacted': redacted_ci,
                'scan_hits': 0}
    except BuildError:
        raise
    except (OSError, ValueError, UnicodeError, tarfile.TarError):
        raise BuildError('input_or_output_error') from None


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--platform', choices=('android', 'ios'), required=True)
    parser.add_argument('--out', required=True, type=Path)
    parser.add_argument('--extra-forbidden-file', type=Path)
    args = parser.parse_args(argv)
    try:
        result = build(args.platform, args.out, extra_forbidden_file=args.extra_forbidden_file)
    except BuildError as error:
        # BuildError messages are fixed rule identifiers, never source content.
        print('build_failed=' + str(error), file=sys.stderr)
        return 1
    print(args.platform + ' ' + ' '.join(k + '=' + str(v) for k, v in result.items()))
    return 0


if __name__ == '__main__':
    sys.exit(main())

"""Synthetic-only checks. Run with python -I -B test_archive.py."""
import contextlib
import gzip
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import sys
import tarfile
import tempfile
import unittest

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent


def module(name):
    path = HERE / (name + '.py')
    if not path.is_file():
        return None
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


scan = module('scan_archive')
builder = module('build_archive')


class ArchiveTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(scan, 'scanner implementation required')
        self.assertIsNotNone(builder, 'builder implementation required')
        work = HERE / 'archive-out'
        work.mkdir(exist_ok=True)
        self.temp = tempfile.TemporaryDirectory(dir=work, prefix='synthetic-')
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)

    def fixture(self):
        source = self.root / 'source'
        assembled = self.root / 'assembled'
        lists = self.root / 'lists'
        df = source / 'df-ios'
        ci = source / 'ci-ios' / 'run' / 'qualification-evidence'
        for p in (df, ci, assembled / 'assembled-ios', lists):
            p.mkdir(parents=True)
        (df / 'a.log').write_text('serial_number="SYNTHETIC123"\n-destination id=SYNTHETIC123\n')
        (df / 'z.log').write_text('safe text\n')
        (df / 'omitted.bin').write_bytes(b'\0\xff')
        (ci / 'ci.log').write_text('udid: SYNTHETIC123\n')
        (lists / 'ios-med.txt').write_text('z.log\na.log\n')
        a = assembled / 'assembled-ios'
        (a / 'raw-samples.json').write_bytes(b'{"synthetic":true}\n')
        (a / 'provenance.json').write_text(json.dumps({'source': builder.SOURCE_PREFIX + 'df-ios/a.log'}))
        (a / 'README.md').write_text(builder.TOOLS_PREFIX + 'assembled-ios/raw-samples.json\n')
        return source, assembled, lists

    def build(self, out='out', extra=None):
        source, assembled, lists = self.fixture()
        result = builder.build('ios', self.root / out, source_root=source,
                               assembled_root=assembled, list_root=lists,
                               extra_forbidden_file=extra)
        return result

    def test_each_scanner_rule_and_safe_diagnostics(self):
        cases = [
            ('00008ABC-' + '1234567890ABCDEF', 'udid_pattern'),
            ('serial_number: SYNTHETIC123', 'serial_udid_field'),
            ('UDID="SYNTHETIC123"', 'serial_udid_field'),
            ('-destination id=SYNTHETIC123', 'destination_id'),
            ('-destination id="SYNTHETIC123"', 'destination_id'),
            ('-destination id=REDACTEDsuffix', 'destination_id'),
            ('arn:aws:devicefarm:region:123456789012:run/a', 'arn_account'),
            ('X-Amz-Signature=synthetic', 'aws_signed_url'),
            ('X-Amz-Credential=synthetic', 'aws_signed_url'),
            ('/home/synthetic/file', 'local_home_path'),
            ('/tmp/858-synthetic/file', 'local_tmp_path'),
        ]
        for leak, rule in cases:
            with self.subTest(rule=rule):
                self.assertIn(rule, scan.scan_bytes(leak.encode()))
                p = self.root / 'leak.txt'
                p.write_text(leak)
                findings = scan.scan_path(p)
                self.assertTrue(any(r == rule for _, r in findings))
                output = io.StringIO()
                with contextlib.redirect_stdout(output):
                    self.assertNotEqual(scan.main([str(p)]), 0)
                self.assertNotIn(leak, output.getvalue())

    def test_identifier_redaction(self):
        data = ('00008ABC-' + '1234567890ABCDEF' + '\n'
                'serial_number="SYNTHETIC123"\nudid: SYNTHETIC123\n'
                '-destination id=SYNTHETIC123\n-destination id="SYNTHETIC123"\n').encode()
        clean = builder.redact(data)
        self.assertFalse(scan.scan_bytes(clean))
        self.assertNotIn(b'SYNTHETIC123', clean)
        self.assertEqual(builder.redact(clean), clean)
        self.assertEqual(builder.redact(b'safe\r\n'), b'safe\r\n')

    def test_redacted_must_be_entire_field_value(self):
        for data in (b'serial: REDACTEDsuffix', b'udid: redacted'):
            self.assertIn('serial_udid_field', scan.scan_bytes(data))
            self.assertFalse(scan.scan_bytes(builder.redact(data)))
        self.assertFalse(scan.scan_bytes(b'serial: REDACTED'))

    def test_metadata_separator_is_not_a_path(self):
        self.assertEqual(builder.rewrite_metadata(b'Android / iOS\n'), b'Android / iOS\n')
        for data in (b'{"path":"/"}', b'{"path":"//server/share"}'):
            with self.assertRaises(builder.BuildError):
                builder.rewrite_metadata(data, True)

    def test_ci_binary_member_is_excluded_and_listed(self):
        source, assembled, lists = self.fixture()
        binary = source / 'ci-ios/run/qualification-evidence/result.xcresult/data'
        binary.parent.mkdir()
        binary.write_bytes(b'\0\xff\x02')
        out = self.root / 'binout'
        builder.build('ios', out, source_root=source, assembled_root=assembled, list_root=lists)
        rows = (out / 'ci-simulator-binary-manifest.tsv').read_text().splitlines()
        self.assertEqual(len(rows), 2)
        self.assertIn('result.xcresult/data', rows[1])
        import tarfile
        with tarfile.open(out / 'ci-simulator-evidence.tgz') as tf:
            self.assertFalse(any('xcresult' in n for n in tf.getnames()))

    def test_invalid_extra_file_refused(self):
        data = self.root / 'clean'
        data.write_text('safe')
        output = io.StringIO()
        with contextlib.redirect_stdout(output):
            self.assertNotEqual(scan.main([str(data), '--extra-forbidden-file', str(self.root / 'missing')]), 0)

    def test_forbidden_archive_metadata_and_secret_filename(self):
        p = self.root / 'leak.tgz'
        with tarfile.open(p, 'w:gz', format=tarfile.PAX_FORMAT) as tf:
            info = tarfile.TarInfo('plain')
            info.pax_headers = {'comment': 'X-Amz-Signature=synthetic'}
            tf.addfile(info, io.BytesIO(b''))
        self.assertTrue(scan.scan_path(p))
        secret = '00008ABC-' + '1234567890ABCDEF'
        leak = self.root / secret
        leak.write_text('safe')
        output = io.StringIO()
        with contextlib.redirect_stdout(output):
            self.assertNotEqual(scan.main([str(leak)]), 0)
        self.assertNotIn(secret, output.getvalue())

    def test_extra_literal_file_and_no_logging(self):
        extra = self.root / 'extra.txt'
        extra.write_text('synthetic.[literal]\n\n')
        p = self.root / 'sample.txt'
        p.write_text('synthetic.[literal]')
        output = io.StringIO()
        with contextlib.redirect_stdout(output):
            self.assertNotEqual(scan.main([str(p), '--extra-forbidden-file', str(extra)]), 0)
        self.assertNotIn('synthetic.[literal]', output.getvalue())
        self.assertFalse(scan.scan_bytes(b'syntheticXliteral', scan.load_extra(extra)))

    def test_tar_member_scan_and_unsafe_members(self):
        for name, kind in [('nested/leak.log', tarfile.REGTYPE), ('../escape', tarfile.REGTYPE), ('link', tarfile.SYMTYPE)]:
            p = self.root / 'leak.tgz'
            with tarfile.open(p, 'w:gz') as tf:
                data = b'serial: SYNTHETIC123'
                info = tarfile.TarInfo(name)
                info.type = kind
                if kind == tarfile.REGTYPE:
                    info.size = len(data)
                    tf.addfile(info, io.BytesIO(data))
                else:
                    info.linkname = 'target'
                    tf.addfile(info)
            self.assertTrue(scan.scan_path(p))

    def test_fail_closed(self):
        for name, content in [('bad.tgz', b'broken'), ('binary', b'\x00\xff')]:
            p = self.root / name
            p.write_bytes(content)
            self.assertTrue(scan.scan_path(p))
        self.assertTrue(scan.scan_path(self.root / 'missing'))
        p = self.root / 'link'
        p.symlink_to(self.root / 'missing')
        self.assertTrue(scan.scan_path(p))
        with self.assertRaises(builder.BuildError):
            builder.redact(b'\x00\xff')

    def test_corrupt_deflate_is_a_named_failure(self):
        compressed = bytearray(gzip.compress(b'synthetic payload', mtime=0))
        compressed[10] = 255
        p = self.root / 'broken.tgz'
        p.write_bytes(compressed)
        self.assertIn(('broken.tgz', 'archive_read_error'), scan.scan_path(p))

    def test_build_determinism_manifest_identity_and_relative_paths(self):
        source, assembled, lists = self.fixture()
        results = []
        for name in ('first', 'second'):
            out = self.root / name
            results.append(builder.build('ios', out, source_root=source, assembled_root=assembled, list_root=lists))
            self.assertFalse(scan.scan_path(out))
            self.assertEqual((out / 'raw-samples.json').read_bytes(), (assembled / 'assembled-ios/raw-samples.json').read_bytes())
            self.assertEqual(json.loads((out / 'provenance.json').read_text())['source'], 'df-ios/a.log')
            self.assertTrue((out / 'README.md').read_bytes().startswith(b'# ios decision input'))
        self.assertEqual(results[0]['files_redacted'], 2)
        for p in (self.root / 'first').iterdir():
            self.assertEqual(p.read_bytes(), (self.root / 'second' / p.name).read_bytes())
        rows = (self.root / 'first/device-farm-file-manifest.tsv').read_text().splitlines()
        self.assertEqual(rows[0], 'path\tsize_original\tsha256_original\tstatus\tsha256_archived')
        entries = {r.split('\t')[0]: r.split('\t') for r in rows[1:]}
        self.assertEqual(entries['omitted.bin'][3:], ['not_retained', ''])
        self.assertEqual(entries['a.log'][3], 'retained_redacted')
        self.assertEqual(entries['z.log'][3], 'retained_unchanged')
        with tarfile.open(self.root / 'first/device-farm-physical-evidence.tgz') as tf:
            self.assertEqual(tf.getnames(), ['a.log', 'z.log'])
            for m in tf:
                self.assertEqual((m.mtime, m.uid, m.gid), (0, 0, 0))
                data = tf.extractfile(m).read()
                self.assertEqual(entries[m.name][4], hashlib.sha256(data).hexdigest())
        self.assertEqual((self.root / 'first/device-farm-physical-evidence.tgz').read_bytes()[4:8], b'\0' * 4)

    def test_absolute_path_abort(self):
        source, assembled, lists = self.fixture()
        for index, bad in enumerate(['/opt/private/file', 'C:\\private\\file', '/Users/person/file']):
            (assembled / 'assembled-ios/provenance.json').write_text(json.dumps({'path': bad}))
            with self.assertRaises(builder.BuildError):
                builder.build('ios', self.root / ('bad' + str(index)), source_root=source, assembled_root=assembled, list_root=lists)

    def test_nonredactable_leaks_abort_and_raw_never_modified(self):
        source, assembled, lists = self.fixture()
        raw = assembled / 'assembled-ios/raw-samples.json'
        for index, leak in enumerate(['arn:aws:s:region:123456789012:x', 'X-Amz-Signature=synthetic', '/home/synthetic', '/tmp/858-synthetic']):
            original = json.dumps({'synthetic': leak}).encode()
            raw.write_bytes(original)
            with self.assertRaises(builder.BuildError):
                builder.build('ios', self.root / ('bad' + str(index)), source_root=source, assembled_root=assembled, list_root=lists)
            self.assertEqual(raw.read_bytes(), original)

    def test_missing_retained_input_abort(self):
        source, assembled, lists = self.fixture()
        (lists / 'ios-med.txt').write_text('missing.log\n')
        with self.assertRaises(builder.BuildError):
            builder.build('ios', self.root / 'bad', source_root=source, assembled_root=assembled, list_root=lists)

    def test_dot_prefixed_retention_list(self):
        source, assembled, lists = self.fixture()
        (lists / 'ios-med.txt').write_text('./z.log\n./a.log\n')
        result = builder.build('ios', self.root / 'out', source_root=source, assembled_root=assembled, list_root=lists)
        self.assertEqual(result['files_redacted'], 2)


if __name__ == '__main__':
    # Never include fixture contents or exception text in test reports.
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(ArchiveTests)
    result = unittest.TestResult()
    suite.run(result)
    print('tests=%d failures=%d errors=%d' % (result.testsRun, len(result.failures), len(result.errors)))
    sys.exit(not result.wasSuccessful())

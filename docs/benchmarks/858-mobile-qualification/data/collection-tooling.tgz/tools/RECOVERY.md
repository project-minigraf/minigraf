# 858 tooling recovery

Work directory: `/tmp/858-rebuild`. No live `collect` command was executed.
The requested durable destination refused writes. Copy this package before another reboot.

## Current outcome

Tooling reconstructed and tested. Live recovery is blocked: AWS MCP's ListRuns call
was rejected because tool approval is required but approval policy is `never`.
The explicitly requested AWS CLI also cannot connect to
`https://devicefarm.us-west-2.amazonaws.com/` from this sandbox. Android rebuild
was attempted first, then iOS. Both stopped on ListRuns before creating state.
Both summaries report FileNotFoundError. No device-minute total, slot validity,
artifact size result, or redaction audit of live data can be reported.

## Recovered sources and known gaps

The four named Claude subagent JSONL transcripts contain Codex handoffs and final
reports, not their implementation edits. The corresponding persistent Codex
sessions contain all driver and assembler source edits, plus two intermediate
fixes required to reach the final 46 collector tests. `SOURCE-PROVENANCE.json`
records the source paths and SHA-256 hashes. JSONL was parsed with `python -I`;
no historical command was blindly executed. The patch containing only README
context, which failed in the original session, was excluded.

`recovered-original/` in the outer recovery directory contains the reconstructed
baseline before the new command. Original `/tmp/858-dfdriver` and
`/tmp/858-assemble` paths were relocated to `/tmp/858-rebuild/tools`.
The assembler preserves its original output-directory restriction, now pointing
to `/tmp/858-rebuild/tools`; copying it elsewhere does not change that restriction.
Its README generation and rejection rules are otherwise preserved.

All six captured Device Farm JSON fixtures survived in transcript output. The
full smoke Logcat file did not; its fixture contains the 11 distinct captured
benchmark lines available in the transcript. This is a partial historical smoke
fixture, not recovered qualification data. The original smoke test assertions
are unchanged. No missing stream records were synthesized.

The original README describes an earlier driver revision. See the source and
this addendum for the final reparse, oversized-artifact and recovery behavior.

The CI build.json files are copied directly from the two paths requested by the
user. Both pin core b0d2d014d57c90680a6adc1d10e749a3db5df40c; iOS binding/harness
is a566cb246a235b10a93e27b571b7a8cbdc6aea36 and Android is
702e25d7b54d2fa6566a03799e2bbf73d6bc16cc. Platform parsers are copied from the
existing qualification worktrees. Their bytes are retained in `parsers/`.

Android runtime pins come from the historical collector launch transcript:
`google/panther/panther:14/AP2A.240905.003/12231197:user/release-keys`, hardware
and product `panther`, loaded ABI `arm64-v8a`, SDK `34`. They have NOT been
re-derived from fresh downloads. Rebuild checks the downloaded runtime against
these pins. iOS uses the user-provided iPhone 15 / 18.5 / 22F76 / iPhone15,4 / arm64 pins.

## Recovery command behavior

`df_collect.py rebuild-state` uses only these AWS CLI operations:
list-runs, list-jobs, list-suites, list-tests, list-artifacts, list-uploads,
list-device-pools, get-run. A separate client rejects every other operation
before invoking a subprocess. Profile is minigraf-devicefarm, region us-west-2.
Every listing consumes all pages and rejects repeated pagination tokens.

Supply --collection-id, --platform, --project-arn, --build-json, --runtime-json,
--core-revision and --out. App/test/pool ARNs are optional: resolve the historical
exact names via full upload and pool listings, or pass explicit ARNs when names
are ambiguous. Inputs must be successful uploads of the platform-specific type
and a pool with one ARN/IN device. Matching runs are sorted by creation time;
duplicate, missing, out-of-order or >3 attempt numbers are refused.

The original collection artifact parser/validator performs selected-test
ownership checks, iOS octal decoding, exact MinigrafBench: matching, mirrored
stream/prefix checks, provider/test failure checks, runtime/build checks and
process-identity checks. Recovery additionally checks the actual device ARN
against the listed singleton pool, and the run appUpload/devicePoolArn against
current inputs. The API does not supply the historical test-package ARN in the
captured run shape; test-package binding is validated through the named upload,
selected method and embedded build identity, without inventing an API field. It retains every historical attempt and
all billing, including superseded attempts. It uses the collector's existing
per-attempt layout and checkpoint/fingerprint generation.

Known account IDs, account segments of ARNs, provider-supplied serial/UDID values,
labelled serial values and modern iOS UDID patterns are redacted before retention.
No presigned URLs are retained. The original bounded downloader records oversized
non-stream artifacts as oversized_not_retained, and retains size/error diagnostics.
The live-data redaction and size audit remains pending because downloads were blocked.

Original local started/finished times and driver phases cannot be inferred from
AWS run metadata. The rebuilt timestamps explicitly use provider created/started/
stopped times. Normally COMPLETED runs become phase done after artifact validation;
active runs and interrupted artifact retrieval leave a resumable incomplete rebuild.
The added collect guard refuses collect --resume until the full rebuild completes.

`--superseded-attempt 02-B1-2` is explicit historical evidence supplied by the
user for iOS, not inferred from AWS. Its artifacts are still recovered and parsed,
billing is retained, and it is finished as invalid/superseded so it cannot block
resuming the satisfied slot. Earlier parser-rejected attempts that validate now
remain valid. No old rejection reason or reparse event is fabricated.

A partially completed rebuild can be rerun with identical inputs. It verifies
that retained attempts are an exact prefix of the chronological inventory,
skips finished recoveries, and retries the unfinished run without scheduling.
Keep this version of the driver and the retained parser unchanged between rebuild
and collect --resume; parser fingerprints include the driver source.

The faithfully restored assembler rejects valid attempts followed by another
attempt in the same slot. Reparsed historical iOS retries can trigger that rule.
No new assembler policy or filtering rule was invented. Assembly was not requested
or run on live data in this recovery.

## Run read-only recovery outside the network-restricted sandbox

Use a writable durable destination for all downloaded data. The wrapper discovers
the historical account only in memory from the original JSONL transcript, uses
the historical Minigraf project UUID, and offers --project-arn as an override.
It never reads credentials or calls STS/list-projects. It invokes rebuild-state
and then summary; it never invokes collect.

```bash
export PATH=<node-bin>:$PATH
mkdir -p <evidence-root>/tools
cp -a /tmp/858-rebuild/tools/. <evidence-root>/tools/
python -I <evidence-root>/tools/recover_collection.py android --out <evidence-root>/df-android
python -I <evidence-root>/tools/recover_collection.py ios --out <evidence-root>/df-ios
```

Run Android to successful reconstruction before the iOS command. Each wrapper
runs summary only after successful reconstruction. An independent summary is:

```bash
python -B <evidence-root>/tools/df_collect.py summary --out <evidence-root>/df-android
python -B <evidence-root>/tools/df_collect.py summary --out <evidence-root>/df-ios
```

If the durable location is still unavailable, pass --out /tmp/858-rebuild/df-android
and /tmp/858-rebuild/df-ios respectively, then sync those full directories.

Expected slot matrix BELOW IS USER-PROVIDED HISTORY, NOT VERIFIED RECOVERY:

| Run index | Android B1 / V / B2 | iOS B1 / V / B2 |
|---|---|---|
| 01 | complete / complete / complete | complete / complete / complete |
| 02 | complete / complete / complete | complete / complete / complete |
| 03 | complete / complete / complete | complete / complete / complete |
| 04 | complete / complete / complete | complete / complete / complete |
| 05 | complete / complete / complete | complete / complete / missing |
| 06 | complete / complete / complete | missing / missing / missing |

Totals, actual validity, and redaction/size anomalies: unverified for both platforms.

## Later: run only the four remaining iOS slots

The following command was PREPARED, NOT EXECUTED. It spends Device Farm minutes.
Run it only after successful recovery and reviewing the summaries:

```bash
PATH=<node-bin>:$PATH bash <evidence-root>/tools/RESUME-IOS.sh <evidence-root>/df-ios
```

The script checks the exact collection ID, completed recovery, no pending attempt,
and exactly these missing slots: 05-B2, 06-B1, 06-V, 06-B2. It reconstructs the
upload/pool account segments only in memory, then invokes the recovered
`df_collect.py collect --resume` using the retained build/runtime/parser. The
existing collector skips satisfied slots and permits two retries per missing slot.
Caps remain 54 total attempts and 600 device minutes; it refuses if those caps
cannot admit a run. There is no supported per-slot selector in the recovered
collector, so one resume command is the faithful way to run those four slots.

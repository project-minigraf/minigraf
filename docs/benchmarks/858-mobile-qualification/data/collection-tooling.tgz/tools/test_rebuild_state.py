"""Offline recovery regression tests; no real AWS calls or collect execution."""
import copy
import json
import os
from pathlib import Path
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import df_collect as d
import test_df_collect as fixtures
try:
    import rebuild_state as r
except ImportError:
    r = None

CID = 'a' * 32
ARN = fixtures.ARN

def run(slot='01-B1', number=1, created='2026-11-19T00:00:00Z'):
    return dict(name=f'm858-{CID}-{slot}-{number}', arn=ARN+f'run:p/{slot}-{number}',
                created=created, stopped=created, started=created,
                appUpload=ARN+'upload:app', devicePoolArn=ARN+'devicepool:p',
                status='COMPLETED', result='PASSED', deviceMinutes={'total': 1.25})

class RebuildTests(unittest.TestCase):
    setUp = fixtures.ReparseTests.setUp

    def api(self):
        self.assertIsNotNone(r, 'rebuild-state implementation is missing')
        return r

    def test_cli_exposes_readonly_rebuild_state(self):
        result=d.subprocess.run([d.sys.executable, '-B', str(Path(d.__file__)), 'rebuild-state', '--help'], capture_output=True, text=True)
        self.assertEqual(result.returncode,0,result.stderr)
        self.assertIn('--collection-id',result.stdout)
        self.assertIn('--superseded-attempt',result.stdout)

    def test_superseded_artifact_outage_does_not_block_later_recovery(self):
        m=self.api();c=m.ReadOnlyCollector(self.args)
        row=m.ordered_runs([run()],CID)[0]
        c.initialize(CID,[row]);c.pinned_device='device'
        c.listing=lambda *a,**kw: []
        def incomplete(a, run):
            a['phase']='artifacts'
            raise d.Stop('artifact retrieval incomplete')
        c.collect_artifacts=incomplete
        c.recover_attempt(row,row['run'],superseded=True)
        self.assertTrue(c.state['attempts'][0]['superseded'])
        self.assertEqual(c.state['attempts'][0]['phase'],'done')

    def test_orders_by_creation_and_preserves_attempt_numbers(self):
        runs=[run('01-B1',2,'2026-11-19T02:00:00Z'),run(),run('01-V',1,'2026-11-19T03:00:00Z')]
        runs.append(dict(name='unrelated'))
        rows=self.api().ordered_runs(runs,CID)
        self.assertEqual([(x['slot'],x['attempt']) for x in rows],[('01-B1',1),('01-B1',2),('01-V',1)])

    def test_refuses_duplicate_slot_attempt_gap_fourth_and_bad_timestamp(self):
        m=self.api()
        for runs in ([run(),run()], [run(number=2)], [run(number=n) for n in range(1,5)],
                     [run(created='unknown')], [run(slot='07-B1')]):
            with self.subTest(runs=runs),self.assertRaises(ValueError):m.ordered_runs(runs,CID)

    def test_mismatched_historical_app_or_pool_refused_before_artifacts(self):
        m=self.api();c=m.ReadOnlyCollector(self.args)
        rows=m.ordered_runs([run()],CID);c.initialize(CID,rows)
        for key in ('appUpload','devicePoolArn'):
            value=dict(rows[0]['run']);value[key]='wrong'
            with self.subTest(key=key), patch.object(c,'listing',side_effect=AssertionError('must not fetch artifacts')):
                with self.assertRaisesRegex(ValueError,'historical run'):
                    c.recover_attempt(rows[0],value)

    def test_transport_failure_hides_arn_and_does_not_escape_as_traceback(self):
        m=self.api();c=m.ReadOnlyCollector(self.args)
        with patch.object(d.subprocess,'run',side_effect=d.subprocess.TimeoutExpired([ARN+'run:p/r'],1)):
            with self.assertRaisesRegex(d.Stop,'transport failure') as error:
                c.aws('list-runs',arn=ARN+'project:p')
        self.assertNotIn(fixtures.ACCOUNT,str(error.exception))

    def test_allowlist_refuses_every_mutating_operation_before_subprocess(self):
        m=self.api()
        with patch.object(d.subprocess,'run',side_effect=AssertionError('must not execute')):
            for op in ['schedule-run','create-upload','stop-run','delete-run','list-projects','get-device']:
                with self.subTest(op=op),self.assertRaises(ValueError):m.ReadOnlyCollector.aws(self.collector,op)

    def test_collect_resume_refuses_incomplete_rebuild_before_any_aws(self):
        m=self.api();c=m.ReadOnlyCollector(self.args)
        rows=m.ordered_runs([run()],CID);c.initialize(CID,rows)
        live=d.Collector(self.args)
        with patch.object(live,'preflight',side_effect=AssertionError('must not call AWS')):
            with self.assertRaisesRegex(ValueError,'rebuild-state is incomplete'):
                live.execute()

    def test_full_recovery_pagination_and_resume_never_resubmits(self):
        m=self.api()
        self.args.out=self.out/'recovery'
        self.args.collection_id=CID;self.args.project_arn=ARN+'project:12345678-abcd'
        self.args.app_name='app';self.args.test_package_name='tests';self.args.pool_name='pool'
        self.args.superseded_attempt=[]
        self.args.allow_file_urls=False
        calls=[]
        provider_run=run()
        test_arn=ARN+'test:p/j/s/t'
        def aws(client, op, **kw):
            self.assertIn(op,m.READ_ONLY);calls.append((op,kw))
            if op=='list-runs':
                return {'runs':[provider_run]} if kw.get('next_token')=='page2' else {'runs':[], 'nextToken':'page2'}
            if op=='get-run':return {'run':provider_run}
            if op=='list-uploads':return {'uploads':[
                dict(name='app',arn=ARN+'upload:app',type='IOS_APP',status='SUCCEEDED'),
                dict(name='tests',arn=ARN+'upload:tests',type='XCTEST_TEST_PACKAGE',status='SUCCEEDED')]}
            if op=='list-device-pools':return {'devicePools':[dict(name='pool',arn=ARN+'devicepool:p',rules=[dict(attribute='ARN',operator='IN',value='["device"]')])]}
            if op=='list-jobs':return {'jobs':[dict(arn=ARN+'job:p/j',result='PASSED',device=dict(arn='device',model='Apple iPhone 15',os='18.5',platform='IOS'))]}
            if op=='list-suites':return {'suites':[dict(arn=ARN+'suite:p/j/s',result='PASSED')]}
            if op=='list-tests':return {'tests':[dict(arn=test_arn,name='testQualificationBaseline',result='PASSED')]}
            if op=='list-artifacts':return {'artifacts': [dict(arn=test_arn.replace(':test:',':artifact:')+'/log',name='Syslog',type='DEVICE_LOG',extension='syslog',url='https://fixture.test/log')] if kw['type']=='LOG' else []}
            raise AssertionError(op)
        raw='\n'.join('MinigrafBench: '+json.dumps(x) for x in self.records).encode()
        with patch.dict(os.environ,AWS_PROFILE='minigraf-devicefarm',AWS_REGION='us-west-2'), patch.object(m.ReadOnlyCollector,'aws',aws), patch.object(m.ReadOnlyCollector,'download',return_value=raw):
            self.assertEqual(m.rebuild(self.args),0)
            state=json.loads((self.args.out/'state.json').read_text())
            self.assertTrue(state['attempts'][0]['valid'])
            self.assertEqual(state['input_fingerprint'],d.Collector(self.args).fingerprint)
            count=len([x for x in calls if x[0]=='get-run'])
            self.assertEqual(m.rebuild(self.args),0)
            self.assertEqual(len([x for x in calls if x[0]=='get-run']),count)
            self.assertTrue(any(kw.get('next_token')=='page2' for op,kw in calls))

    def test_upload_discovery_requires_unique_successful_named_types(self):
        m=self.api()
        self.args.app_arn=self.args.test_package_arn=self.args.device_pool_arn=None
        self.args.app_name='app';self.args.test_package_name='tests';self.args.pool_name='pool'
        data={'uploads':[dict(name='app',arn=ARN+'upload:app',type='IOS_APP',status='SUCCEEDED'),
                         dict(name='tests',arn=ARN+'upload:tests',type='XCTEST_TEST_PACKAGE',status='SUCCEEDED')],
              'devicePools':[dict(name='pool',arn=ARN+'devicepool:p',rules=[dict(attribute='ARN',operator='IN',value='["device"]')])]}
        listing=lambda op,key,**kw:copy.deepcopy(data[key])
        m.resolve_inputs(self.args,listing,ARN+'project:p')
        self.assertEqual(self.args.app_arn,ARN+'upload:app')
        data['uploads'][0]['status']='FAILED'
        with self.assertRaises(ValueError):m.resolve_inputs(self.args,listing,ARN+'project:p')

    def test_redacts_account_serial_udid_and_retains_hash(self):
        m=self.api();c=m.ReadOnlyCollector(self.args)
        c.remember_serials({'device':{'serialNumber':'SERIAL123456','udid':'00008120-00123456789ABCDE'}})
        raw=(ARN+'run:p/r SERIAL123456 00008120-00123456789ABCDE '+('b'*64)+
             ' serial=SECOND1234 "serial_number": "THIRD1234"').encode()
        safe=c.redact(raw)
        for private in [fixtures.ACCOUNT,'SERIAL123456','00008120-00123456789ABCDE','SECOND1234','THIRD1234']:
            self.assertNotIn(private.encode(),safe)
        self.assertIn(('b'*64).encode(),safe)

    def test_rebuild_uses_real_parser_keeps_all_history_and_resume_identity(self):
        m=self.api();c=m.ReadOnlyCollector(self.args)
        c.project=ARN+'project:p';c.pinned_device='device'
        rows=m.ordered_runs([run(),run(number=2,created='2026-11-19T01:00:00Z')],CID)
        c.initialize(CID,rows)
        def listing(op,key,**kw):
            if key=='jobs':return [dict(arn=ARN+'job:p/j',result='PASSED',device=dict(arn='device',model='Apple iPhone 15',os='18.5',platform='IOS',serialNumber='SERIAL123456'))]
            if key=='suites':return [dict(arn=ARN+'suite:p/j/s',result='PASSED')]
            if key=='tests':return [dict(arn=ARN+'test:p/j/s/t',name='testQualificationBaseline',result='PASSED')]
            if key=='artifacts':return [dict(arn=ARN+'artifact:p/j/s/t/a',name='Syslog',type='DEVICE_LOG',extension='syslog',url='https://fixture.test/stream')] if kw['type']=='LOG' else []
            raise AssertionError(op)
        c.listing=listing
        current=[0]
        def download(url):
            records=copy.deepcopy(self.records)
            for x in (records[0],records[-1]):x['run_id']='run-'+str(current[0])
            return ('serial=SERIAL123456\n'+'\n'.join('MinigrafBench: '+json.dumps(x).replace('/',r'\/').replace('\\',r'\134') for x in records)).encode()
        c.download=download
        for row in rows:
            current[0]+=1;c.recover_attempt(row,row['run'])
        state=json.loads((self.out/'state.json').read_text())
        self.assertEqual(state['input_fingerprint'],d.Collector(self.args).fingerprint)
        self.assertEqual([a['valid'] for a in state['attempts']],[True,True])
        self.assertEqual(c.slots()[0]['status'],'completed')
        self.assertEqual(sum(a['device_minutes'] for a in state['attempts']),2.5)
        for p in self.out.rglob('*'):
            if p.is_file():
                self.assertNotIn(fixtures.ACCOUNT.encode(),p.read_bytes())
                self.assertNotIn(b'SERIAL123456',p.read_bytes())
        self.assertTrue((self.out/'ios/01-B1-2/manifest.json').exists())

    def test_superseded_attempt_is_explicit_and_finished_without_losing_billing(self):
        m=self.api();c=m.ReadOnlyCollector(self.args)
        c.state={'attempts':[]}
        a={'parsed':c.parse('',{'set':'B1','run_index':2,'attempt':2}), 'device_minutes':2.5,'valid':True,'phase':'artifacts'}
        c.mark_superseded(a)
        self.assertFalse(a['valid']);self.assertEqual(a['phase'],'done')
        self.assertEqual(a['device_minutes'],2.5);self.assertIn('superseded',a['reason'])

if __name__=='__main__':unittest.main()

# Verification results

- Reconstructed baseline: 46 collector + 11 assembler tests, 57 passed in 380.506 s.
- Full regression after CLI wiring and incomplete-rebuild guard: 68 tests passed
  in 439.888 s (46 collector, 11 assembler, 11 recovery tests present at invocation).
- Final recovery suite after two additional checks: 13 passed in 0.505 s.
- Final focused run: 11 assembler + 13 recovery tests, 24 passed in 1.286 s.
- Current unique test inventory: 70 tests, all covered by the passing runs above.
- Python source syntax and RESUME-IOS.sh shell syntax checked.
- No real AWS account IDs found in the final tooling; no live artifact redaction
  or size audit was possible because ListRuns failed before any downloads.
- No live collect executed. The original collector integration tests use a fake
  aws executable with an offline profile; recovery tests mock provider/download
  boundaries. No test assertions were weakened. No timing mocks were needed.
- All started exec sessions exited; no child Codex agent was launched.

Live Android and iOS reconstruction both failed on ListRuns with an endpoint
connection error. MCP ListRuns was separately blocked by required approval under
approval policy never. No live state exists, both requested summary attempts
reported FileNotFoundError, and minutes/slot validity/anomalies are unverified.
Durable destination writes were refused; sync /tmp/858-rebuild before reboot.

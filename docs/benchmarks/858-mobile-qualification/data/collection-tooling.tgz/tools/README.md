# Mission 858 physical collector

`df_collect.py` uses Python 3's standard library and the AWS CLI. Development and
tests run offline, without AWS requests, credential lookup, or resource creation.
The tests put a fake executable named `aws` first on PATH and download synthetic
artifacts through local `file:` URLs. Response checks also load supplied redacted
Device Farm captures and an actual Android smoke Logcat; see the
[field-by-field audit and capture limits](fixtures/devicefarm/README.md). No repository changes
or commits are needed. This is collection tooling, not evidence of qualification.

## Invocation

Supply the **actual build.json embedded in the uploaded packages**, a full pinned
core revision, and a JSON file of public physical runtime pins recorded before
timing. The parser paths default to the two supplied qualification worktrees;
use `--parser /absolute/path/to/qualification/parse_samples.py` if relocated.
Imports disable bytecode generation, including in those read-only worktrees.

With the shell variables below set to your existing uploaded ARNs and evidence
paths, these are complete commands. Both outputs stay in the requested sandbox.

Both uploads must have status `SUCCEEDED`. For iOS, `--app-arn` must identify an
`IOS_APP` upload and `--test-package-arn` an `XCTEST_TEST_PACKAGE` upload. For
Android, the required types are `ANDROID_APP` and `INSTRUMENTATION_TEST_PACKAGE`,
respectively. These are the types reported on real, accepted uploads supplied
by the user. The driver checks each role strictly before any schedule-run;
swapped roles or mismatched platform types are refused.

```sh
export AWS_PROFILE='your-profile'
export AWS_REGION='us-west-2'

python3 -B /tmp/858-rebuild/tools/df_collect.py collect --platform ios \
  --app-arn "$IOS_APP_ARN" --test-package-arn "$IOS_TEST_PACKAGE_ARN" \
  --device-pool-arn "$IOS_DEVICE_POOL_ARN" --build-json "$IOS_BUILD_JSON" \
  --runtime-json "$IOS_RUNTIME_JSON" --core-revision "$CORE_REVISION" \
  --out /tmp/858-rebuild/tools/out-ios < /dev/null

python3 -B /tmp/858-rebuild/tools/df_collect.py collect --platform android \
  --app-arn "$ANDROID_APP_ARN" --test-package-arn "$ANDROID_TEST_APK_ARN" \
  --device-pool-arn "$ANDROID_DEVICE_POOL_ARN" --build-json "$ANDROID_BUILD_JSON" \
  --runtime-json "$ANDROID_RUNTIME_JSON" --core-revision "$CORE_REVISION" \
  --out /tmp/858-rebuild/tools/out-android < /dev/null

python3 -B /tmp/858-rebuild/tools/df_collect.py summary \
  --out /tmp/858-rebuild/tools/out-ios < /dev/null
python3 -B /tmp/858-rebuild/tools/df_collect.py summary \
  --out /tmp/858-rebuild/tools/out-android < /dev/null
```

Add `--dry-run` to either collection command to print the 18-slot plan without
AWS calls or output writes. Add `--resume` to the **same command and inputs** to
resume. `--poll-interval` defaults to 30 seconds; `--run-timeout` defaults to
1800 seconds, measured from the durable intent, including queue time. Attempt
and minute caps default to 54 and 600. Exit 0 means all 18 slots have valid
streams; exit 2 means refused, stopped, or unresolved; exit 130 is an orderly
keyboard interruption. Summary is read-only and includes unknown billing counts.

Runtime JSON must contain only nonempty string values. Required iOS pins:

```json
{
  "provider": "Device Farm",
  "model": "iPhone 15",
  "os": "iOS 18.5",
  "os_build": "ACTUAL_PRE_REGISTERED_BUILD",
  "machine": "iPhone15,4",
  "architecture": "arm64"
}
```

Required Android pins:

```json
{
  "provider": "Device Farm",
  "model": "Pixel 7",
  "os": "Android 14",
  "fingerprint": "ACTUAL_PRE_REGISTERED_GUEST_BUILD_FINGERPRINT",
  "hardware": "panther",
  "product": "panther",
  "loaded_abi": "arm64-v8a",
  "sdk": "34"
}
```

These examples are templates, not observed configuration evidence. Replace the
`ACTUAL_...` strings and corroborate all other pins before collection. A changed
OS build/fingerprint is invalid for the original configuration. The collector
checks provider model/OS on each job and these required pins on every stream.
Provider models are exactly `Apple iPhone 15` and `Google Pixel 7`, with OS values
`18.5` and `14`, respectively. Provider platform and any supplied manufacturer
must also match. These provider names differ from the runtime model pins above.
Extra public descriptive string fields may be included; they are retained, but
only the documented required pins are checked against runtime records.

The device pool must contain an explicit `ARN IN ["one-device-arn"]` rule.
The driver reads that device before scheduling and refuses an unmatched model,
OS, or platform. It does not edit pools. This restriction bounds each scheduled
run to one device; a general model-based pool could match multiple devices.

## Collection and recovery

The schedule is `(B1,V,B2) × 6`. Each schedule-run starts a new provider run,
selecting one harness method. B1/B2 use `BenchmarkTests/testQualificationBaseline`
and V uses `BenchmarkTests/testQualificationSlowdown` for iOS (`XCTEST`). Android
uses `INSTRUMENTATION` and top-level `test.filter` with
`io.github.project_minigraf.benchmark.BenchmarkTest#testQualificationBaseline`
or `#testQualificationSlowdown`. No variant parameter or
`test.parameters.filter` is used. Optional `--filter-b1`, `--filter-b2` and
`--filter-v` accept only those pre-registered values.

Each slot permits three attempts, in sequence, and only a no-valid-stream failure
permits a retry. Exhaustion records an unresolved slot and continues later slots.
Neither latency nor a statistical gate influences collection. A fresh process
UUID must not appear in any previous attempt, including failed attempts.

`state.json` is the authoritative checkpoint. Each mutation of local attempt
state uses temporary-file replacement plus file and directory fsync. A local
file lock prevents concurrent drivers in the same output directory. Keep the
directory intact; restoring an older checkpoint can defeat resume safety.

A unique run name is durable **before** calling schedule-run. AWS CLI automatic
request retries are disabled. Once accepted, the redacted ARN is durable before
polling. After interruption in the submission window, all list-runs pages are
searched for that exact name. One match is adopted. Zero or multiple matches
stop collection without another schedule-run. A zero-match result is not proof
of rejection: it may be a crash before submission or delayed provider visibility.
Resume later to reconcile; there is deliberately no automatic override that
could double-schedule. No provider idempotency parameter is assumed.

Timeout is recorded as a provider failure. The driver exits while that run is
still active, preserving its ARN, known minutes, and reason. Resume first checks
that same run. Only after it is COMPLETED does the driver retrieve its artifacts
and permit the bounded retry. There is no cancellation call, and no retry overlaps
an active timed-out run. Pending/ambiguous attempts appear as invalid placeholders
in the schema fragment until finalized, without adding an attempt on resume.

Polling subprocesses use the remaining run deadline, so a hung read cannot
extend the polling window. Other AWS CLI calls have a 60-second transport
timeout; ambiguous submission is reconciled as described above.

Attempt admission stops at the chosen attempt cap. Minute admission requires
`observed total + ceil(run_timeout / 60) <= max_device_minutes`; schedule-run sets
`executionConfiguration.jobTimeoutMinutes` to that same reservation. Billing is
the run's `deviceMinutes.total`, never a sum of run and job totals. Missing final
billing stops new submissions. Pending runs are reconciled even if caps were
lowered on resume; finished valid slots are never replaced.

**Billing boundary:** the cap is enforced on observed minutes and the maximum
configured job duration reserved for the next single-device run. It cannot be
an unconditional ceiling on AWS's eventual bill: this offline implementation
cannot verify whether setup, teardown, rounding, or delayed reporting exceed
that provider limit. The driver never cancels or modifies an existing resource.
An actual billing overrun is retained and prevents further scheduling. A strict
provider-side financial ceiling cannot be guaranteed with schedule/read-only
operations alone.

## Evidence and privacy

Outputs include `raw-samples.json` (one physical configuration in the exact
SCHEMA.md envelope), `collection-log.json`, frozen build/runtime metadata, a
copy of the imported parser, `state.json`, and `SHA256SUMS`. This physical-only
fragment must be combined with the independently collected matching candidate
configuration before `decide.py` can process a complete study. It is not itself
a decision report.

Each `out/<platform>/<index>-<set>-<attempt>/` retains raw artifact payloads,
`manifest.json`, `parsed.json`, and `attempt.json`. The parser retains the original
sample totals/iterations, means, partial records, and suite-wide invalid reasons.
The collector requires all 14 cases and ten sample means via the **existing
platform parser imported by path**. Provider/job/test results must be successful;
the harness completion marker supplies its post-teardown completion evidence.
Provider timestamps, job results, actual model/OS, run minutes, and local receipt
times are retained. Unavailable job fields are null, not fabricated observations.

FILE, LOG, and SCREENSHOT artifacts are enumerated on runs, jobs, suites and tests,
with pagination. Duplicate artifact ARNs are downloaded once. Text/log output and
ZIP containers are supported; ZIP members are stored under sanitized flat names,
never extracted to provider-supplied paths. Archives and downloads have 128 MiB
limits (expanded ZIP total included). Unsupported compressed formats do not
produce a valid stream. All available raw payloads are kept even when invalid.

Only artifacts whose ARN belongs to the selected benchmark test supply streams;
setup and teardown artifacts remain retained evidence. Android streams must come
from that test's `DEVICE_LOG` artifact named `Logcat`, using threadtime lines
`<date> <time> <pid> <tid> I MinigrafBench: {json}`. Instrumentation Output is not
a benchmark source. Identical artifact names have distinct numbered filenames,
and manifest file entries identify their source artifact ARN.

Identical streams in selected-test exports count once. A redundant truncated
prefix can corroborate a complete stream. Different records, multiple process
IDs, duplicated records within a stream, malformed tagged lines, mixed modes,
or disagreeing copies invalidate the whole attempt. No artifacts are concatenated
or selected by latency. iOS JSONL/prefixed logs and extracted Android Logcat JSON
use the parser's existing record validation.

If a complete stream has already been observed, an artifact-download failure
(including an unavailable screenshot) pauses collection. Resume retrieves evidence
for the same run; the driver cannot schedule a replacement just because an
unrelated artifact is temporarily unavailable.

Account IDs in ARNs are replaced with `REDACTED` throughout retained evidence;
the input account ID is also scrubbed outside ARNs. No unredacted ARN is saved,
including in state. Resume reconstructs the account component from the original
upload arguments and verifies a SHA-256 fingerprint of all immutable inputs.
The original account, full provider responses, and signed URLs stay in memory.
CLI stderr is not retained because it can expose private data. Public job
metadata excludes serial numbers and device-instance identifiers.

Raw text means provider bytes **after account redaction**. Manifest hashes label
both original downloaded bytes and retained payloads. ZIP originals are represented
by a download hash and their sanitized/redacted members, because retaining their
compressed originals could hide account IDs. Screenshots and other non-text
payloads are retained with hashes and byte-level scrubbing; this is not OCR or
a guarantee that private information rendered inside an image is removed.
Perform the protocol's public-evidence privacy review before publishing.

## Offline assumptions requiring provider verification

* The Android README itself marks Device Farm's acceptance/passing of a single
  top-level `CLASS#METHOD` Instrumentation filter as unverified. Verify selection
  and fresh app/process behavior before timing. The script follows that exact
  documented assumption and fails on mixed/duplicate/nonqualification streams.
* The supplied Android job artifact capture confirms Logcat, Instrumentation
  Output, Video, and TCP dump log names/types/extensions and test resource paths.
  The supplied Logcat confirms tagged benchmark records. iOS artifact packaging
  and discovery at other hierarchy levels remain unverified against captures.
  The driver cannot pull files from the device itself.
* Device fields, job results, suite structure, and run billing fields were checked
  against supplied responses. No captures were supplied for list-tests, get-upload,
  get-device-pool, or schedule-run. Per-job timeout behavior and current physical
  availability also remain unverified. No network requests were made in this
  audit. Missing/changed fields stop or invalidate collection.
* The local build.json is asserted to accompany the supplied uploaded artifacts.
  The parsers verify embedded source/Release/native identities (full manifest on
  Android, compact identity on iOS); Device Farm metadata alone cannot attest
  that the local manifest was embedded in an uploaded package. Upload creation
  and package/build integrity remain the Generator's responsibility.
* A pool selects a public model/OS, not an exclusive physical unit. Every returned
  job is checked. The driver cannot certify protocol pre-registration was committed
  or that pre-timing correctness controls ran; those are prerequisites for its use.

## Tests

```sh
cd /tmp/858-rebuild/tools
python3 -B -m unittest < /dev/null
```

All test scratch files are created under this directory and removed by the test
suite. Tests cover both full 18-slot schedules, retries, unresolved exhaustion,
wrong model/OS, upload role/type mismatches before scheduling, build/runtime pins,
stale and duplicate streams, timeout
draining, two SIGKILL recovery windows, ambiguous submission, pagination, ZIP
handling, redaction, checksums, summary, dry-run, and budget/attempt admission.
Captured-response tests exercise every supplied JSON sample and the Android
Logcat. Artifact regressions cover selected-method ownership, setup/teardown
exclusion, Android source type, and collision-free files for identical names.

Archive note: local absolute paths in this archived copy (evidence root, Node install
directory, home paths) are replaced by the placeholders `<evidence-root>`, `<node-bin>` and
`<local-path>`; edit them before re-running any script.

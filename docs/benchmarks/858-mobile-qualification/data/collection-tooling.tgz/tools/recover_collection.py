#!/usr/bin/env python3
"""Run only rebuild-state, then summary. Never calls collect.

Project account is read from the user-authorized historical transcript in memory;
no account number or signed URL is stored in this package.
"""
import argparse
import json
import os
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
COLLECTIONS = {'android':'e59b2e83a0cc4459aa54393cfd4c8162', 'ios':'11e4c1bc53064fe48b296d713d6fd0ae'}
PROJECT = '7d2e4e7f-2821-422e-8f09-94828f9a714a'
TRANSCRIPT = Path.home()/'.claude/projects/<claude-project-dir>/<session>.jsonl'

def project_arn():
    # Parse JSONL in isolated Python, never execute any transcript content.
    accounts=set()
    for line in TRANSCRIPT.read_text().splitlines():
        row=json.loads(line)
        for value in strings(row):
            accounts.update(re.findall(r'arn:aws:devicefarm:us-west-2:(\d{12}):',value))
    if len(accounts)!=1:
        raise ValueError('historical project account is missing/ambiguous; pass --project-arn')
    return 'arn:aws:devicefarm:us-west-2:'+accounts.pop()+':project:'+PROJECT

def strings(value):
    if isinstance(value,str):yield value
    elif isinstance(value,dict):
        for item in value.values():yield from strings(item)
    elif isinstance(value,list):
        for item in value:yield from strings(item)

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('platform',choices=COLLECTIONS)
    p.add_argument('--out',required=True,type=Path)
    p.add_argument('--project-arn')
    a=p.parse_args()
    project=a.project_arn or project_arn()
    build=ROOT/'inputs'/('build-'+a.platform+'.json')
    cmd=[sys.executable,'-B',str(ROOT/'df_collect.py'),'rebuild-state',
         '--platform',a.platform,'--collection-id',COLLECTIONS[a.platform],
         '--project-arn',project,'--build-json',str(build),
         '--runtime-json',str(ROOT/'inputs'/('runtime-'+a.platform+'.json')),
         '--parser',str(ROOT/'parsers'/a.platform/'parse_samples.py'),
         '--core-revision',json.loads(build.read_text())['core_revision'],'--out',str(a.out)]
    if a.platform=='ios':cmd+=['--superseded-attempt','02-B1-2']
    env=dict(os.environ,AWS_PROFILE='minigraf-devicefarm',AWS_REGION='us-west-2')
    result=subprocess.run(cmd,env=env,stdin=subprocess.DEVNULL)
    if result.returncode:return result.returncode
    return subprocess.run([sys.executable,'-B',str(ROOT/'df_collect.py'),'summary','--out',str(a.out)],env=env,stdin=subprocess.DEVNULL).returncode

if __name__=='__main__':raise SystemExit(main())

#!/usr/bin/env bash
# PREPARED FOR THE USER. NOT EXECUTED DURING RECOVERY. This starts Device Farm runs.
set -euo pipefail
export PATH=<node-bin>:$PATH
export AWS_PROFILE=minigraf-devicefarm AWS_REGION=us-west-2
TOOLS=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
OUT=${1:?Usage: bash RESUME-IOS.sh /path/to/df-ios}
# Rehydrate only the account component in memory, and refuse any unexpected state.
INPUTS=$(python -I - "$TOOLS" "$OUT" <<'PY'
import json, runpy, sys
from pathlib import Path
root, out = map(Path, sys.argv[1:])
s = json.loads((out/'state.json').read_text())
assert s['collection_id'] == '11e4c1bc53064fe48b296d713d6fd0ae'
assert s.get('rebuild', {}).get('completed_at'), 'Complete rebuild-state first'
assert all(a['phase'] == 'done' for a in s['attempts']), 'Pending existing attempts need reconciliation'
missing = [f'{i:02d}-{kind}' for i in range(1,7) for kind in ('B1','V','B2')
           if not any(a['valid'] and a['run_index']==i and a['set']==kind for a in s['attempts'])]
assert missing == ['05-B2','06-B1','06-V','06-B2'], 'Recovered slots differ from expected four missing slots'
account = runpy.run_path(str(root/'recover_collection.py'))['project_arn']().split(':')[4]
print(' '.join(s['inputs'][key].replace(':REDACTED:', ':'+account+':') for key in ('app','test_package','pool')))
PY
)
read -r APP TEST POOL <<< "$INPUTS"
python -B "$TOOLS/df_collect.py" collect --platform ios \
  --app-arn "$APP" --test-package-arn "$TEST" --device-pool-arn "$POOL" \
  --build-json "$OUT/build.json" --runtime-json "$OUT/runtime.json" \
  --parser "$OUT/parse_samples.py" \
  --core-revision b0d2d014d57c90680a6adc1d10e749a3db5df40c \
  --max-attempts 54 --max-device-minutes 600 \
  --out "$OUT" --resume < /dev/null

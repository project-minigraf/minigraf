const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const {extract, verify, moduleSource} = require('./verify.cjs');
const manifest = require('./isolation.json');
const production = fs.readFileSync(path.join(__dirname, 'production-bench.yml'), 'utf8');
const body = fs.readFileSync(path.join(__dirname, 'binding.cjs'), 'utf8');

test('extracted body is byte-identical after exactly the recorded substitutions', () => {
  verify(production, body);
});
test('rejects production drift, generated drift, or additional substitutions', () => {
  assert.throws(() => verify(production.replace('per_page: 20,', 'per_page: 21,'), body));
  assert.throws(() => verify(production, body.replace('per_page: 20,', 'per_page: 21,')));
  assert.throws(() => verify(production, body.replace('previous.has(b)', 'true')));
});
test('only two exact one-occurrence substitutions are recorded', () => {
  assert.equal(manifest.substitutions.length, 2);
  const raw = extract(production);
  for (const change of manifest.substitutions) assert.equal(raw.split(change.from).length - 1, 1);
  assert.equal(moduleSource(raw), body);
  assert.match(body, /per_page: 20/);
  assert.match(body, /prevJob.conclusion === 'failure' && !experiment/);
});

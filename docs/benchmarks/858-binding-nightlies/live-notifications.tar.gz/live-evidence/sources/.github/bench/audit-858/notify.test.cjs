const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const notify = require('./notify.cjs');
const binding = require('./binding.cjs');
const session = 'audit-858-20261119';
const alert = id => `- ${id} (Latency): https://bencher.dev/console/projects/minigraf/alerts/example\n`;
const history = (ref, kind) => `History branch: ${ref}; testbed: ${session}-${kind}; executed 2/2;\n`;

async function isolated(fn) {
  const cwd = process.cwd(), env = {...process.env};
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ac9-stage/notify-'));
  process.chdir(dir);
  try { await fn(); } finally {
    process.chdir(cwd);
    for (const key of Object.keys(process.env)) if (!(key in env)) delete process.env[key];
    Object.assign(process.env, env);
    fs.rmSync(dir, {recursive: true, force: true});
  }
}
function fake() {
  const runs = [], issues = [], comments = [], calls = [];
  const github = {rest: {actions: {
    listWorkflowRuns: async args => {
      calls.push(['runs', args]);
      assert.equal(args.branch, 'audit/858-live-checks');
      assert.equal(args.workflow_id, 'bench.yml');
      assert.equal(args.per_page, 20);
      return {data: {workflow_runs: runs.slice(0, args.per_page)}};
    },
    listJobsForWorkflowRun: async args => ({data: {jobs: runs.find(r => r.id === args.run_id).jobs}}),
    downloadJobLogsForWorkflowRun: async args => {
      calls.push(['logs', args]);
      if (args.job_id === 0) throw Object.assign(new Error('Not Found'), {status: 404});
      return {data: runs.flatMap(r => r.jobs).find(j => j.id === args.job_id).text};
    },
  }, issues: {
    listForRepo: async () => ({data: issues}),
    create: async args => {
      const data = {...args, number: issues.length + 1, html_url: 'https://example.invalid/issue/' + (issues.length + 1)};
      issues.push(data); return {data};
    },
    createComment: async args => {
      const data = {...args, id: comments.length + 1, html_url: 'https://example.invalid/comment/' + (comments.length + 1)};
      comments.push(data); return {data};
    },
    get: async args => ({data: issues.find(i => i.number === args.issue_number)}),
    getComment: async args => ({data: comments.find(i => i.id === args.comment_id)}),
    update: async () => { throw Error('must not update'); },
  }}};
  const warnings = [];
  const summary = {addHeading(){return this;}, addRaw(){return this;}, addList(){return this;}, addBreak(){return this;}, async write(){}};
  return {github, runs, issues, comments, calls, warnings, core: {warning: msg => warnings.push(msg), summary}};
}
function configure(kind, stage) {
  const ref = session + (stage === 'other-branch' ? '-other' : '');
  const suite = 'binding_' + kind + (stage === 'other-suite' ? '_other' : '');
  Object.assign(process.env, {KIND: kind, STAGE: stage, BENCH_REF: ref, SUITE: suite,
    AUDIT_TESTBED: session + '-' + kind, GITHUB_REF_NAME: 'audit/858-live-checks', BENCH_SHA: 'a'.repeat(40)});
  return {ref, suite};
}
const context = id => ({repo: {owner: 'example', repo: 'test'}, runId: id, serverUrl: 'https://example.invalid'});

for (const kind of ['jvm', 'wasi']) {
  test(`${kind}: eight stages use real production body with mocked API transport`, () => isolated(async () => {
    const f = fake();
    configure(kind, 'first');
    f.runs.push({id: 1, display_title: `Nightly Benchmarks (${session})`, html_url: 'https://example.invalid/run/1',
      jobs: [{id: 10, name: 'bench / binding_' + kind, conclusion: 'success', text: history(session, kind)}]});
    const stages = ['first', 'other-branch', 'repeat', 'other-suite', 'reset-first', 'different-id', 'lookup-error', 'upload-failure'];
    for (const [index, stage] of stages.entries()) {
      const {ref, suite} = configure(kind, stage), runId = index + 2;
      const id = `audit/858/20261119/${kind}/${['different-id', 'lookup-error'].includes(stage) ? 'secondary' : 'primary'}`;
      const output = stage === 'upload-failure' ? 'HTTP 404 upload failed\n' : alert(id);
      fs.writeFileSync('binding-bencher.txt', output);
      await notify({github: f.github, core: f.core, context: context(runId)});
      const receipt = JSON.parse(fs.readFileSync('notification-receipt.json'));
      assert.equal(receipt.writes.length, ['repeat', 'reset-first', 'upload-failure'].includes(stage) ? 1 : 0, stage);
      if (stage === 'lookup-error') {
        assert.ok(receipt.warnings.some(w => w.includes('Could not read')));
        assert.ok(receipt.messages.includes('Alerts in previous run: none'));
        assert.ok(receipt.records.some(r => r.status === 404 && r.args.job_id === 0));
      }
      f.runs.unshift({id: runId, display_title: `Nightly Benchmarks (${ref})`, html_url: 'https://example.invalid/run/' + runId,
        jobs: [{id: runId * 10, name: 'bench / ' + suite, conclusion: stage === 'upload-failure' ? 'failure' : 'success', text: history(ref, kind) + output}]});
    }
    assert.equal(f.issues.length, 1);
    assert.equal(f.comments.length, 2);
    assert.match(f.issues[0].body, /primary/);
    assert.match(f.comments[0].body, /primary/);
    assert.match(f.comments[1].body, /listed no alerts/);
  }));
}

for (const scenario of ['matching', 'wrong-history', 'clean', 'failed-without-summary', 'experiment', 'beyond-20']) {
  test(`bounded lookup: ${scenario}`, () => isolated(async () => {
    const f = fake(), kind = 'jvm', id = 'audit/858/20261119/jvm/primary';
    configure(kind, 'repeat');
    fs.writeFileSync('binding-bencher.txt', alert(id));
    const run = (n, text, conclusion = 'success') => ({id: n, display_title: `Nightly Benchmarks (${session})`,
      html_url: 'https://example.invalid/run/' + n, jobs: [{id: n * 10, name: 'bench / binding_jvm', text, conclusion}]});
    const older = run(1, history(session, kind) + alert(id));
    if (scenario === 'matching') f.runs.push(older);
    if (scenario === 'wrong-history') f.runs.push(run(2, `History branch: v3; testbed: binding-jvm-ubuntu24-v1;\n` + alert(id)));
    if (scenario === 'clean') f.runs.push(run(2, history(session, kind)), older);
    if (scenario === 'failed-without-summary') f.runs.push(run(2, alert(id), 'failure'), older);
    if (scenario === 'experiment') f.runs.push(run(2, `History branch: binding-experiment/other; testbed: ${session}-jvm;\n`, 'failure'), older);
    if (scenario === 'beyond-20') {
      for (let i = 25; i > 5; i--) f.runs.push({...run(i, ''), display_title: `Nightly Benchmarks (${session}-other)`});
      f.runs.push(older);
    }
    await binding({github: f.github, core: f.core, context: context(100)});
    assert.equal(f.issues.length, ['matching', 'experiment'].includes(scenario) ? 1 : 0);
    if (scenario === 'failed-without-summary') assert.ok(f.warnings.some(w => w.includes('breaking the alert streak')));
  }));
}

test('wrapper rejects production scope before calling any API', () => isolated(async () => {
  const f = fake();
  configure('jvm', 'first');
  process.env.BENCH_REF = 'v3';
  await assert.rejects(notify({github: f.github, core: f.core, context: context(1)}));
  assert.deepEqual(f.calls, []);
}));

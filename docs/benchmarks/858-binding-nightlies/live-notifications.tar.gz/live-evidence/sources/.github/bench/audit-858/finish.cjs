const fs = require('node:fs');
const assert = require('node:assert/strict');
const {audit} = require('./report.cjs');
const session = 'audit-858-20261119';
const {STAGE: stage, KIND: kind, SUITE: suite, BENCH_REF: ref, AUDIT_TESTBED: testbed} = process.env;
assert.ok(['jvm', 'wasi'].includes(kind));
assert.ok([session, session + '-other'].includes(ref));
assert.equal(testbed, session + '-' + kind);
const read = p => fs.existsSync(p) ? fs.readFileSync(p, 'utf8') : '';
const selected = ['primary', 'secondary'].map(name => `audit/858/20261119/${kind}/${name}`);
const result = stage === 'seed' ? {uploadStatus: process.env.BENCHER_OUTCOME, errors: []} :
  audit(selected, read('fixture-execution.txt'), read('binding-bencher.txt'), process.env.BENCHER_OUTCOME);
if (stage === 'seed' && result.uploadStatus !== 'success') result.errors.push('Seed upload failed');
const report = {stage, suite, ref, historyBranch: ref, testbed, selected, ...result};
fs.writeFileSync('binding-report.json', JSON.stringify(report, null, 2) + '\n');
// The production lookup consumes this exact line from real previous job logs.
const summary = `History branch: ${ref}; testbed: ${testbed}; upload ${result.uploadStatus}; synthetic fixture\n` +
  result.errors.map(error => `- ${error}\n`).join('');
console.log(summary);
if (process.env.GITHUB_STEP_SUMMARY) fs.appendFileSync(process.env.GITHUB_STEP_SUMMARY, summary);
if (result.errors.length) process.exitCode = 1;

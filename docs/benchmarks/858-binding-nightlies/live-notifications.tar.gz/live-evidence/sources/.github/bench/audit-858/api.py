"""Bencher REST transport. Never log tokens or response error bodies."""
import json
import os
from urllib.error import HTTPError
from urllib.request import Request, urlopen

BASE = 'https://api.bencher.dev/v0/projects/minigraf/'


def request(path, method='GET'):
    headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer ' + os.environ['BENCHER_API_TOKEN']}
    try:
        with urlopen(Request(BASE + path, headers=headers, method=method), timeout=60) as response:
            body = response.read()
            return response.status, json.loads(body) if body else None, dict(response.headers)
    except HTTPError as error:
        if method == 'GET' and error.code == 404:
            return 404, None, {}
        raise RuntimeError(f'{method} {path}: HTTP {error.code}') from None

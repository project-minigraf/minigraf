// Verify the YAML scalar bytes, excluding YAML indentation and trailing blank lines.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const manifest = require('./isolation.json');
const sha = text => crypto.createHash('sha256').update(text).digest('hex');
function extract(yaml) {
  const job = yaml.indexOf('\n  bindings:\n');
  assert.ok(job >= 0, 'Missing production bindings job');
  const report = yaml.indexOf('      - name: Report regression\n', job);
  assert.ok(report >= 0, 'Missing binding Report regression');
  const marker = '          script: |\n';
  const start = yaml.indexOf(marker, report);
  assert.ok(start >= 0, 'Missing github-script scalar');
  const lines = [];
  for (const line of yaml.slice(start + marker.length).split('\n')) {
    if (line && !line.startsWith('            ')) break;
    lines.push(line ? line.slice(12) : '');
  }
  while (lines.at(-1) === '') lines.pop();
  return lines.join('\n') + '\n';
}
function moduleSource(raw) {
  let isolated = raw;
  for (const {from, to} of manifest.substitutions) {
    assert.equal(isolated.split(from).length - 1, 1, `Substitution must match once: ${from}`);
    isolated = isolated.replace(from, to);
  }
  return 'module.exports = async function ({github, context, core}) {\n' + isolated + '};\n';
}
function verify(production, generated) {
  assert.equal(sha(production), manifest.productionWorkflowSha256, 'Production snapshot drift');
  const raw = extract(production);
  assert.equal(sha(raw), manifest.productionBodySha256, 'Production notification body drift');
  assert.equal(generated, moduleSource(raw), 'Notification body differs beyond recorded substitutions');
}
module.exports = {extract, moduleSource, verify};
if (require.main === module) {
  const production = fs.readFileSync(process.argv[2] || path.join(__dirname, 'production-bench.yml'), 'utf8');
  verify(production, fs.readFileSync(path.join(__dirname, 'binding.cjs'), 'utf8'));
  console.log(`Verified production binding body at ${manifest.productionCommit}; exactly ${manifest.substitutions.length} substitutions.`);
}

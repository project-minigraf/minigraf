const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const {spawnSync} = require('node:child_process');
const os = require('node:os');
const workflow = fs.readFileSync(path.join(__dirname, '../../workflows/bench.yml'), 'utf8');

test('disposable workflow uses production lookup identity, both suites and isolated serialization', () => {
  assert.match(workflow, /name: Nightly Benchmarks\nrun-name: Nightly Benchmarks \(\$\{\{ inputs.route \}\}\)/);
  assert.match(workflow, /name: bench \/ \$\{\{ matrix.suite \}\}/);
  assert.match(workflow, /kind: jvm, suite: binding_jvm/);
  assert.match(workflow, /kind: wasi, suite: binding_wasi/);
  assert.match(workflow, /group: audit-858-live-notifications/);
  assert.match(workflow, /require\('\.\/\.github\/bench\/audit-858\/notify.cjs'\)/);
  assert.match(workflow, /node \.github\/bench\/audit-858\/verify.cjs/);
  assert.match(workflow, /if: always\(\)\n        env:\n          BENCHER_OUTCOME/);
  assert.doesNotMatch(workflow, /schedule:|start-point|binding-.*-ubuntu24-v1/);
});

for (const kind of ['jvm', 'wasi']) {
  test(`${kind}: finish emits matching history line and fails upload completeness`, () => {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ac9-stage/finish-'));
    try {
      const childEnv = {...process.env};
      delete childEnv.NODE_TEST_CONTEXT;
      const log = path.join(dir, 'child.log');
      const fd = fs.openSync(log, 'w');
      const result = spawnSync(process.execPath, [path.join(__dirname, 'finish.cjs')], {cwd: dir, stdio: ['ignore', fd, fd],
        env: {...childEnv, STAGE: 'upload-failure', KIND: kind, SUITE: 'binding_' + kind,
          BENCH_REF: 'audit-858-20261119', AUDIT_TESTBED: 'audit-858-20261119-' + kind,
          BENCHER_OUTCOME: 'failure', GITHUB_STEP_SUMMARY: path.join(dir, 'summary')}});
      fs.closeSync(fd);
      assert.ifError(result.error);
      assert.equal(result.status, 1);
      assert.ok(fs.readFileSync(log, 'utf8').includes(`History branch: audit-858-20261119; testbed: audit-858-20261119-${kind};`));
      const report = JSON.parse(fs.readFileSync(path.join(dir, 'binding-report.json')));
      assert.equal(report.uploadStatus, 'error');
      assert.ok(report.errors.some(e => e.includes('Upload: missing')));
    } finally { fs.rmSync(dir, {recursive: true, force: true}); }
  });
}

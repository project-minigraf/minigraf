# #858 AC9 disposable binding notification harness

Prepared locally; no live uploads, dispatches, notifications, or cleanup have been
performed by this harness delivery. This directory and the replacement
`.github/workflows/bench.yml` belong **only** on `audit/858-live-checks`. Never merge
that replacement into `main` or `v3`. The separate
`.github/workflows/audit-858-cleanup.yml` shares its audit-only concurrency group.

This follows the #840 protocol in `docs/benchmarks/840-regression/live-checks.md`
and its archived fixture, report, notifier, and cleanup pattern. It changes no
runtime code, Rust tests, production benchmark values, or production histories.
The tested production binding notification script is pinned to `origin/v3` at
`b0d2d014d57c90680a6adc1d10e749a3db5df40c`. `production-bench.yml` is its source
snapshot, not an executable workflow in this directory.

## Isolation and exact production-body reuse

`binding.cjs` contains the binding job's `Report regression` github-script body,
wrapped in an async CommonJS function. YAML scalar indentation and trailing blank
lines are removed; every remaining byte is preserved except these two one-match
substitutions, also recorded with source hashes in `isolation.json`:

| Production text | Disposable text | Purpose |
|---|---|---|
| `branch: 'main',` | `branch: process.env.GITHUB_REF_NAME,` | Read completed runs on `audit/858-live-checks`, still using workflow ID `bench.yml`. |
| `` const testbed = `binding-${suite.slice('binding_'.length)}-ubuntu24-v1`; `` | `const testbed = process.env.AUDIT_TESTBED;` | Match the dedicated audit testbed in prior job logs. |

The workflow name is `Nightly Benchmarks`, the run title is
`Nightly Benchmarks (<route>)`, and jobs are `bench / binding_jvm` and
`bench / binding_wasi`. Only `other-suite` adds `_other` to the job and suite.
`finish.cjs` emits the exact matching prefix from the job itself:

```text
History branch: audit-858-20261119; testbed: audit-858-20261119-jvm;
History branch: audit-858-20261119; testbed: audit-858-20261119-wasi;
```

The `other-branch` stage emits `audit-858-20261119-other` in that line. Both suite
variants use the same lane-specific testbed; the job-name check supplies suite
isolation. The production 20-completed-run walk, run-title check, job-name check,
log matching, and failed-job streak break are otherwise unchanged. These checks
do not prove the unmodified default-branch or production-testbed lookup.

`notify.cjs` guards scope, records actual API calls/results and warnings, and reads
back created issues/comments through separate GET calls. For `lookup-error` only,
it passes `job_id: 0` to the real job-log API instead of the selected prior job ID;
it records both arguments and requires HTTP 404, a `Could not read` warning,
`Alerts in previous run: none`, and zero issue writes. This deliberate transport
fault is outside the production body; it is not a third body substitution.

## Stage order and expected results

Run each dispatch to completion before starting the next. A concurrency group
prevents overlap but does not guarantee ordering of queued dispatches. Run the
sequence once on fresh resources; reruns change history and invalidate the table.
Every dispatch runs both suites. Use route `audit-858-20261119` except where shown.

First run `seed`: five independent uploads per lane per branch with values
99, 100, 101, 99, 100 for both IDs. Expect success and no notification. Preserve
seed logs and confirm numeric Bencher comparison baselines/upper limits before
continuing; local tests cannot establish live numeric comparisons.

The eight #840 scenarios then apply independently to **each** suite:

| Order / stage | Route | Values (primary, secondary) | Expected alert and notification |
|---|---|---|---|
| 1. `first` | session | 1e6, 100 | Primary alerts; no prior exact ID; no issue/comment. |
| 2. `other-branch` | session + `-other` | 1e6, 100 | Primary alerts; the other route cannot use stage 1; no issue/comment. |
| 3. `repeat` | session | 1e12, 100 | Primary repeats stage 1 across the unrelated branch run; opens the suite issue (comments if that exact issue is already open). |
| 4. `other-suite` | session | 1e18, 100 | Primary alerts under `binding_<lane>_other`; no matching prior job; no issue/comment. |
| 5. `reset-first` | session | 1e24, 100 | Primary repeats stage 3: the bounded walk skips stage 4's different job name; comments on the suite issue. |
| 6. `different-id` | session | 100, 1e6 | Secondary alerts but the prior same-suite alert is primary; no issue/comment. |
| 7. `lookup-error` | session | 100, 1e12 | Secondary alerts; actual prior-log GET fails; warning plus empty prior set; no issue/comment. |
| 8. `upload-failure` | session | 100, 100 | Real upload failure without alerts; immediate comment; completeness audit and workflow fail as expected. |

`reset-first` retains #840's stage name, but **does not reset** the current
production bounded walk. #840's older single-run lookup suppressed this stage;
copying that expectation would mis-test the current body. The first seven
scenario jobs should succeed after checking their intentional alert exits;
`upload-failure` should fail the always-run completeness check after notification.

`fixture.py` invokes Bencher 0.4.25 with JSON values, `t_test`, upper boundary
0.999, maximum sample size 30, and no start point. Upload failure changes only the
project argument to valid-but-nonexistent UUID
`00000000-0000-0000-0000-000000000858`; it uses the same credential. If that UUID
unexpectedly exists, stop: the scenario is invalid. No alerts are fabricated in
live runs. `fixture-execution.txt` is explicitly a synthetic execution record,
not a timed Criterion or foreign-runtime measurement.

## Resources and evidence

Exact allowlists (a matching prefix alone is insufficient):

- Branches: `audit-858-20261119`, `audit-858-20261119-other`.
- Testbeds: `audit-858-20261119-jvm`, `audit-858-20261119-wasi`.
- IDs: `audit/858/20261119/<jvm|wasi>/<primary|secondary>` (four total).
- Issue titles: `Benchmark regression: binding_jvm (audit-858-20261119)` and
  `Benchmark regression: binding_wasi (audit-858-20261119)`.

A single successful sequence should leave 34 reports, four thresholds, two
branches, two testbeds, four benchmarks, two issues, and four comments. Counts
are expectations, not substituted API evidence. There are no separate `_other`
testbeds or IDs, and no reports from the failed upload.

`main`, `v3`, `ubuntu-latest`, `binding-jvm-ubuntu24-v1`,
`binding-wasi-ubuntu24-v1`, all other production testbeds, and non-allowlisted IDs
are forbidden upload/deletion scope. Credentials come from `BENCHER_API_TOKEN`;
commands containing credentials are never printed. Captured fixture output
redacts the token as an additional precaution.

Retain each run URL, job log, fixture, Bencher report/alert UUID, and
`notification-receipt.json` (candidate runs/jobs, selected log or lookup failure,
issue/comment URLs, read-back bodies). The `binding-report.json` and job summary
record actual upload completeness. Archive these with checksums beyond the
30-day artifact retention before cleanup. Delivery means a verified GitHub issue
or comment, not proof of receipt by a human mailbox.

## Collect and clean up

`collect.py PLAN.json` uses authenticated Bencher REST GETs with pagination to
collect the complete disposable report/threshold records, branches, testbeds,
and benchmark UUIDs. It refuses inherited branch start points, foreign
relationships, malformed/duplicate UUIDs, and incomplete resource scope. It
never prints the token. No resource UUID plan is fabricated or bundled now:
it must be collected after the actual live sequence.

After archiving scenario evidence:

1. Dispatch `audit-858-cleanup.yml` on `audit/858-live-checks` with mode `collect`
   (or run the collector in the authorized environment). Archive its
   `cleanup-plan.json` and SHA-256. Review its names, UUIDs, and expected counts.
2. Place that exact recorded plan at `.github/bench/audit-858/cleanup-plan.json`
   on the disposable branch. Dispatch cleanup mode `execute`.
3. `cleanup.py execute PLAN.json` validates the saved plan, re-collects the live
   plan, and requires identical UUID sets and name-to-UUID mappings **before any
   DELETE**. It deletes only reports, thresholds, branches, testbeds, benchmarks,
   in that order. Every DELETE is followed by a GET requiring 404. Preserve
   `cleanup-receipts.json`; partial deletion receipts survive an error. A partial
   failure requires reconciliation, not blindly replaying an obsolete plan.
4. Independently verify deletion, close only the two recorded test issues after
   checking their exact titles, then remove the temporary workflow branch when
   all evidence is archived. The Bencher cleanup script does not mutate GitHub
   issues, branches, normal Actions runs, projects, measures, or credentials.

The cleanup workflow uses the same audit concurrency group so it cannot overlap
a fixture dispatch. Keep the repository quiescent for these resources during
collection/execution; do not enqueue another scenario while cleaning up.

## Local verification

Run from a disposable repository copy with these files overlaid. For this local
build, the source was copied with `rsync`, excluding `.git` and `target/`, into
`/tmp/ac9-stage/repo-copy`. All test scratch files use `/tmp/ac9-stage/`.

```sh
python3 -m unittest discover -s .github/bench/audit-858 -p 'test_*.py'
node --test --test-isolation=none .github/bench/audit-858/*.test.cjs
node .github/bench/audit-858/verify.cjs /path/to/read-only/production/.github/workflows/bench.yml
```

The Node command uses a version supporting `--test-isolation=none` (local
verification used Node 26). Without that flag, run each `.test.cjs` directly with
Node; each uses `node:test`. Local child-process output is captured to files to
avoid sandbox pipe restrictions. These checks never invoke Bencher or contact
GitHub/Bencher. The workflow's `verify.cjs` invocation defaults to the bundled
pinned production snapshot; passing an external production file additionally
checks that source for drift. Any source or notification-body drift fails.

Files: `fixture.py`/`scope.py` enforce upload scope; `binding.cjs`, `notify.cjs`,
`isolation.json`, `production-bench.yml`, and `verify.cjs` preserve and check the
notifier; `report.cjs`/`finish.cjs` check uploads and emit the history line;
`api.py`, `collect.py`, and `cleanup.py` implement planned cleanup; the Python
and Node test files exercise guards, parser failures, notification stages, and
lookup edges. The two workflows supply scenario and cleanup dispatch entrypoints.

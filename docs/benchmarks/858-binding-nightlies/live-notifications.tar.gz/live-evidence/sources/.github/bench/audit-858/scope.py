"""Exact disposable scope; a prefix alone never authorizes a write."""
SESSION = 'audit-858-20261119'
WORKFLOW_REF = 'audit/858-live-checks'
KINDS = ('jvm', 'wasi')
BRANCHES = {SESSION, SESSION + '-other'}
TESTBEDS = {SESSION + '-' + kind for kind in KINDS}


def require(condition, message='Outside the disposable #858 scope'):
    if not condition:
        raise ValueError(message)


def ids_for(kind):
    require(kind in KINDS)
    return [f'audit/858/20261119/{kind}/{case}' for case in ('primary', 'secondary')]


BENCHMARKS = {name for kind in KINDS for name in ids_for(kind)}

import unittest
from unittest.mock import patch
import fixture
from scope import SESSION, WORKFLOW_REF, ids_for


def environment(kind='jvm', stage='first'):
    return dict(KIND=kind, STAGE=stage, BENCH_REF=SESSION + ('-other' if stage == 'other-branch' else ''),
                SUITE=f'binding_{kind}' + ('_other' if stage == 'other-suite' else ''),
                AUDIT_TESTBED=SESSION + '-' + kind, GITHUB_REF_NAME=WORKFLOW_REF,
                GITHUB_SHA='a' * 40, WORKFLOW_SHA='b' * 40, BENCHER_API_TOKEN='test-token')


class FixtureTests(unittest.TestCase):
    def test_each_stage_and_lane(self):
        for kind in ('jvm', 'wasi'):
            for stage in fixture.STAGES:
                with self.subTest(kind=kind, stage=stage):
                    config = fixture.configuration(environment(kind, stage))
                    self.assertEqual(config['ids'], ids_for(kind))

    def test_refuses_foreign_scope(self):
        for key, values in {
            'BENCH_REF': ['main', 'v3', 'audit-858-other-session', '../audit-858'],
            'AUDIT_TESTBED': ['ubuntu-latest', 'binding-jvm-ubuntu24-v1', 'binding-wasi-ubuntu24-v1', 'audit-858-foreign'],
            'KIND': ['native', 'python', '../jvm'],
            'SUITE': ['binding_wasi', 'binding_jvm_other', 'binding_python'],
            'GITHUB_REF_NAME': ['main', 'v3', 'audit/foreign'],
            'STAGE': ['cleanup', 'unknown'],
        }.items():
            for value in values:
                with self.subTest(key=key, value=value), self.assertRaises((AssertionError, ValueError)):
                    fixture.configuration({**environment(), key: value})

    def test_route_stage_cannot_be_crossed(self):
        for stage in fixture.STAGES:
            env = environment(stage=stage)
            env['BENCH_REF'] = SESSION if stage == 'other-branch' else SESSION + '-other'
            with self.assertRaises((AssertionError, ValueError)):
                fixture.configuration(env)

    def test_command_is_isolated_and_failure_changes_only_project(self):
        for kind in ('jvm', 'wasi'):
            config = fixture.configuration(environment(kind))
            with patch.dict('os.environ', {'BENCHER_API_TOKEN': 'test-token'}):
                normal = fixture.command(config)
                failed = fixture.command(config, fail=True)
            self.assertEqual(normal[:2], ['bencher', 'run'])
            for option, value in [('--branch', SESSION), ('--testbed', SESSION + '-' + kind),
                                  ('--threshold-test', 't_test'), ('--threshold-max-sample-size', '30'),
                                  ('--threshold-upper-boundary', '0.999')]:
                self.assertEqual(normal[normal.index(option) + 1], value)
            self.assertFalse(any('start-point' in arg for arg in normal))
            diffs = [i for i, pair in enumerate(zip(normal, failed)) if pair[0] != pair[1]]
            self.assertEqual(diffs, [normal.index('--project') + 1])
            self.assertEqual(failed[diffs[0]], '00000000-0000-0000-0000-000000000858')

    def test_command_revalidates_mutated_scope_and_ids(self):
        for field, value in [('route', 'v3'), ('testbed', 'ubuntu-latest'), ('ids', ['query/production']),
                             ('ids', ['audit/858/foreign/jvm/primary'])]:
            config = fixture.configuration(environment())
            config[field] = value
            with patch.dict('os.environ', {'BENCHER_API_TOKEN': 'test-token'}), self.assertRaises((AssertionError, ValueError)):
                fixture.command(config)


if __name__ == '__main__':
    unittest.main()

"""Collect the post-scenario resource UUID plan through authenticated GETs only."""
import json
from pathlib import Path
import sys
from urllib.parse import urlencode
from api import request
from scope import BRANCHES, TESTBEDS, require


def listed(kind, branch):
    require(kind in ('reports', 'thresholds') and branch in BRANCHES)
    result, page = [], 1
    while True:
        status, rows, headers = request(kind + '?' + urlencode(dict(branch=branch, expand='true', per_page=100, page=page)))
        require(status == 200 and isinstance(rows, list), 'Invalid API list')
        result.extend(rows)
        total = next(int(value) for key, value in headers.items() if key.lower() == 'x-total-count')
        if len(result) == total:
            return result
        require(rows and len(result) < total, 'Invalid API pagination')
        page += 1


def collect_plan():
    from cleanup import validate_plan
    result = {kind: [] for kind in ('reports', 'thresholds', 'branches', 'testbeds', 'benchmarks')}
    benchmarks = {}
    for branch in sorted(BRANCHES):
        status, value, _ = request('branches/' + branch)
        require(status == 200 and value['name'] == branch)
        result['branches'].append(value)
        for kind in ('reports', 'thresholds'):
            rows = listed(kind, branch)
            for row in rows:
                require(row['branch']['name'] == branch and row['testbed']['name'] in TESTBEDS)
            result[kind].extend(rows)
        for report in result['reports']:
            for iteration in report['results']:
                for row in iteration:
                    benchmark = row['benchmark']
                    previous = benchmarks.get(benchmark['uuid'])
                    require(previous is None or previous['name'] == benchmark['name'])
                    benchmarks[benchmark['uuid']] = benchmark
    for testbed in sorted(TESTBEDS):
        status, value, _ = request('testbeds/' + testbed)
        require(status == 200 and value['name'] == testbed)
        result['testbeds'].append(value)
    result['benchmarks'] = sorted(benchmarks.values(), key=lambda b: b['name'])
    validate_plan(result)
    return result


if __name__ == '__main__':
    result = collect_plan()
    Path(sys.argv[1]).write_text(json.dumps(result, indent=2) + '\n')
    print({kind: len(rows) for kind, rows in result.items()})

"""Controlled values, not runtime measurements. No production history writes."""
import json
import os
from pathlib import Path
import subprocess
import sys
from scope import SESSION, WORKFLOW_REF, KINDS, ids_for, require

VALUES = {
    'first': [1e6, 100], 'other-branch': [1e6, 100],
    'repeat': [1e12, 100], 'other-suite': [1e18, 100],
    'reset-first': [1e24, 100], 'different-id': [100, 1e6],
    'lookup-error': [100, 1e12], 'upload-failure': [100, 100],
}
STAGES = ('seed', *VALUES)


def validate(config):
    kind, stage = config['kind'], config['stage']
    require(kind in KINDS and stage in STAGES)
    require(config['workflow_ref'] == WORKFLOW_REF)
    require(config['route'] == SESSION + ('-other' if stage == 'other-branch' else ''))
    require(config['suite'] == 'binding_' + kind + ('_other' if stage == 'other-suite' else ''))
    require(config['testbed'] == SESSION + '-' + kind)
    require(config['ids'] == ids_for(kind))


def configuration(env):
    config = dict(kind=env['KIND'], stage=env['STAGE'], route=env['BENCH_REF'],
                  suite=env['SUITE'], testbed=env['AUDIT_TESTBED'], ids=ids_for(env['KIND']),
                  workflow_ref=env['GITHUB_REF_NAME'], sha=env['GITHUB_SHA'], workflow_sha=env['WORKFLOW_SHA'])
    validate(config)
    return config


def command(config, fail=False):
    validate(config)
    project = '00000000-0000-0000-0000-000000000858' if fail else 'minigraf'
    return ['bencher', 'run', '--project', project, '--token', os.environ['BENCHER_API_TOKEN'],
            '--branch', config['route'], '--hash', config['sha'], '--testbed', config['testbed'],
            '--threshold-measure', 'latency', '--threshold-test', 't_test',
            '--threshold-max-sample-size', '30', '--threshold-upper-boundary', '0.999',
            '--err', '--adapter', 'json', '--file', 'fixture.json']


def upload(config, values, output, fail=False):
    args = command(config, fail=fail)
    require(len(values) == len(config['ids']))
    Path('fixture.json').write_text(json.dumps({name: {'latency': {'value': value}}
                                               for name, value in zip(config['ids'], values)}))
    # Never log argv: the credential exists only at runtime.
    result = subprocess.run(args, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    output_bytes = result.stdout.replace(os.environ['BENCHER_API_TOKEN'].encode(), b'[REDACTED]')
    Path(output).write_bytes(output_bytes)
    sys.stdout.buffer.write(output_bytes)
    return result.returncode


def main():
    config = configuration(os.environ)
    Path('bench-selection.json').write_text(json.dumps(dict(suite=config['suite'], ref=config['route'],
        sha=config['sha'], workflowSha=config['workflow_sha'], selected=config['ids'],
        filter='^audit/858/', threshold='0.999')))
    Path('fixture-execution.txt').write_text(''.join(f'Benchmarking {name}: Analyzing\n' for name in config['ids']))
    if config['stage'] == 'seed':
        for route in (SESSION, SESSION + '-other'):
            # Seed both routes with the same guarded uploader used by scenarios.
            seed = dict(config, stage='first' if route == SESSION else 'other-branch', route=route)
            for index, value in enumerate((99, 100, 101, 99, 100)):
                code = upload(seed, [value, value], f'seed-{route}-{index}.txt')
                if code:
                    return code
        return 0
    code = upload(config, VALUES[config['stage']], 'bencher_out.txt', fail=config['stage'] == 'upload-failure')
    Path('binding-bencher.txt').write_bytes(Path('bencher_out.txt').read_bytes())
    return code


if __name__ == '__main__':
    sys.exit(main())

import copy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from uuid import uuid5, NAMESPACE_URL
import cleanup
import api
import collect
from scope import BRANCHES, TESTBEDS, BENCHMARKS


def resource(name):
    return dict(name=name, uuid=str(uuid5(NAMESPACE_URL, name)))


def candidate():
    result = dict(branches=[dict(resource(n), head={'start_point': None}) for n in sorted(BRANCHES)],
                  testbeds=[resource(n) for n in sorted(TESTBEDS)], benchmarks=[resource(n) for n in sorted(BENCHMARKS)],
                  reports=[], thresholds=[])
    for branch in result['branches']:
        for testbed in result['testbeds']:
            name = branch['name'] + '/' + testbed['name']
            refs = dict(branch=branch, testbed=testbed)
            benchmarks = [b for b in result['benchmarks'] if '/' + testbed['name'].rsplit('-', 1)[1] + '/' in b['name']]
            result['reports'].append(dict(uuid=resource(name)['uuid'], results=[[dict(benchmark=b) for b in benchmarks]], **refs))
            result['thresholds'].append(dict(uuid=resource(name + '/threshold')['uuid'], **refs))
    return result


class CleanupTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        Path('/tmp/ac9-stage').mkdir(exist_ok=True)

    def test_fixed_scope_allowed(self):
        cleanup.validate_plan(candidate())

    def test_names_and_start_points_fail_closed(self):
        for kind, names in {
            'branches': ['main', 'v3', 'audit-858-foreign', 'foreign'],
            'testbeds': ['ubuntu-latest', 'binding-jvm-ubuntu24-v1', 'binding-wasi-ubuntu24-v1', 'binding-python-ubuntu24-v1', 'foreign'],
            'benchmarks': ['query/production', 'audit/858/foreign/jvm/primary', 'audit/840/x'],
        }.items():
            for name in names:
                plan = candidate()
                plan[kind][0]['name'] = name
                with self.subTest(kind=kind, name=name), self.assertRaises((AssertionError, ValueError)):
                    cleanup.validate_plan(plan)
        plan = candidate()
        plan['branches'][0]['head']['start_point'] = {'branch': 'main'}
        with self.assertRaises((AssertionError, ValueError)):
            cleanup.validate_plan(plan)

    def test_foreign_report_or_threshold_and_uuid_injection_rejected(self):
        for kind in ('reports', 'thresholds'):
            for field, value in [('branch', resource('v3')), ('testbed', resource('ubuntu-latest'))]:
                plan = candidate()
                plan[kind][0][field] = value
                with self.assertRaises((AssertionError, ValueError)):
                    cleanup.validate_plan(plan)
        for kind in candidate():
            plan = candidate()
            plan[kind][0]['uuid'] = '../../branches/v3'
            with self.assertRaises((AssertionError, ValueError)):
                cleanup.validate_plan(plan)
        plan = candidate()
        plan['reports'][0]['results'][0][0]['benchmark'] = resource('query/production')
        with self.assertRaises((AssertionError, ValueError)):
            cleanup.validate_plan(plan)

    def test_changed_plan_never_deletes(self):
        original = candidate()
        current = copy.deepcopy(original)
        current['reports'][0]['uuid'] = resource('new report')['uuid']
        with tempfile.TemporaryDirectory(dir='/tmp/ac9-stage') as tmp:
            path = Path(tmp) / 'plan.json'
            path.write_text(json.dumps(original))
            with patch.object(cleanup, 'collect_plan', return_value=current), patch.object(cleanup, 'request') as request:
                with self.assertRaises((AssertionError, ValueError)):
                    cleanup.execute(path, Path(tmp) / 'receipts.json')
                request.assert_not_called()

    def test_deletes_in_dependency_order_and_verifies_every_uuid(self):
        plan = candidate()
        calls = []
        def request(path, method='GET'):
            calls.append((path, method))
            return (204, None, {}) if method == 'DELETE' else (404, None, {})
        with tempfile.TemporaryDirectory(dir='/tmp/ac9-stage') as tmp:
            path, receipts = Path(tmp) / 'plan.json', Path(tmp) / 'receipts.json'
            path.write_text(json.dumps(plan))
            with patch.object(cleanup, 'collect_plan', return_value=plan), patch.object(cleanup, 'request', request):
                cleanup.execute(path, receipts)
            expected = [(kind + '/' + r['uuid'], method) for kind in cleanup.ORDER for r in plan[kind] for method in ('DELETE', 'GET')]
            self.assertEqual(calls, expected)
            self.assertEqual(len(json.loads(receipts.read_text())), len(expected) // 2)

    def test_api_authenticates_gets_without_printing_token(self):
        class Response:
            status, headers = 200, {}
            def __enter__(self):
                return self
            def __exit__(self, *args):
                pass
            def read(self):
                return b'[]'
        with patch.dict('os.environ', {'BENCHER_API_TOKEN': 'local-test-secret'}), patch.object(api, 'urlopen', return_value=Response()) as opened:
            self.assertEqual(api.request('reports?branch=audit-858-20261119')[0], 200)
            request = opened.call_args.args[0]
            self.assertEqual(request.get_header('Authorization'), 'Bearer local-test-secret')
            self.assertEqual(request.get_method(), 'GET')

    def test_failed_verification_preserves_partial_receipts(self):
        plan = candidate()
        with tempfile.TemporaryDirectory(dir='/tmp/ac9-stage') as tmp:
            path, receipts = Path(tmp) / 'plan.json', Path(tmp) / 'receipts.json'
            path.write_text(json.dumps(plan))
            with patch.object(cleanup, 'collect_plan', return_value=plan), patch.object(cleanup, 'request', side_effect=[(204, None, {}), (200, {}, {})]) as req:
                with self.assertRaises(ValueError):
                    cleanup.execute(path, receipts)
                self.assertEqual(req.call_count, 2)
            self.assertEqual(json.loads(receipts.read_text())[0]['verification_status'], 200)

    def test_collector_paginates_and_validates_api_records(self):
        plan = candidate()
        def request(path, method='GET'):
            kind, name = path.split('/')
            return 200, next(row for row in plan[kind] if row['name'] == name), {}
        def listed(kind, branch):
            return [r for r in plan[kind] if r['branch']['name'] == branch]
        with patch.object(collect, 'request', request), patch.object(collect, 'listed', listed):
            self.assertEqual(collect.collect_plan(), plan)
        pages = [(200, [1], {'X-Total-Count': '2'}), (200, [2], {'x-total-count': '2'})]
        with patch.object(collect, 'request', side_effect=pages) as req:
            self.assertEqual(collect.listed('reports', sorted(BRANCHES)[0]), [1, 2])
            self.assertIn('page=2', req.call_args.args[0])


if __name__ == '__main__':
    unittest.main()

// Observe real calls and guard issue writes; the production body is in binding.cjs.
const fs = require('node:fs');
const assert = require('node:assert/strict');
const session = 'audit-858-20261119';
module.exports = async ({github, context, core}) => {
  const {STAGE: stage, KIND: kind, SUITE: suite, BENCH_REF: ref} = process.env;
  assert.ok(['jvm', 'wasi'].includes(kind));
  assert.ok(['first', 'other-branch', 'repeat', 'other-suite', 'reset-first', 'different-id', 'lookup-error', 'upload-failure'].includes(stage));
  assert.equal(process.env.GITHUB_REF_NAME, 'audit/858-live-checks');
  assert.equal(ref, session + (stage === 'other-branch' ? '-other' : ''));
  assert.equal(suite, `binding_${kind}` + (stage === 'other-suite' ? '_other' : ''));
  assert.equal(process.env.AUDIT_TESTBED, `${session}-${kind}`);
  const expected = ['repeat', 'reset-first', 'upload-failure'].includes(stage) ? 1 : 0;
  const title = `Benchmark regression: binding_${kind} (${session})`;
  const records = [], writes = [], warnings = [], messages = [];
  const invoke = async (name, fn, args) => {
    try {
      const result = await fn(args);
      records.push({name, args, data: result.data});
      return result;
    } catch (error) {
      records.push({name, args, error: error.message, status: error.status});
      throw error;
    }
  };
  const actions = github.rest.actions, issues = github.rest.issues;
  const wrapped = {rest: {actions: {
    listWorkflowRuns: args => {
      assert.equal(args.branch, 'audit/858-live-checks');
      assert.equal(args.workflow_id, 'bench.yml');
      assert.equal(args.per_page, 20);
      return invoke('listWorkflowRuns', actions.listWorkflowRuns, args);
    },
    listJobsForWorkflowRun: args => invoke('listJobsForWorkflowRun', actions.listJobsForWorkflowRun, args),
    downloadJobLogsForWorkflowRun: args => {
      // A real nonexistent job lookup, not a fabricated exception or alert.
      const attempted = stage === 'lookup-error' ? {...args, job_id: 0} : args;
      if (stage === 'lookup-error') records.push({name: 'lookup-error-injection', original: args, attempted});
      return invoke('downloadJobLogsForWorkflowRun', actions.downloadJobLogsForWorkflowRun, attempted);
    },
  }, issues: {
    listForRepo: args => invoke('listForRepo', issues.listForRepo, args),
    create: async args => {
      assert.equal(expected, 1, 'Unexpected notification forbidden');
      assert.equal(stage, 'repeat', 'Later stages must comment on the existing issue');
      assert.equal(args.title, title);
      const result = await invoke('create', issues.create, args);
      const readback = await invoke('get', issues.get, {owner: args.owner, repo: args.repo, issue_number: result.data.number});
      assert.equal(readback.data.title, title);
      assert.equal(readback.data.body, args.body);
      writes.push({kind: 'issue', url: result.data.html_url, title, body: args.body, verified: true});
      return result;
    },
    createComment: async args => {
      assert.equal(expected, 1, 'Unexpected notification forbidden');
      const existing = await invoke('get', issues.get, {owner: args.owner, repo: args.repo, issue_number: args.issue_number});
      assert.equal(existing.data.title, title);
      const result = await invoke('createComment', issues.createComment, args);
      const readback = await invoke('getComment', issues.getComment, {owner: args.owner, repo: args.repo, comment_id: result.data.id});
      assert.equal(readback.data.body, args.body);
      writes.push({kind: 'comment', url: result.data.html_url, title, body: args.body, verified: true});
      return result;
    },
    update: () => { throw new Error('Test must never rename an existing issue'); },
  }}};
  const coreWrapper = Object.create(core);
  coreWrapper.warning = message => { warnings.push(message); core.warning(message); };
  const originalLog = console.log;
  console.log = (...args) => { messages.push(args.join(' ')); originalLog(...args); };
  try {
    await require('./binding.cjs')({github: wrapped, context, core: coreWrapper});
    assert.equal(writes.length, expected, 'Unexpected live notification count');
    if (stage === 'lookup-error') {
      assert.ok(warnings.some(w => w.includes('Could not read')));
      assert.ok(records.some(r => r.name === 'downloadJobLogsForWorkflowRun' && r.status === 404));
      assert.ok(messages.includes('Alerts in previous run: none'));
    }
  } finally {
    console.log = originalLog;
    fs.writeFileSync('notification-receipt.json', JSON.stringify({stage, records, writes, warnings, messages}, null, 2) + '\n');
  }
};

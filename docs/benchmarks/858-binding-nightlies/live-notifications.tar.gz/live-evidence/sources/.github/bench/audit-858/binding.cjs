module.exports = async function ({github, context, core}) {
const fs = require('fs');
const { owner, repo } = context.repo;
const suite = process.env.SUITE;
const ref = process.env.BENCH_REF;
const jobName = `bench / ${suite}`;
const label = `${suite}, ${ref}`;

// Bencher lists each alert as "- <benchmark> (Latency): <.../alerts/<id>>".
// The "View results" lines use /perf? URLs, so they do not match.
const alertRe = /- (\S+) \(Latency\): https:\/\/bencher\.dev\/console\/projects\/[^/\s]+\/alerts\//g;
const parseAlerts = text => new Set([...text.matchAll(alertRe)].map(m => m[1]));

const current = parseAlerts(fs.readFileSync('binding-bencher.txt', 'utf8'));
const runUrl = `${context.serverUrl}/${owner}/${repo}/actions/runs/${context.runId}`;

let body;
if (current.size === 0) {
  // Bencher failed without listing alerts (API or upload error).
  // Report it at once so a broken setup does not go unnoticed.
  body = [
    `Bencher failed in the nightly benchmark run (${label}) but listed no alerts. This is likely an API or upload error.`,
    '',
    `**Branch:** \`${ref}\``,
    `**Measured checkout:** \`${process.env.BENCH_SHA}\``,
    `**Run:** ${runUrl}`,
  ].join('\n');
} else {
  // Search at most 20 completed runs for this suite's most recent
  // production history. A JVM-only experiment shares the v3 run
  // title but must not hide an earlier production repetition.
  let previous = new Set();
  let previousUrl = null;
  try {
    const { data: runs } = await github.rest.actions.listWorkflowRuns({
      owner, repo,
      workflow_id: 'bench.yml',
      branch: process.env.GITHUB_REF_NAME,
      status: 'completed',
      per_page: 20,
    });
    const runRef = r => {
      const m = /\(([^)]+)\)$/.exec(r.display_title || '');
      return m ? m[1] : 'main';
    };
    for (const prevRun of runs.workflow_runs) {
      if (prevRun.id >= context.runId || runRef(prevRun) !== ref) continue;
      const { data: jobs } = await github.rest.actions.listJobsForWorkflowRun({
        owner, repo, run_id: prevRun.id, per_page: 100,
      });
      const prevJob = jobs.jobs.find(j => j.name === jobName);
      if (prevJob) {
        const { data: log } = await github.rest.actions.downloadJobLogsForWorkflowRun({
          owner, repo, job_id: prevJob.id,
        });
        const text = typeof log === 'string' ? log : Buffer.from(log).toString('utf8');
        // A JVM-only experiment can share this run title. Its
        // alerts must never count as a production repetition.
        const testbed = process.env.AUDIT_TESTBED;
        if (text.includes(`History branch: ${ref}; testbed: ${testbed};`)) {
          previous = parseAlerts(text);
          previousUrl = prevRun.html_url;
          // A clean production run breaks the streak too.
          break;
        }
        const experiment = text.split('\n').some(line =>
          line.includes('History branch: binding-experiment/') && line.includes(`; testbed: ${testbed};`));
        if (prevJob.conclusion === 'failure' && !experiment) {
          // A failure before the history summary cannot establish
          // production repetition. Do not bridge it to older alerts.
          previousUrl = prevRun.html_url;
          core.warning('Previous suite job failed without a production history summary; breaking the alert streak.');
          break;
        }
      }
    }
    if (!previousUrl) core.warning('No matching production history in the last 20 completed runs; using an empty prior alert set.');
  } catch (err) {
    core.warning(`Could not read the previous run's alerts: ${err.message}`);
  }

  const repeated = [...current].filter(b => previous.has(b)).sort();
  console.log(`Alerts this run: ${[...current].join(', ')}`);
  console.log(`Alerts in previous run: ${[...previous].join(', ') || 'none'}`);
  if (repeated.length === 0) {
    const msg = `Bencher flagged ${current.size} benchmark(s) in ${label}, but none alerted on the previous run too. Not reporting.`;
    core.warning(msg);
    await core.summary
      .addHeading(`Benchmark alerts not reported (${label})`, 3)
      .addRaw(msg, true)
      .addList([...current].sort().map(b => `<code>${b}</code>`))
      .write();
    return;
  }

  body = [
    `Bencher flagged these benchmarks in the nightly run (${label}) on two runs in a row:`,
    '',
    ...repeated.map(b => `- \`${b}\``),
    '',
    `**Branch:** \`${ref}\``,
    `**Measured checkout:** \`${process.env.BENCH_SHA}\``,
    `**Run:** ${runUrl}`,
    `**Previous run:** ${previousUrl}`,
    '',
    'Please review the Bencher dashboard to confirm the regression.',
  ].join('\n');
}

const { data: openIssues } = await github.rest.issues.listForRepo({
  owner, repo,
  labels: 'performance',
  state: 'open',
  per_page: 100,
});
const title = `Benchmark regression: ${suite} (${ref})`;
// Issues for main used to be titled without the branch. Keep
// commenting on such an open issue, and give it the new title.
const legacyTitle = ref === 'main' ? `Benchmark regression: ${suite}` : null;
const existing =
  openIssues.find(i => !i.pull_request && i.title === title) ||
  openIssues.find(i => !i.pull_request && legacyTitle && i.title === legacyTitle);
let reported;
if (existing) {
  if (existing.title !== title) {
    await github.rest.issues.update({
      owner, repo, issue_number: existing.number, title,
    });
  }
  await github.rest.issues.createComment({
    owner, repo, issue_number: existing.number, body,
  });
  reported = `Commented on #${existing.number}`;
} else {
  const { data: issue } = await github.rest.issues.create({
    owner, repo, title, body,
    labels: ['performance'],
  });
  reported = `Opened #${issue.number}`;
}
core.warning(`${title}. ${reported}.`);
await core.summary
  .addHeading(`Benchmark regression reported (${label})`, 3)
  .addRaw(`${reported}.`, true)
  .addBreak()
  .addRaw(body, true)
  .write();
};

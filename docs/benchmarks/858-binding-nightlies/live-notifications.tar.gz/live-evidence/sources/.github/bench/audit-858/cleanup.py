"""Delete only a recorded, freshly revalidated disposable UUID plan."""
import json
from pathlib import Path
import sys
from uuid import UUID
from api import request
from collect import collect_plan
from scope import BRANCHES, TESTBEDS, BENCHMARKS, ids_for, require

ORDER = ('reports', 'thresholds', 'branches', 'testbeds', 'benchmarks')


def validate_plan(plan):
    require(set(plan) == set(ORDER), 'Unexpected resource kinds')
    for kind in ORDER:
        rows = plan[kind]
        require(isinstance(rows, list) and rows, 'Empty resource list')
        for row in rows:
            require(str(UUID(row['uuid'])) == row['uuid'], 'Invalid resource UUID')
        require(len(rows) == len({r['uuid'] for r in rows}), 'Duplicate resource UUID')
    for kind, names in [('branches', BRANCHES), ('testbeds', TESTBEDS), ('benchmarks', BENCHMARKS)]:
        require({row['name'] for row in plan[kind]} == names and len(plan[kind]) == len(names))
    for branch in plan['branches']:
        require(branch['head']['start_point'] is None, 'Inherited branch forbidden')
    known = {kind: {r['uuid']: r['name'] for r in plan[kind]} for kind in ('branches', 'testbeds', 'benchmarks')}
    for kind in ('reports', 'thresholds'):
        for row in plan[kind]:
            for field, collection in [('branch', 'branches'), ('testbed', 'testbeds')]:
                ref = row[field]
                require(known[collection].get(ref['uuid']) == ref['name'])
            require(row['branch']['head']['start_point'] is None, 'Inherited report/threshold forbidden')
            if kind == 'reports':
                require(row['results'] and all(row['results']), 'Unexpanded or empty report')
                allowed = set(ids_for(row['testbed']['name'].rsplit('-', 1)[1]))
                for iteration in row['results']:
                    for result in iteration:
                        ref = result['benchmark']
                        require(ref['name'] in allowed and known['benchmarks'].get(ref['uuid']) == ref['name'])


def execute(filename, receipts_path='cleanup-receipts.json'):
    archived = json.loads(Path(filename).read_text())
    validate_plan(archived)
    current = collect_plan()
    validate_plan(current)
    for kind in ORDER:
        require({r['uuid'] for r in current[kind]} == {r['uuid'] for r in archived[kind]}, 'Resources changed since archive')
    # Exact name-to-UUID mapping must also remain unchanged.
    for kind in ('branches', 'testbeds', 'benchmarks'):
        require({r['uuid']: r['name'] for r in current[kind]} == {r['uuid']: r['name'] for r in archived[kind]})
    receipts = []
    try:
        for kind in ORDER:
            for row in current[kind]:
                resource = kind + '/' + row['uuid']
                status, _, _ = request(resource, 'DELETE')
                receipt = dict(resource=resource, delete_status=status)
                receipts.append(receipt)
                require(status in (200, 202, 204), 'Deletion failed')
                check, _, _ = request(resource)
                receipt['verification_status'] = check
                require(check == 404, 'Deleted resource still present')
                print(resource, status, check)
    finally:
        Path(receipts_path).write_text(json.dumps(receipts, indent=2) + '\n')


if __name__ == '__main__':
    require(len(sys.argv) == 3 and sys.argv[1] == 'execute', 'Usage: cleanup.py execute PLAN.json')
    execute(sys.argv[2])

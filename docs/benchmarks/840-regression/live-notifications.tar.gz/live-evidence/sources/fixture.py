"""Synthetic fixtures only. Never uploads into production branch/testbeds."""
import json
import os
from pathlib import Path
import subprocess
import sys

SESSION = 'audit-840-20261105'
route = os.environ['BENCH_REF']
kind = os.environ['KIND']
stage = os.environ['STAGE']
assert route in (SESSION, SESSION + '-other')
assert kind in ('native', 'binding')
testbed = SESSION + '-' + kind
ids = [f'audit/840/20261105/{kind}/{name}' for name in ('primary', 'secondary')]
base = ['bencher', 'run', '--project', 'minigraf', '--token', os.environ['BENCHER_API_TOKEN'],
        '--hash', os.environ['GITHUB_SHA'], '--testbed', testbed,
        '--threshold-measure', 'latency', '--threshold-test', 't_test',
        '--threshold-max-sample-size', '30', '--threshold-upper-boundary', '0.999',
        '--err', '--adapter', 'json', '--file', 'fixture.json']


def upload(branch, values, output, fail=False):
    assert branch in (SESSION, SESSION + '-other')
    Path('fixture.json').write_text(json.dumps({name: {'latency': {'value': value}} for name, value in zip(ids, values)}))
    command = list(base)
    if fail:
        # Valid but nonexistent project UUID: force a real API failure, with no
        # altered credential and no production report write.
        command[command.index('--project') + 1] = '00000000-0000-0000-0000-000000000840'
    # Never print command: it contains a runtime-only credential.
    result = subprocess.run(command + ['--branch', branch], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    Path(output).write_bytes(result.stdout)
    sys.stdout.buffer.write(result.stdout)
    return result.returncode


if stage == 'seed':
    for branch in (SESSION, SESSION + '-other'):
        for index, value in enumerate((99, 100, 101, 99, 100)):
            code = upload(branch, [value, value], f'seed-{branch}-{index}.txt')
            if code:
                sys.exit(code)
else:
    values = {
        'first': [1e6, 100], 'other-branch': [1e6, 100],
        'repeat': [1e12, 100], 'other-suite': [1e18, 100],
        'reset-first': [1e24, 100], 'different-id': [100, 1e6],
        'lookup-error': [100, 1e12], 'upload-failure': [100, 100],
    }[stage]
    Path('bench-selection.json').write_text(json.dumps(dict(suite=os.environ['SUITE'], ref=route,
        sha=os.environ['GITHUB_SHA'], workflowSha=os.environ['GITHUB_SHA'], selected=ids,
        filter='^audit/840/', threshold='0.999')))
    # These are fixture execution records, not timed Criterion measurements.
    Path('fixture-execution.txt').write_text(''.join(f'Benchmarking {name}: Analyzing\n' for name in ids))
    code = upload(route, values, 'bencher_out.txt', fail=stage == 'upload-failure')
    Path('binding-bencher.txt').write_bytes(Path('bencher_out.txt').read_bytes())
    sys.exit(code)

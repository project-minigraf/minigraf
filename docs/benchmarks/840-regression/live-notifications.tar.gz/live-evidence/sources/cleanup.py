"""Plan or execute deletion of ONLY the authorized #840 synthetic resources."""
import json
import os
from pathlib import Path
import sys
from urllib.error import HTTPError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

SESSION = 'audit-840-20261105'
BRANCHES = {SESSION, SESSION + '-other'}
TESTBEDS = {SESSION + '-native', SESSION + '-binding'}
BENCHMARKS = {f'audit/840/20261105/{kind}/{case}' for kind in ('native', 'binding') for case in ('primary', 'secondary')}
BASE = 'https://api.bencher.dev/v0/projects/minigraf/'


def request(path, method='GET'):
    headers = {'Content-Type': 'application/json'}
    if method != 'GET':
        headers['Authorization'] = 'Bearer ' + os.environ['BENCHER_API_TOKEN']
    try:
        with urlopen(Request(BASE + path, headers=headers, method=method), timeout=60) as response:
            body = response.read()
            return response.status, json.loads(body) if body else None, dict(response.headers)
    except HTTPError as error:
        if method == 'GET' and error.code == 404:
            return 404, None, {}
        raise RuntimeError(f'{method} {path}: HTTP {error.code}') from None


def listed(kind, branch):
    result = []
    page = 1
    while True:
        query = urlencode(dict(branch=branch, expand='true', per_page=100, page=page))
        status, rows, headers = request(kind + '?' + query)
        assert status == 200 and isinstance(rows, list)
        result.extend(rows)
        total = next(int(value) for key, value in headers.items() if key.lower() == 'x-total-count')
        if len(result) == total:
            return result
        assert rows and len(result) < total
        page += 1


def plan():
    result = {kind: [] for kind in ('reports', 'thresholds', 'branches', 'testbeds', 'benchmarks')}
    benchmarks = {}
    for branch in sorted(BRANCHES):
        status, value, _ = request('branches/' + branch)
        assert status == 200 and value['name'] == branch and value['head']['start_point'] is None
        result['branches'].append(value)
        for report in listed('reports', branch):
            assert report['branch']['name'] == branch and report['testbed']['name'] in TESTBEDS
            for iteration in report['results']:
                for row in iteration:
                    benchmark = row['benchmark']
                    assert benchmark['name'] in BENCHMARKS
                    benchmarks[benchmark['uuid']] = benchmark
            result['reports'].append(report)
        for threshold in listed('thresholds', branch):
            assert threshold['branch']['name'] == branch and threshold['testbed']['name'] in TESTBEDS
            result['thresholds'].append(threshold)
    for testbed in sorted(TESTBEDS):
        status, value, _ = request('testbeds/' + testbed)
        assert status == 200 and value['name'] == testbed
        result['testbeds'].append(value)
    result['benchmarks'] = sorted(benchmarks.values(), key=lambda b: b['name'])
    assert {b['name'] for b in result['benchmarks']} == BENCHMARKS
    for values in result.values():
        assert len(values) == len({v['uuid'] for v in values})
    return result


if __name__ == '__main__':
    mode, filename = sys.argv[1:]
    assert mode in ('plan', 'execute')
    path = Path(filename)
    current = plan()
    if mode == 'plan':
        path.write_text(json.dumps(current, indent=2) + '\n')
        print({k: len(v) for k, v in current.items()})
    else:
        archived = json.loads(path.read_text())
        for kind in current:
            assert {r['uuid'] for r in current[kind]} == {r['uuid'] for r in archived[kind]}, 'Resources changed since archive'
        receipts = []
        try:
            for kind in ('reports', 'thresholds', 'branches', 'testbeds', 'benchmarks'):
                for row in current[kind]:
                    resource = kind + '/' + row['uuid']
                    status, body, _ = request(resource, 'DELETE')
                    assert status in (200, 202, 204)
                    check, _, _ = request(resource)
                    assert check == 404
                    receipts.append(dict(resource=resource, delete_status=status, verification_status=check))
                    print(resource, status, check)
        finally:
            Path('cleanup-receipts.json').write_text(json.dumps(receipts, indent=2) + '\n')

import importlib.util
from pathlib import Path
import unittest
from unittest.mock import patch

spec = importlib.util.spec_from_file_location('cleanup', Path(__file__).with_name('cleanup.py'))
cleanup = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cleanup)


class ScopeTests(unittest.TestCase):
    def candidate(self, foreign=None):
        def request(path):
            kind, name = path.split('/')
            return 200, dict(uuid=name, name=name, head={'start_point': None}), {}

        def listed(kind, branch):
            testbed = sorted(cleanup.TESTBEDS)[0]
            if kind == 'thresholds':
                return [dict(uuid=branch, branch={'name': branch}, testbed={'name': testbed})]
            return [dict(uuid=branch, branch={'name': 'v3' if foreign == 'branch' else branch},
                testbed={'name': 'ubuntu-latest' if foreign == 'testbed' else testbed},
                results=[[dict(benchmark=dict(uuid=name, name='query/production' if foreign == 'benchmark' else name))
                          for name in sorted(cleanup.BENCHMARKS)]])]

        with patch.object(cleanup, 'request', request), patch.object(cleanup, 'listed', listed):
            return cleanup.plan()

    def test_allows_only_fixed_test_scope(self):
        self.assertEqual(len(self.candidate()['benchmarks']), 4)

    def test_rejects_production_branch(self):
        with self.assertRaises(AssertionError):
            self.candidate('branch')

    def test_rejects_production_testbed(self):
        with self.assertRaises(AssertionError):
            self.candidate('testbed')

    def test_rejects_production_benchmark(self):
        with self.assertRaises(AssertionError):
            self.candidate('benchmark')


unittest.main()

// Invoke the unchanged production notification body against live GitHub APIs.
// The only isolation substitution is the workflow lookup's branch filter.
const fs = require('node:fs');
const assert = require('node:assert/strict');

module.exports = async ({ github, context, core }) => {
  assert.ok(['audit-840-20261105', 'audit-840-20261105-other'].includes(process.env.BENCH_REF));
  assert.equal(process.env.GITHUB_REF_NAME, 'audit/840-live-checks');
  assert.ok(/^(audit_840_native|binding_audit_840)(?:_other)?$/.test(process.env.SUITE));
  const records = [], writes = [], warnings = [];
  const invoke = async (name, fn, args) => {
    try {
      const result = await fn(args);
      records.push({ name, args, data: result.data });
      return result;
    } catch (error) {
      records.push({ name, args, error: error.message, status: error.status });
      throw error;
    }
  };
  const actions = github.rest.actions;
  const issues = github.rest.issues;
  const wrapped = { rest: { actions: {
    listWorkflowRuns: args => {
      assert.equal(args.branch, 'main');
      assert.equal(args.workflow_id, 'bench.yml');
      return invoke('listWorkflowRuns', actions.listWorkflowRuns, { ...args, branch: process.env.GITHUB_REF_NAME });
    },
    listJobsForWorkflowRun: args => invoke('listJobsForWorkflowRun', actions.listJobsForWorkflowRun, args),
    downloadJobLogsForWorkflowRun: args => invoke('downloadJobLogsForWorkflowRun', actions.downloadJobLogsForWorkflowRun,
      process.env.STAGE === 'lookup-error' ? { ...args, job_id: 0 } : args),
  }, issues: {
    listForRepo: args => invoke('listForRepo', issues.listForRepo, args),
    create: async args => {
      assert.match(args.title, /^Benchmark regression: (audit_840_native|binding_audit_840) \(audit-840-20261105\)$/);
      const result = await invoke('create', issues.create, args);
      writes.push({ url: result.data.html_url, title: args.title, body: args.body });
      return result;
    },
    createComment: async args => {
      const existing = await issues.get({ owner: args.owner, repo: args.repo, issue_number: args.issue_number });
      assert.match(existing.data.title, /^Benchmark regression: (audit_840_native|binding_audit_840) \(audit-840-20261105\)$/);
      const result = await invoke('createComment', issues.createComment, args);
      writes.push({ url: result.data.html_url, title: existing.data.title, body: args.body });
      return result;
    },
    update: () => { throw new Error('Test must never rename an existing issue'); },
  } } };
  const coreWrapper = Object.create(core);
  coreWrapper.warning = message => { warnings.push(message); core.warning(message); };
  try {
    await require(`./${process.env.KIND}.cjs`)({ github: wrapped, context, core: coreWrapper });
    const expected = ['repeat', 'upload-failure'].includes(process.env.STAGE) ? 1 : 0;
    assert.equal(writes.length, expected, 'unexpected live notification count');
    if (process.env.STAGE === 'lookup-error') {
      assert.ok(warnings.some(w => w.includes('Could not read')));
      assert.ok(records.some(r => r.name === 'downloadJobLogsForWorkflowRun' && r.status === 404));
    }
  } finally {
    fs.writeFileSync('notification-receipt.json', JSON.stringify({ stage: process.env.STAGE, records, writes, warnings }, null, 2));
  }
};

import json,re,subprocess,time
from pathlib import Path
root=Path('/tmp/minigraf-840-live'); ids=json.loads((root/"baseline-runs.json").read_text())
repo='project-minigraf/minigraf'
def command(args):
 return subprocess.check_output(args,text=True)
while True:
 run=ids[-1]
 data=json.loads(command(['gh','api',f'repos/{repo}/actions/runs/{run}']))
 (root/f'baseline-{run}.json').write_text(json.dumps(data,indent=2)+'\n')
 (root/'baseline-runs.json').write_text(json.dumps(ids)+'\n')
 if data['status']!='completed':
  print(f'Run {run}: {data["status"]}',flush=True)
  time.sleep(30)
  continue
 print(f'Run {run}: {data["conclusion"]}',flush=True)
 if data['conclusion']!='success': raise SystemExit('Inspect failed run before continuing')
 if len(ids)==2: break
 result=command(['gh','workflow','run','bench.yml','--repo',repo,'--ref','main','-f','ref=v3','-f','binding-ref=v3'])
 print(result,flush=True)
 ids.append(int(re.search(r'/actions/runs/(\d+)',result)[1]))
print('Completed independent v3 runs',ids,flush=True)

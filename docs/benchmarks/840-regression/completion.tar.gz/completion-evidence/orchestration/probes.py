import json,re,subprocess,time
from pathlib import Path
from urllib.request import urlopen
root=Path('/tmp/minigraf-840-live');repo='project-minigraf/minigraf'
def gh(args):return subprocess.check_output(['gh']+args,text=True)
def getrun(run):return json.loads(gh(['api',f'repos/{repo}/actions/runs/{run}']))
def snapshot(name):
 with urlopen('https://api.bencher.dev/v0/projects/minigraf/branches/v3',timeout=60) as response:data=response.read()
 (root/name).write_bytes(data)
 assert json.loads(data)['head']['uuid']=='01a1a84c-e947-745c-98e7-018e0c2245a3'
while True:
 ids=json.loads((root/'baseline-runs.json').read_text())
 if len(ids)==2:
  data=getrun(ids[-1])
  if data['status']=='completed':
   assert data['conclusion']=='success';break
 time.sleep(30)
plan=[dict(run=run,role='full-v3') for run in ids]
(root/'measurement-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
for branch,probe,role in [('v3','c','c-probe'),('main','udf','main-probe'),('v3','udf','v3-probe')]:
 snapshot('before-'+role+'.json')
 out=gh(['workflow','run','bench.yml','--repo',repo,'--ref','audit/840-history-probe','-f',f'ref={branch}','-f',f'probe={probe}','-f','binding-ref=v3'])
 run=int(re.search(r'/actions/runs/(\d+)',out)[1]);print(role,run,flush=True)
 plan.append(dict(run=run,role=role));(root/'measurement-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
 while True:
  data=getrun(run)
  if data['status']=='completed':break
  time.sleep(20)
 print(role,run,data['conclusion'],flush=True)
 assert data['conclusion']=='success'
 snapshot('after-'+role+'.json')
print('All real measurement and history probes complete',flush=True)
